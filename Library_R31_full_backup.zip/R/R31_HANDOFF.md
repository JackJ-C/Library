# R31补充交接：已匹配远端正式结果，本执行增量未发布

## 阅读入口

主报告：`docs/R31_REPLAY_SUPPLEMENT.md`。审核范围及限制：`docs/R31_AUDIT.md`。机器可读结果：`results/r28_r31/REPLAY_SUMMARY.json`。断点回执：`results/r28_r31/recovery/RESUME_RECEIPT.json`。

原来的`FINAL_HANDOFF.md`属于R27，不覆盖它。R31主结果是负结果：空间构造并参与提议有有限支持，稳定空间收益与严格递归环节没有通过两批验收。体验没有测量。

## 执行命令

在本包或Library的R目录中，使用Python 3.13.5（本次实际环境，全部标准库）：

```bash
python -m r28_r31.tests
python tools/r31_supplemental_audit.py
python tools/r31_audit_regressions.py
python tools/r31_posthoc_diagnostics.py
python tools/r31_finalize_summary.py
python tools/verify_r31_delivery.py
```

原48份原档已存在；不覆盖它们。完整重算可指定不同输出位置：

```bash
python -m r28_r31.run A --output results/r28_r31/reproduction_A
python -m r28_r31.run B --output results/r28_r31/reproduction_B
```

上述重算不增加统计样本。比较各原档的解压JSON SHA-256，而不是将重复算出的轨迹再次计数。事后诊断不会进入学习器；其测试最佳候选不可用于声称自主发现。

## 与此前R28模型的关系

Git已存在面向实施的`docs/R28_MODEL_ADOPTION.md`。本包另外保留上一轮完整模型MD、反例代码和当时原结果的逐字副本于`reference/r28_review_original/`。当时稿件中的“未提交”是历史事实，不改写；本次重新执行的18项诊断回执另存于recovery目录，不覆盖旧回执。

## 发布限制和补丁

初读R HEAD为`61e94edafb6f501b2a805d8e3e4ffb6409943083`，随后读到`f40d22f25a46d2d75b14a212b5f62526c7454692`，正式报告、清单和统计已发布。本执行的48份重跑原档与其全部摘要一致。

本执行接口没有写入动作，git CLI又在DNS解析处失败，因此**这些远端新提交不是本执行创建的，本执行的补充文件没有提交号**。本地STATUS是基于这一最终事实准备的更新草稿。

补丁以f40d22f为发布基线，只增加R/内不同名称的补充文档、重跑原档、只读工具、原R28材料备份，并更新R/STATUS.md；不覆盖已有正式报告、PUBLIC_SUMMARY及远端审核工具；不包含对被冻结来源、M、main或根README的改动。应用前必须在Library的R分支、核对基线与工作区，并先执行`git apply --check`；若HEAD或目标文件发生变化，先审查差异，不能强制覆盖。提交只能包含补丁清单中的路径，不把其他未提交工作顺带加入。不建PR，不合并。

本次研究编号止于R31；没有预占或执行R32。后续科学问题见主报告第8节，属于尚未运行的研究提案，不列为完成项。
