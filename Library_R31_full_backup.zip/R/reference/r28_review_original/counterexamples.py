#!/usr/bin/env python3
"""Synthetic diagnostics for a proposed Library joint-deployment model.

NOT a replay of Library, NOT an R28 experiment, NOT evidence of RSI.
Uses only Python's standard library. No network, repository access, or code execution
from generated program strings. Every example and test is constructed for this review.

Run: python counterexamples.py --out results.json
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
import math
import sys
import unittest
from dataclasses import asdict, dataclass
from fractions import Fraction
from pathlib import Path
from typing import Iterable, Mapping, Sequence


def radius(n: int, *, generation: int = 1, comparisons: int = 1,
           max_looks: int = 1, delta: float = 0.05) -> float:
    """Two-sided paired Hoeffding radius for values in [-1,1].

    A comparison's conditional error allowance is
    delta / (comparisons * max_looks * t * (t+1)).
    All comparisons must be frozen before their fresh independent evaluation blocks.
    Conditional iid assumptions and genuine block identities are protocol obligations;
    this numeric function does not test independence, provenance, or deployment identity.
    """
    for value in (n, generation, comparisons, max_looks):
        if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
            raise ValueError("Counts must be positive integers")
    if not math.isfinite(delta) or not 0 < delta < 1:
        raise ValueError("delta must be finite and between zero and one")
    return math.sqrt(2.0 / n * math.log(
        2.0 * comparisons * max_looks * generation * (generation + 1) / delta))


@dataclass(frozen=True)
class Certificate:
    n: int
    mean_gain: float
    radius: float
    lower: float
    upper: float
    status: str


def paired_certificate(gains: Sequence[float], *, generation: int = 1,
                       comparisons: int = 1, max_looks: int = 1,
                       delta: float = 0.05, margin: float = 0.0) -> Certificate:
    """Numerical interval only; ACCEPT does not override the external runtime gates."""
    if not gains:
        raise ValueError("At least one independent paired block is required")
    if not math.isfinite(margin) or margin < 0:
        raise ValueError("Margin must be finite and nonnegative")
    xs = [float(x) for x in gains]
    if any(not math.isfinite(x) or x < -1 or x > 1 for x in xs):
        raise ValueError("Paired gains must be finite and in [-1,1]")
    r = radius(len(xs), generation=generation, comparisons=comparisons,
               max_looks=max_looks, delta=delta)
    mean = math.fsum(xs) / len(xs)
    lower, upper = mean - r, mean + r
    status = "ACCEPT" if lower > margin else ("REJECT" if upper <= margin else "UNKNOWN")
    return Certificate(len(xs), mean, r, lower, upper, status)


def support_closure(seed: Iterable[str], edges: Mapping[str, Sequence[str]]) -> set[str]:
    """Edges point from a required support to a dependent proof/certificate node.

    A different independently supported certificate is a different node. Historical
    references must NOT be supplied as support edges. Nodes are not deleted.
    """
    invalid = set(seed)
    frontier = list(invalid)
    while frontier:
        node = frontier.pop()
        for child in edges.get(node, ()):
            if child not in invalid:
                invalid.add(child)
                frontier.append(child)
    return invalid


def bounded_vm(events: Iterable[str], fuel: int) -> str:
    """Consume at most fuel abstract VM events; never run an arbitrary program."""
    if isinstance(fuel, bool) or not isinstance(fuel, int) or fuel <= 0:
        raise ValueError("fuel must be positive")
    iterator = iter(events)
    for _ in range(fuel):
        try:
            event = next(iterator)
        except StopIteration:
            return "HALTED"
        if event == "HALT":
            return "HALTED"
    return "UNKNOWN_TIMEOUT"


def xor_risk(observed: Mapping[str, int]) -> float:
    worlds = [(x, y) for x in (0, 1) for y in (0, 1)
              if ("x" not in observed or x == observed["x"])
              and ("y" not in observed or y == observed["y"])]
    positives = sum(x ^ y for x, y in worlds)
    return min(positives, len(worlds) - positives) / len(worlds)


def minimum_n_for_radius(gap: float) -> int:
    """First n with the stated t=K=N=1 radius strictly below gap.

    This is a sufficient certificate resolution, NOT an information lower bound and
    NOT a power guarantee. A uniform sufficient acceptance condition is gap > 2r.
    """
    if gap <= 0:
        raise ValueError("gap must be positive")
    return math.floor(2 * math.log(80) / gap ** 2) + 1


def diagnose() -> dict:
    joint = {"old_program_old_calibration": 0.10,
             "new_program_old_calibration": 0.08,
             "old_program_new_calibration": 0.09,
             "new_program_new_calibration": 0.16}
    interaction = joint["new_program_new_calibration"] - joint["new_program_old_calibration"] \
        - joint["old_program_new_calibration"] + joint["old_program_old_calibration"]
    descriptors = list(itertools.product(range(-2, 3), range(3)))
    score_functions = (lambda m, u: m-u, lambda m, u: 2*(m-u), lambda m, u: m-u+7)
    rankings = [tuple(sorted(range(len(descriptors)),
                             key=lambda i: (f(*descriptors[i]), i))) for f in score_functions]
    # Query-only Bayes objectives, with a fixed cost of 0.1 per observation.
    xor = {"no_query_total": xor_risk({}),
           "one_query_total": 0.1 + xor_risk({"x": 0}),
           "two_queries_total": 0.2 + xor_risk({"x": 0, "y": 0})}
    support_edges = {"observation": ["model_certificate"],
                     "model_certificate": ["deployment_license"]}
    invalid = sorted(support_closure(["observation"], support_edges))
    test_domain = list(range(17))
    f = lambda x: x*x
    hidden = lambda x: x*x + int(x == 17)
    candidates = {"cheap": {"risk": 0.10, "cost": 0.2},
                  "expensive": {"risk": 0.0, "cost": 10.0}}
    objective = lambda k: candidates[k]["risk"] + 0.001*candidates[k]["cost"]
    unconstrained = min(candidates, key=objective)
    constrained = min((k for k in candidates if candidates[k]["cost"] <= 1.0), key=objective)
    # A pure coordinate relabeling, not a physical intervention.
    original = {"robot": 0, "target": 1}
    renamed = {k: v-10 for k, v in original.items()}
    sign = lambda v: (v > 0) - (v < 0)
    relative_actions = [sign(s["target"]-s["robot"]) for s in (original, renamed)]
    absolute_actions = [sign(s["target"]) for s in (original, renamed)]
    # Two proposed internal attributions that no allowed u can distinguish.
    attributions = [(1, 0), (0, 1)]
    outputs = [[a+b+u for u in range(-10, 11)] for a, b in attributions]
    r12 = radius(12)
    certificate = paired_certificate([0.001] * 12)
    positive = paired_certificate([0.2] * 1024)
    overlap = {"unique_blocks": 12, "three_copies_are_not_independent": 36,
               "correct_radius": r12, "incorrect_naive_radius": radius(36)}
    cases = {
        "C01_joint_interaction": {"risks": joint, "interaction": interaction,
                                   "each_separate_change_improves": True,
                                   "joint_gain": 0.1 - 0.16},
        "C02_syntax_not_strategy": {"expressions": ["mean-uncert", "2*(mean-uncert)", "mean-uncert+7"],
                                     "observed_rank_classes": len(set(rankings)),
                                     "scope": "15 explicitly enumerated descriptors; operation costs remain separate"},
        "C03_rare_failure": {"parent_risk": 0.001, "candidate_risk": 0.01,
                              "no_rare_case_in_12_probability": 0.99**12,
                              "mean_rule_false_accept_probability": 0.99**12,
                              "sample_certificate_on_no_rare_case": asdict(certificate),
                              "n_for_at_least_one_rare_case_with_95pct_probability": math.ceil(math.log(0.05)/math.log(0.99))},
        "C04_finite_hidden_branch": {"agree_on_test_domain": all(f(x)==hidden(x) for x in test_domain),
                                      "test_domain": test_domain,
                                      "witness_x": 17, "f_17": f(17), "g_17": hidden(17)},
        "C05_unidentifiable_attribution": {"two_attributions": attributions,
                                            "same_observed_outputs": outputs[0] == outputs[1],
                                            "analytic_family": "y=a+b+u for every allowed u"},
        "C06_regime_change": {"validation_parent_risk": 0.2, "validation_new_risk": 0.0,
                                "post_shift_parent_risk": 0.2, "post_shift_new_risk": 1.0},
        "C07_evidence_synergy": xor,
        "C08_history_not_free": {"fresh_only_cost": 1.0, "read_and_recheck_cost": 101.0,
                                  "equal_final_task_risk": True},
        "C09_stable_not_progress": {"initial_potential": 0.1, "min_strict_gain": 0.01,
                                     "max_accepted_improvements_on_same_bounded_scale": int(Fraction(1,10)/Fraction(1,100))},
        "C10_gate_delay": {"activation_at_t_0": 1.0, "activation_at_t_0_01": math.exp(-0.01),
                            "half_life_if_beta_1": math.log(2), "logical_license_after_withdrawal": False,
                            "note": "Activation is NOT an epistemic probability and must not authorize execution"},
        "C11_support_and_reference": {"invalid_after_withdrawal": invalid,
                                       "historical_reinterpretation_only_references_old_observation": True,
                                       "reinterpretation_should_stay_valid": "reinterpretation" not in invalid},
        "C12_coordinate_relabeling": {"relative_policy_actions": relative_actions,
                                      "absolute_policy_actions": absolute_actions},
        "C13_bounded_interpreter": {"finite_program": bounded_vm(["RUNNING", "HALT"], 3),
                                     "infinite_program_with_fuel": bounded_vm(itertools.repeat("RUNNING"), 10)},
        "C14_correlated_splits": overlap,
        "C15_live_memory_changes_behavior": {"frozen_certificate_memory": "cursor=12, scale=1",
                                               "later_memory_view": "cursor=13, scale=0.25",
                                               "same_source_does_not_mean_same_deployed_snapshot": True},
    }
    ablations = {
        "Fermat_path_lookahead": {"full": xor["two_queries_total"], "removed_greedy": xor["no_query_total"],
                                   "removed_mechanism": "multistep information planning", "result": "greedy misses jointly useful queries"},
        "Lagrange_budget_constraints": {"full_choice": constrained, "removed_choice": unconstrained,
                                         "budget": 1.0, "removed_choice_cost": candidates[unconstrained]["cost"],
                                         "result": "unconstrained risk optimum is infeasible"},
        "Euler_support_graph": {"full_invalid_nodes": invalid, "without_propagation_invalid_nodes": ["observation"],
                                "result": "downstream license incorrectly remains live; graph semantics can be stored in JSON"},
        "Einstein_coordinate_consistency": {"full_actions": relative_actions, "without_consistency_example": absolute_actions,
                                             "result": "same physical relation can yield different actions under relabeling"},
        "Lyapunov_whole_bundle_descent_gate": {"full_joint_deployment": "not accepted", "without_gate_risk": 0.16,
                                                "old_risk": 0.10, "result": "separate improvements do not imply joint descent"},
        "Turing_finite_execution_scope": {"full_infinite_candidate_result": "UNKNOWN_TIMEOUT",
                                          "without_limit": "no general termination guarantee; unbounded program was NOT executed"},
        "Huxley_optional_activation": {"full_hard_license_after_withdrawal": False,
                                        "without_activation_hard_license_after_withdrawal": False,
                                        "result": "core certificate theorem unchanged; no demonstrated need for activation"},
        "Hoeffding_uncertainty_certificate": {"full_no_rare_case_status": certificate.status,
                                              "removed_mean_rule_false_accept_probability": 0.99**12,
                                              "result": "fresh samples alone do not bound false acceptance"},
    }
    return {
        "scope": "Constructed arithmetic and finite-state diagnostics, not Library rerun or R28",
        "repository_reads": {"main": "15dd68540c17753b6faf2c26f6278d314037fe0b",
                             "R": "3c51492efc01a2a70be730008cd2fcf749b9afe6"},
        "repository_writes": 0,
        "counterexamples": cases, "semantic_ablations": ablations,
        "certificate_resolution": {"radius_n12_t1_K1_looks1_delta005": r12,
                                   "radius_n12_t1_K8_looks12_delta005": radius(12, comparisons=8, max_looks=12),
                                   "first_n_radius_below_001": minimum_n_for_radius(0.01),
                                   "first_n_radius_below_02": minimum_n_for_radius(0.2),
                                   "positive_control_n1024_gain02": asdict(positive),
                                   "caution": "Radius thresholds are sufficient for this conservative certificate, not universal sample lower bounds"},
    }


class ConstructedTests(unittest.TestCase):
    def setUp(self):
        self.r = diagnose()

    def test_joint_interaction(self):
        c = self.r["counterexamples"]["C01_joint_interaction"]
        self.assertAlmostEqual(c["interaction"], 0.09)
        self.assertLess(c["joint_gain"], 0)

    def test_ranking_duplication(self):
        self.assertEqual(self.r["counterexamples"]["C02_syntax_not_strategy"]["observed_rank_classes"], 1)

    def test_rare_failure_exact_probability(self):
        c = self.r["counterexamples"]["C03_rare_failure"]
        self.assertGreater(c["candidate_risk"], c["parent_risk"])
        self.assertAlmostEqual(c["mean_rule_false_accept_probability"], 0.8863848717161292)
        self.assertEqual(c["sample_certificate_on_no_rare_case"]["status"], "UNKNOWN")

    def test_hidden_branch(self):
        c = self.r["counterexamples"]["C04_finite_hidden_branch"]
        self.assertTrue(c["agree_on_test_domain"])
        self.assertNotEqual(c["f_17"], c["g_17"])

    def test_unidentifiability(self):
        self.assertTrue(self.r["counterexamples"]["C05_unidentifiable_attribution"]["same_observed_outputs"])

    def test_lookahead_xor(self):
        c = self.r["counterexamples"]["C07_evidence_synergy"]
        self.assertEqual(c["no_query_total"], 0.5)
        self.assertGreater(c["one_query_total"], c["no_query_total"])
        self.assertLess(c["two_queries_total"], c["no_query_total"])

    def test_dependency_not_reference(self):
        invalid = support_closure(["e"], {"e": ["cert"], "cert": ["license"]})
        self.assertEqual(invalid, {"e", "cert", "license"})
        self.assertNotIn("historical_commentary", invalid)

    def test_alternative_certificate_not_invalidated(self):
        invalid = support_closure(["e1"], {"e1": ["cert1"], "e2": ["cert2"]})
        self.assertNotIn("cert2", invalid)

    def test_cycle_closure_terminates(self):
        self.assertEqual(support_closure(["a"], {"a": ["b"], "b": ["a"]}), {"a", "b"})

    def test_relabeling(self):
        c = self.r["counterexamples"]["C12_coordinate_relabeling"]
        self.assertEqual(c["relative_policy_actions"], [1, 1])
        self.assertEqual(c["absolute_policy_actions"], [1, -1])

    def test_finite_fuel(self):
        self.assertEqual(bounded_vm(itertools.repeat("RUNNING"), 100), "UNKNOWN_TIMEOUT")
        self.assertEqual(bounded_vm(["HALT"], 1), "HALTED")

    def test_budget_ablation(self):
        a = self.r["semantic_ablations"]["Lagrange_budget_constraints"]
        self.assertEqual(a["full_choice"], "cheap")
        self.assertGreater(a["removed_choice_cost"], a["budget"])

    def test_activation_not_authorization(self):
        a = self.r["semantic_ablations"]["Huxley_optional_activation"]
        self.assertFalse(a["full_hard_license_after_withdrawal"])
        self.assertFalse(a["without_activation_hard_license_after_withdrawal"])

    def test_nonvacuous_large_margin(self):
        self.assertEqual(paired_certificate([0.2]*1024).status, "ACCEPT")
        self.assertEqual(paired_certificate([-0.2]*1024).status, "REJECT")

    def test_margin_resolution_not_power_claim(self):
        n = minimum_n_for_radius(0.01)
        self.assertLess(radius(n), 0.01)
        self.assertGreaterEqual(radius(n-1), 0.01)

    def test_alpha_budget_telescopes(self):
        T = 1000
        used = math.fsum(0.05/(t*(t+1)) for t in range(1,T+1))
        self.assertAlmostEqual(used, 0.05*(1-1/(T+1)))
        self.assertLess(used, 0.05)

    def test_overlap_cannot_increase_information(self):
        c = self.r["counterexamples"]["C14_correlated_splits"]
        self.assertGreater(c["correct_radius"], c["incorrect_naive_radius"])

    def test_input_errors(self):
        for bad in ([], [float("nan")], [1.1], [float("inf")]):
            with self.assertRaises(ValueError):
                paired_certificate(bad)
        for bad in (0, -1, True):
            with self.assertRaises(ValueError):
                radius(bad)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--out", type=Path, default=Path("results.json"))
    args = parser.parse_args()
    result = unittest.TextTestRunner(stream=sys.stdout, verbosity=2).run(
        unittest.defaultTestLoader.loadTestsFromTestCase(ConstructedTests))
    data = diagnose()
    data["test_run"] = {"tests": result.testsRun, "failures": len(result.failures),
                        "errors": len(result.errors), "successful": result.wasSuccessful(),
                        "what_pass_means": "constructed failures and arithmetic were reproduced; no RSI validation"}
    data["script_sha256"] = hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
    args.out.parent.mkdir(parents=True, exist_ok=True)
    args.out.write_text(json.dumps(data, ensure_ascii=False, indent=2)+"\n", encoding="utf-8")
    return 0 if result.wasSuccessful() else 1


if __name__ == "__main__":
    raise SystemExit(main())
