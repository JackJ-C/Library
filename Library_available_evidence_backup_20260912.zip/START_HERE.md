# Library 原始数据备份：先看这里

这份包保存本次会话实际取得的九份原始研究运行包，原包字节不改动。
已明确核对：最新M54–M57待传清单19份，以及此前M37–M48待传清单13份，全部32份原始文件均包含在这些原包里，共10,912,094字节。

## 你只需要保留这一个ZIP

不要先解压再上传，不必逐个上传里面的文件。将外层 `Library_available_evidence_backup_20260912.zip` 作为一个文件上传到原有交付分支即可。它小于GitHub网页单文件25MiB限额。不要选择Publish或改变仓库可见性。

仓库：JackJ-C/Library
分支：delivery/m54-m57-verified-20260911
建议提交说明：backup: archive available Library raw evidence packages

代码和报告已经在GitHub；此ZIP是保存完整原始材料，不能把“打包完成”说成“远端上传完成”。上传后可用清单校验。

## 解压与核验

original_packages/ 里是原来九份完整ZIP，每份有独立源码、结果和说明。不同阶段同名模块可能不同，不要直接互相覆盖。
BACKUP_MANIFEST.json 列出每个原包、内部文件和32份待传文件的SHA-256。
`python3 verify_backup.py` 可在外层ZIP解压后检查全部内容；只使用Python标准库，不联网、不重新运行研究。

## 范围说明

这不是全部M0–M57所有分支的完整镜像。当前没有取得M21–M24独立ZIP；M0–M7和其他仅在远端的历史文件也没有被本备份自动补齐。已知的32份待传文件全部在内，但不把“已知清单补齐”冒充“全历史无遗漏”。
