"""Offline checksum verification; does not execute archived research programs."""
from pathlib import Path
from hashlib import sha256
from io import BytesIO
import json,zipfile
root=Path(__file__).resolve().parent
m=json.loads((root/'BACKUP_MANIFEST.json').read_text(encoding='utf-8'))
checked=0
for p in m['packages']:
 data=(root/p['path']).read_bytes()
 if len(data)!=p['bytes'] or sha256(data).hexdigest()!=p['sha256']:
  raise SystemExit('Package mismatch: '+p['path'])
 with zipfile.ZipFile(BytesIO(data)) as z:
  expected={f['path'] for f in p['files']}
  if expected!={i.filename for i in z.infolist() if not i.is_dir()}:
   raise SystemExit('Package inventory mismatch')
  for f in p['files']:
   b=z.read(f['path'])
   if len(b)!=f['bytes'] or sha256(b).hexdigest()!=f['sha256']:
    raise SystemExit('Member mismatch: '+f['path'])
   checked+=1
print(json.dumps({'status':'VERIFIED','packages':len(m['packages']),
 'member_files':checked,'declared_backlog_files':len(m['pending_files_32'])}))
