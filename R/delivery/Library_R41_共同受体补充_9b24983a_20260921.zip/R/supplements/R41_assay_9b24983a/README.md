# 最终目录与远端并行协议说明

本轮为R41共同受体产物协议的独立补充，最终目录`R/supplements/R41_assay_9b24983a/`。请先读NAMESPACE_AND_REMOTE.md；不要覆盖远端另一个R/r41协议。以下命令已对应隔离目录。

# R41 完整证据包

先读 REPORT.md，再读 PROTOCOL.md 与 THEORY.md。FROZEN.json 是本次正式前封存；FREEZE_RECEIPT.md记录其身份。原R39/R40完整原档没有在本次恢复，本包不冒充它们；报告中R40数字不计入R41正式统计。

本包含本轮全部322份正式原档、各自执行与独立核验回执、开发失败、26项测试、4例原样重放、第三路径算术核对，以及12份原样继承的R37执行依赖。无需安装第三方包。实测CPython3.13.5；其他Python版本可能运行，但跨版本逐字节复现未作保证。

## 使用

在独立目录解压，进入其中的R目录：

```bash
python -m supplements.R41_assay_9b24983a.tests
python -O -m supplements.R41_assay_9b24983a.tests
python -m supplements.R41_assay_9b24983a.run origin C
python -m supplements.R41_assay_9b24983a.run origin D
```

前两条重新跑开发机制/破坏测试，不新增正式样本。后两条在已有完整证据上检查哈希/冻结身份后跳过，不覆盖原档、不算新的正式运行。

重新独立核验任意一个原档：

```bash
python - <<'PY'
import json,lzma
from pathlib import Path
from supplements.R41_assay_9b24983a.audit import verify
p=Path('supplements/R41_assay_9b24983a/results/D/86182.json.xz')
print(verify(json.loads(lzma.decompress(p.read_bytes()))))
PY
```

要重新生成整批正式数据，请另复制一个干净工作副本，并把其中results目录改名保留，使用空results输出。不要清空、覆盖本包原档。analyze.py和supplement/recheck.py默认也拒绝覆盖已有汇总/重放回执；需要新副本而非删掉原证据。

## 文件语义

- core.py / acquisition.py：冻结的实际Queen因果过程与独立的部分取证问题。
- audit.py：不导入前述学习器的只读解释器/原始证据核验。
- run.py / analyze.py：冻结的离线执行与按origin统计。
- results/C、results/D：256个origin，.json.xz / .json.receipt.json / .json.audit.json。
- results/acquisition：64个族内fixed/active档与2个域外控制。
- results/SUMMARY.json：主结果、完整案例与辅助结果；ORIGIN_SCORES.json：逐origin摘要。
- logs：冻结前开发失败、普通/-O测试、前台时限恢复、正常Git访问失败记录。
- supplement：正式后解释性重放与第三路径核对；不得反馈正式选择。
- reference/R37/R：12份原样执行依赖及原冻结清单，不是整个R37仓库镜像。
- FILE_MANIFEST.json：本包成员SHA-256与Git blob，清单本身由外层ZIP摘要绑定。

当前R41是本地交付。没有把只读连接器、DNS失败或准备好脚本误写成已上传。上传时只允许JackJ-C/Library的R分支R/内，禁止覆盖旧R37、R39冻结文件。
