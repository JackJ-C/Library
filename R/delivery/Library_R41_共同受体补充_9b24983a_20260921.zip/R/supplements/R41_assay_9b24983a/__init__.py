"""R41 independent continuation, separate from immutable R38-R40 reports."""
