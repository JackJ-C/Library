"""Separate, researcher-prior partial identification. Not an RSI intervention."""
from __future__ import annotations
from collections import Counter
from itertools import product
from .core import base, canon, identity
from r32_r37 import experiment as inherited
from r32_r37.closure import measure_cell, STATES, ACTIONS

class ExceptionalPort:
    """Evaluator fixture: one unqueried command=2 transition breaks the family."""
    def __init__(self,p,w):self.p=p;self.w=w
    def sense(self):return self.p.sense()
    def place(self,positions):return self.p.place(positions)
    def calibrate(self,a):return self.p.calibrate(a)
    def move(self,obj,a,mode='task'):
        special=tuple(self.w.positions)+(self.w.last,obj,a)==(0,0,0,0,2)
        result=self.p.move(obj,a,mode)
        if special:
            self.w.positions[0]=(self.w.positions[0]+1)%7
            result=self.p.sense()
        return result

def family_vectors(normals):
    vals=[g for g in range(1,7) if g not in normals];profiles=set()
    for a,b in product(vals,repeat=2):
        if a==b:continue
        for kind in ('less','equal'):
            for threshold in range(1,6):
                profiles.add(tuple(b if (h<threshold if kind=='less' else h==threshold) else a for h in range(7)))
    return profiles

def learn(q,port,mode):
    rows=[];steps=[]
    def observe(state,obj):
        row=measure_cell(q,port,state,(obj,1));rows.append(row)
        return row['output'][obj]
    values=[observe((r,0,0),0) for r in range(7)]
    counts=Counter(values);ordinary,count=counts.most_common(1)[0]
    if count!=6:raise ValueError('outside declared distinct-gain prior')
    special=next(r for r,v in enumerate(values) if v!=ordinary)
    r=next(r for r in range(7) if r!=(-special)%7)
    normal1=observe((r,0,0),1);normals=(ordinary,normal1)
    if len(set(normals))!=2:raise ValueError('non-distinct ordinary effects')
    version_space={v for v in family_vectors(normals) if v[0]==values[special]}
    observed={0:values[special]};computations=0
    while len(version_space)>1:
        remaining=[h for h in range(7) if h not in observed]
        if not remaining:raise RuntimeError('full history did not identify finite profile')
        if mode=='fixed':h=remaining[0]
        elif mode=='active':
            scored=[]
            for h in remaining:
                c=Counter(v[h] for v in version_space);computations+=len(version_space)
                scored.append((sum(n*n for n in c.values()),h))
            h=min(scored)[1]
        else:raise ValueError('mode')
        before=len(version_space);v=observe((special,0,h),0);observed[h]=v
        computations+=len(version_space)
        version_space={p for p in version_space if p[h]==v}
        steps.append({'history':h,'observed':v,'before':before,'after':len(version_space)})
        if not version_space:raise ValueError('observations refute declared family')
    if not version_space:raise ValueError('empty family')
    model={'special_relative':special,'normals':list(normals),'history_profile':list(next(iter(version_space)))}
    return {'mode':mode,'model':model,'rows':rows,'steps':steps,'learning_cells':len(rows),
            'posterior_operations':computations,'ledger':q.ledger.export(),
            'learned_offsets':list(q.offsets),'assumption':'fixed researcher-supplied R37 distinct-nonzero-gain family'}

def predict(model,state,action):
    p0,p1,h=state;obj,a=action;positions=(p0,p1)
    gain=model['history_profile'][h] if (positions[obj]-positions[1-obj])%7==model['special_relative'] else model['normals'][obj]
    output=[0,0];output[obj]=gain*a%7;return output

def experiment(seed,mode,negative=False):
    q,w,p=inherited.fixture(seed)
    if negative:p=ExceptionalPort(p,w)
    start=dict(w.cost);learned=learn(q,p,mode);learn_cost={k:w.cost[k]-start.get(k,0) for k in w.cost}
    # Hold learner and its identified profile fixed. Audit has its own fixture and costs.
    _,aw,ap=inherited.fixture(seed)
    if negative:ap=ExceptionalPort(ap,aw)
    audit=[];failed=[]
    for i,s in enumerate(STATES):
        for j,a in enumerate(ACTIONS):
            ap.move(0,s[2],'audit_primer');ap.place(list(s[:2]));before=ap.sense()
            after=ap.move(a[0],a[1],'audit_target')
            decoded=[[(x-aw.bias[k])%7 for x in row] for k,row in enumerate(after['workers'])]
            effect=[(decoded[0][k]-s[k])%7 for k in (0,1)]
            if effect!=predict(learned['model'],s,a):failed.append([i,j])
            audit.append([i,j,before['workers'],after['workers']]);aw.events.clear()
    return {'stage':'R41_acquisition','seed':seed,'method':mode,'negative_control':negative,
            'learning':learned,'learning_cost':learn_cost,'audit_cells':audit,
            'audit_offsets':list(aw.bias),'audit_failures':failed,'audit_correct':4802-len(failed),
            'audit_cost':dict(aw.cost),'audit_digest':identity(audit),
            'hidden_parameters_evaluator_only':list(w.parameters)}
