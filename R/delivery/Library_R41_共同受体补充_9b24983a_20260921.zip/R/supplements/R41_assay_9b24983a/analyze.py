"""Frozen origin-level descriptive analysis. Shared assays are never independent samples."""
from __future__ import annotations
from collections import Counter
from hashlib import sha256
from math import sqrt,log
from random import Random
from statistics import mean
from pathlib import Path
import json,lzma
from .core import HERE, BATCHES, canon
from .run import existing, check_frozen

def bootstrap(values,seed):
    r=Random(seed);n=len(values)
    means=sorted(sum(r.choices(values,k=n))/n for _ in range(5000))
    return [means[125],means[4875]]

def describe(values,seed):
    return {'n_origins':len(values),'mean':mean(values),'bootstrap_descriptive_95':bootstrap(values,seed),
            'positive':sum(v>1e-12 for v in values),'negative':sum(v< -1e-12 for v in values),
            'zero':sum(abs(v)<=1e-12 for v in values)}

def add_cost(out,c):
    for k,v in c.items():out[k]+=v

def main():
    fid=check_frozen();result={'stage':'R41','freeze_sha256':fid,'batches':{},'cases_post_hoc':[],
                            'not_original_R39_reproduction':True}
    records=[];all_acq=[];diagnostic=Counter();continuation_cost={a:Counter() for a in ('with','without')}
    for bi,batch in enumerate(('C','D')):
        ds=[]
        for seed in BATCHES[batch]:
            p=HERE/'results'/batch/f'{seed}.json.xz'
            if not existing(p):raise RuntimeError('missing formal origin '+str(seed))
            d=json.loads(lzma.decompress(p.read_bytes()));ds.append(d)
            records.append({'batch':batch,'origin':seed,**d['summary']})
            if d['root'] is None:continue
            s=d['summary']
            if any(abs(s[k])>1e-12 for k in ('delta0','delta3','selector_delta3')):
                case={'origin':seed,'batch':batch,'summary':s,
                      'root_parent':d['root']['parent'],'root_child':d['root']['child']}
                for arm in ('with','without'):
                    case[arm]=[{'generation':r['generation'],'accepted':r['check']['accepted'],
                                'parent':r['parent'],'child':r['child'],
                                'I_full':d['assays'][d['aliases'][f'{arm}_{r["generation"]}:full']]['estimated_I']}
                               for r in d['branches'][arm]['rounds']]
                result['cases_post_hoc'].append(case)
            for arm in ('with','without'):
                add_cost(continuation_cost[arm],s[arm+'_future_actual'])
                for row in d['branches'][arm]['rounds']:
                    for what in ('proposal_cost','adoption_cost'):
                        add_cost(continuation_cost[arm],{'model_'+k:v for k,v in row[what].items()})
                    add_cost(continuation_cost[arm],{'deployment_'+k:v for k,v in row['applied']['model_cost'].items()})
            for assay in d['assays'].values():
                if assay['mode']!='full':continue
                diagnostic['unique_full_donors_within_origin']+=1
                for sl in assay['slates']:
                    diagnostic['full_slates_clustered']+=1
                    risks=sl['oracle_all_risks_post_decision'];best=min(risks);base=risks[0]
                    diagnostic['pools_with_audit_better_candidate']+=best<base-1e-12
                    diagnostic['pools_without_audit_better_candidate']+=not best<base-1e-12
                    shortlist=[0]+sl['selection']['shortlist']
                    diagnostic['shortlist_misses_best_audit_risk']+=min(risks[i] for i in shortlist)>best+1e-12
                    pi=next(i for i,b in enumerate(sl['pool']) if b['key']==sl['candidate']['key'])
                    accepted=sl['check']['accepted'];gain=sl['gain']
                    diagnostic['accepted_products']+=accepted
                    diagnostic['accepted_audit_better']+=accepted and gain>1e-12
                    diagnostic['accepted_audit_worse']+=accepted and gain< -1e-12
                    diagnostic['accepted_audit_equal']+=accepted and abs(gain)<=1e-12
                    diagnostic['rejected_candidate_audit_better']+=not accepted and risks[pi]<base-1e-12
        summaries=[d['summary'] for d in ds];b={}
        for k in ('delta3','delta0','additional_effect','selector_delta3'):
            b[k]=describe([s[k] for s in summaries],902000+bi*100+len(k))
        b.update(origins=len(ds),roots=sum(s['has_root'] for s in summaries),
                 with_updates=sum(s['with_updates'] for s in summaries),
                 without_updates=sum(s['without_updates'] for s in summaries),
                 chain_screens=sum(s['chain_screen'] for s in summaries))
        conditional=[s['delta3'] for s in summaries if s['has_root']]
        b['conditional_root_mean_delta3']=mean(conditional) if conditional else None
        b['descriptive_repeat_gate']=(b['delta3']['mean']>.002 and b['delta3']['bootstrap_descriptive_95'][0]>0)
        b['hoeffding_two_batches_family_error_05_radius']=sqrt(2*log(80)/len(ds))
        b['hoeffding_assumptions']='Ideal independent origin innovations; PRNG finite fixed seed set is not natural-world random sampling.'
        result['batches'][batch]=b
    for p in sorted((HERE/'results'/'acquisition').glob('*.json.xz')):
        if not existing(p):raise RuntimeError('incomplete acquisition evidence')
        d=json.loads(lzma.decompress(p.read_bytes()));a=json.loads(p.with_suffix('.audit.json').read_text())
        all_acq.append({'seed':d['seed'],'method':d['method'],'negative':d['negative_control'],
                        'cells':a['learning_cells'],'posterior_operations':a['posterior_operations'],
                        'audit_correct':a['audit_correct'],'learning_cost':d['learning_cost'],
                        'audit_cost':d['audit_cost']})
    if len(all_acq)!=66:raise RuntimeError('expected 64 acquisition and two negative control archives')
    normal=[r for r in all_acq if not r['negative']];fixed={r['seed']:r for r in normal if r['method']=='fixed'}
    active={r['seed']:r for r in normal if r['method']=='active'}
    diffs=[fixed[s]['cells']-active[s]['cells'] for s in sorted(fixed)]
    result['acquisition']={'worlds':32,'paired_records':64,'negative_records':2,
           'fixed_mean_cells':mean(r['cells'] for r in fixed.values()),
           'active_mean_cells':mean(r['cells'] for r in active.values()),
           'mean_cells_saved':mean(diffs),'active_cheaper':sum(x>0 for x in diffs),
           'active_more_expensive':sum(x<0 for x in diffs),'equal':sum(x==0 for x in diffs),
           'fixed_posterior_ops':sum(r['posterior_operations'] for r in fixed.values()),
           'active_posterior_ops':sum(r['posterior_operations'] for r in active.values()),
           'family_audit_correct':sum(r['audit_correct'] for r in normal),'family_audit_total':64*4802,
           'negative_controls':[r for r in all_acq if r['negative']], 'all_rows':all_acq}
    result['pooled_diagnostics_not_independent_samples']=dict(diagnostic)
    result['continuation_costs']= {k:dict(v) for k,v in continuation_cost.items()}
    result['repeat_gate_passed']=all(v['descriptive_repeat_gate'] for v in result['batches'].values())
    result['total_archives']=len(records)+len(all_acq)
    dest=HERE/'results'/'SUMMARY.json'
    with dest.open('x') as f:f.write(canon(result)+'\n')
    with (HERE/'results'/'ORIGIN_SCORES.json').open('x') as f:f.write(canon(records)+'\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ('cases_post_hoc','acquisition')},indent=2))

if __name__=='__main__':main()
