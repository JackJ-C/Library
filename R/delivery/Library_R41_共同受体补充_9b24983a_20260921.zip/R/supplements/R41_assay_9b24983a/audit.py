"""Read-only R41 verifier. Does NOT import R41 core, Queen, or R37 learner.
Independent DSL, task generator, candidate generator, diagnostic execution,
allocation race, measured response geometry, selection, and adoption replay.
Shared primitives are CPython Random/float/math/JSON only; not an independent team.
"""
from __future__ import annotations
from hashlib import sha256
from random import Random
from math import sqrt
from statistics import mean
from fractions import Fraction
import json

AV=('mean','uncert','visits','gap'); TV=('info','price','spread','order')
A0={'ast':['-','mean','uncert'],'scale':1.0}

def canon(v):return json.dumps(v,sort_keys=True,separators=(',',':'),ensure_ascii=False,allow_nan=False)
def key(v):return sha256(canon(v).encode()).hexdigest()
def freeze(v):
    if isinstance(v,dict):return tuple((k,freeze(v[k])) for k in sorted(v))
    return tuple(freeze(z) for z in v) if isinstance(v,(tuple,list)) else v
def demand(ok,why):
    if not ok:raise ValueError(why)
def eq(a,b,why):demand(freeze(a)==freeze(b),why)
def close(a,b,why):demand(abs(a-b)<1e-11,why)
def addr(origin,*parts):return int(sha256(canon(['R41_v1',origin,*parts]).encode()).hexdigest()[:15],16)
def size(t):return 1 if isinstance(t,(int,str)) else 1+size(t[1])+size(t[2])
def text(t):return str(t) if isinstance(t,(int,str)) else '('+text(t[1])+t[0]+text(t[2])+')'
def bk(b):return key([b['ast'],b['scale']])
A0['key']=bk(A0)

def task_eval(t,x):
    if type(t)is int:return t*256
    if isinstance(t,str):return x[TV.index(t)]
    a=task_eval(t[1],x);b=task_eval(t[2],x)
    v={'+':lambda:a+b,'-':lambda:a-b,'*':lambda:a*b//256,'/':lambda:a*256//(abs(b)+1)}[t[0]]()
    return min(10**9,max(-10**9,v))
def alloc_eval(t,x):
    if type(t)is int:return float(t)
    if isinstance(t,str):return x[AV.index(t)]
    a=alloc_eval(t[1],x);b=alloc_eval(t[2],x)
    v={'+':lambda:a+b,'-':lambda:a-b,'*':lambda:a*b,'/':lambda:a/(abs(b)+.001)}[t[0]]()
    return min(1e6,max(-1e6,v))

def diagnostic(p,h,ast):
    mask=(1<<p['count'])-1;available=list(range(len(p['masks'])));rows=[];paid=0
    while mask.bit_count()>1 and available:
        scored=[]
        for q in available:
            amounts=[(m&mask).bit_count() for m in p['masks'][q]];n=mask.bit_count()
            f=((n*n-sum(v*v for v in amounts))*1024//(n*n),p['prices'][q]*128,
               sum(v>0 for v in amounts)*128,q*16)
            if f[0]>0:scored.append((task_eval(ast,f),-q,q,f))
        if not scored:break
        _,_,q,f=max(scored)
        v=next(j for j,m in enumerate(p['masks'][q]) if m&(1<<h))
        old=mask;mask&=p['masks'][q][v];available.remove(q);paid+=p['prices'][q]
        rows.append({'query':q,'value':v,'before':old,'after':mask,'features':f,'price':p['prices'][q]})
    return paid if mask.bit_count()==1 else paid+1000,mask,rows

def make_problem(seed):
    rng=Random(seed);n=16;masks=[];prices=[]
    for _ in range(12):
        k=rng.choice((2,2,3,4,5));weights=[rng.expovariate(1) for _ in range(k)]
        labels=rng.choices(range(k),weights=weights,k=n)
        masks.append(tuple(sum(1<<i for i,label in enumerate(labels) if label==j) for j in range(k)))
        prices.append(rng.randrange(1,10))
    for bit in range(4):
        masks.append(tuple(sum(1<<i for i in range(n) if ((i>>bit)&1)==v) for v in (0,1)))
        prices.append(rng.randrange(3,10))
    return {'problem':{'masks':masks,'prices':prices,'count':16},'inferred':rng.randrange(16)}
def make_block(seed):
    r=Random(seed)
    return [make_problem(r.randrange(1<<50)) for _ in range(6)]

def alloc_candidates(parent,seed,count):
    r=Random(seed);out=[freeze(parent)];seen={text(parent)}
    def draw(d):
        if d==0 or r.random()<.4:return r.choice(AV+(0,1,2,-1))
        return (r.choice(('+','-','*','/')),draw(d-1),draw(d-1))
    def change(t):
        if isinstance(t,(int,str)) or r.random()<.3:return draw(2)
        j=r.choice((1,2));z=list(t);z[j]=change(t[j]);return tuple(z)
    for _ in range(1000):
        x=change(parent) if r.random()<.6 else draw(2)
        if size(x)>15 or text(x) in seen:continue
        seen.add(text(x));out.append(x)
        if len(out)==count:return out
    raise ValueError('independent candidate supply exhausted')
def self_pool(parent,seed):
    asts=alloc_candidates(parent['ast'],seed,8);r=Random(seed^731)
    return [parent]+[dict(ast=a,scale=(s:=r.choice((.5,1.,2.))),key=key([a,s])) for a in asts[1:]]
def product_pool(donor,seed,mode):
    generator=donor if mode=='full' else A0
    asts=alloc_candidates(generator['ast'],seed,16);r=Random(seed^731)
    out=[A0];seen={A0['key']};emitted=[]
    for a in asts[1:]:
        s=r.choice((.5,1.,2.));b=dict(ast=a,scale=s,key=key([a,s]));emitted.append(b)
        if b['key'] in seen or (mode=='full' and b['key']==donor['key']):continue
        seen.add(b['key']);out.append(b)
        if len(out)==8:return out,emitted
    raise ValueError('independent assay supply exhausted')
def tasks(parent,seed):
    r=Random(seed)
    def draw(d):
        if d==0 or r.random()<.35:return r.choice((0,1,2,-1)+TV)
        return (r.choice(('+','-','*','/')),draw(d-1),draw(d-1))
    def change(t):
        if isinstance(t,(int,str)) or r.random()<.3:return draw(2)
        j=r.randrange(2)+1;v=list(t);v[j]=change(v[j]);return tuple(v)
    out=[];seen={text(parent)}
    for _ in range(100):
        a=change(parent) if r.random()<.55 else draw(3)
        if size(a)>15 or text(a) in seen:continue
        seen.add(text(a));out.append(a)
        if len(out)==5:break
    demand(len(out)==5,'task supply')
    return [parent]+out

class Engine:
    def __init__(self,tasks,blocks):self.tasks=tasks;self.blocks=blocks;self.cases={};self.responses={}
    def case(self,a,j,i):
        k=(a,j,i)
        if k not in self.cases:
            x=self.blocks[j][i];p=x['problem'];cost,h,tr=diagnostic(p,x['inferred'],self.tasks[a])
            self.cases[k]=(cost/(9*len(p['masks'])) if h.bit_count()==1 else 1.,
                           tuple((t['query'],t['value'],t['price']) for t in tr))
        return self.cases[k]
    def run(self,b,j):
        k=(bk(b),j)
        if k in self.responses:return self.responses[k]
        values=[[] for _ in self.tasks];tr=[]
        for turn in range(12):
            if turn<len(self.tasks):chosen=turn
            else:
                av=[sum(z)/len(z) for z in values];lo=min(av);scores=[]
                for z,m in zip(values,av):
                    variance=sum((v-m)**2 for v in z)/max(1,len(z)-1)
                    u=b['scale']*sqrt((variance+.01)/len(z))
                    scores.append(alloc_eval(b['ast'],(m,u,len(z)/12,m-lo)))
                chosen=min(range(len(self.tasks)),key=lambda i:(scores[i],i))
            i=len(values[chosen]);loss=self.case(chosen,j,i%4)[0]
            values[chosen].append(loss);tr.append((chosen,i,loss))
        av=[sum(z)/len(z) for z in values]
        chosen=min(range(len(self.tasks)),key=lambda i:(av[i],size(self.tasks[i]),text(self.tasks[i])))
        checks=[self.case(chosen,j,i) for i in (4,5)]
        response={'loss':mean(c[0] for c in checks),'signature':tuple(c[1] for c in checks),
                  'task':chosen,'requests':tuple(tr)}
        self.responses[k]=response;return response

def response_signature(r):return freeze([r['loss'],r['signature'],r['task'],r['requests']])
def geometry(pool,eng):
    columns=[[eng.run(b,j) for b in pool] for j in range(3)]
    index={};rows=[tuple(response_signature(col[i]) for col in columns) for i in range(8)]
    groups=[index.setdefault(row,len(index)) for row in rows]
    ds=[]
    for i in range(8):
        row=[]
        for k in range(8):
            pieces=[]
            for col in columns:
                a,b=col[i],col[k]
                pieces.append(max(abs(Fraction(str(a['loss']))-Fraction(str(b['loss']))),
                    *[Fraction(1,4)*(freeze(a[f])!=freeze(b[f])) for f in ('signature','task','requests')]))
            row.append(float(sum(pieces,Fraction())/3))
        ds.append(row)
    return groups,ds

def select(pool,donor,eng):
    groups,dist=geometry(pool,eng);chosen=[];classes=set();rank=[]
    losses=[[eng.run(b,j)['loss'] for j in range(3)] for b in pool]
    av=[mean(row) for row in losses];dev=list(range(3,len(eng.blocks)))
    for _ in range(2):
        eligible=[i for i in range(1,8) if i not in chosen]
        novel=[i for i in eligible if groups[i] not in classes]
        if novel:eligible=novel
        priorities=[]
        for i in eligible:
            variance=mean((v-av[i])**2 for v in losses[i]);novelty=min(dist[i][j] for j in [0]+chosen)
            u=sqrt((variance+.0001)/3)+.025*novelty
            f=(av[i],donor['scale']*u,3/(3+len(dev)),av[i]-min(av))
            priorities.append((alloc_eval(donor['ast'],f),size(pool[i]['ast']),pool[i]['key'],i,f))
        winner=min(priorities);chosen.append(winner[3]);classes.add(groups[winner[3]])
        rank.append({'eligible':eligible,'chosen':winner[3],
                     'priorities':[[p[3],p[0],p[4]] for p in priorities]})
    scores=[(mean(eng.run(pool[i],j)['loss'] for j in dev),0 if i==0 else 1,
             size(pool[i]['ast']),pool[i]['key'],i) for i in [0]+chosen]
    proposed=min(scores)[-1]
    selection={'mode':'space','proposer':donor,'pilot_means':av,'shortlist':chosen,
               'proposal':proposed,'scores':[[x[-1],x[0]] for x in scores],
               'ranking':rank,'logical_full_checks':len(chosen)*len(dev)}
    return proposed,selection,groups,dist

def adopted(parent,candidate,eng):
    old=[eng.run(parent,j)['loss'] for j in range(4)]
    new=[eng.run(candidate,j)['loss'] for j in range(4)]
    ok=bk(candidate)!=bk(parent) and mean(old)-mean(new)>.002
    return candidate if ok else parent,ok,old,new

def ledger_parse(records):
    bodies=[]
    for i,r in enumerate(records):
        demand(r['seq']==i,'noncontiguous ledger')
        for tag in ('deps','refs'):
            demand(len(set(r[tag]))==len(r[tag]),'duplicate ledger link')
            demand(all(type(x)is int and 0<=x<i for x in r[tag]),'nonhistorical ledger edge')
        bodies.append(json.loads(r['body']))
    return bodies

def read_block(records,bodies,ref,expected_seed=None,program=None):
    demand(records[ref]['kind']=='R30_observed_block','wrong observation block')
    out=[]
    for row in bodies[ref]['cases']:
        p=row['problem'];h=row['inferred'];intent=bodies[row['intention']];receipt=bodies[row['receipt']]
        eq(intent['problem'],p,'problem receipt mismatch')
        if program is not None:eq(intent['program'],program,'unexpected acquisition program')
        demand(receipt['intention']==row['intention'],'unpaired causal observation')
        demand(receipt['inferred_mechanism']==h,'mechanism index mismatch')
        cost,H,tr=diagnostic(p,h,intent['program'])
        demand(H==(1<<h),'unidentified mechanism')
        eq(tr,receipt['transcript'],'actual diagnostic response replay')
        demand(cost==receipt['price']==row['price'] if 'price' in row else cost==receipt['price'],
               'actual diagnostic price')
        out.append({'problem':p,'inferred':h})
    if expected_seed is not None:eq(out,make_block(expected_seed),'incorrect external problem substream')
    return out

def numeric_equal(a,b,why):
    if isinstance(a,dict) and isinstance(b,dict):
        demand(set(a)==set(b),why+' keys')
        for k in a:numeric_equal(a[k],b[k],why+'.'+str(k))
    elif isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)):
        demand(len(a)==len(b),why+' length')
        for i,(x,y) in enumerate(zip(a,b)):numeric_equal(x,y,why+f'[{i}]')
    elif isinstance(a,(float,int)) and not isinstance(a,bool) and isinstance(b,(float,int)) and not isinstance(b,bool):
        close(a,b,why)
    else:demand(a==b,why)

def check_round(r,records,bodies,origin,phase,generation,parent,program,history_refs):
    eq(r['parent'],parent,'wrong preceding mechanism');eq(r['start_program'],program,'wrong preceding task')
    demand(r['phase']==phase and r['generation']==generation,'phase identity')
    ns=addr(origin,phase,generation,'new_history');demand(r['new_history_seed']==ns,'new history seed')
    read_block(records,bodies,r['new_history_ref'],ns,program)
    expected_refs=(history_refs+[r['new_history_ref']])[-6:]
    eq(r['history_refs'],expected_refs,'persistent history scope')
    hist=[read_block(records,bodies,ref) for ref in expected_refs]
    eq(hist,r['history_blocks'],'substituted prior evidence')
    ts=addr(origin,phase,generation,'tasks');ps=addr(origin,phase,generation,'mechanisms')
    demand((ts,ps)==(r['task_seed'],r['pool_seed']),'candidate/task exogenous seed')
    tt=tasks(program,ts);eq(tt,r['tasks'],'task regeneration')
    pool=self_pool(parent,ps);eq(pool,r['pool'],'candidate regeneration')
    for b in pool:demand(b['key']==bk(b),'bundle identity')
    eng=Engine(tt,hist);i,sel,groups,distance=select(pool,parent,eng)
    numeric_equal(sel,r['selection'],'proposal replay')
    eq(pool[i],r['proposed'],'proposed program')
    eq(groups,r['space']['groups'],'geometry equivalence classes')
    for j in range(8):
        for k in range(8):close(float(Fraction(r['space']['distance_rationals'][j][k])),distance[j][k],'geometry metric')
    asources=[addr(origin,phase,generation,'adoption',j) for j in range(4)]
    eq(asources,r['adoption_seeds'],'adoption exogenous seeds')
    ab=[read_block(records,bodies,ref,s,program) for ref,s in zip(r['adoption_refs'],asources)]
    eq(ab,r['adoption_blocks'],'adoption evidence')
    ae=Engine(tt,ab);child,ok,old,new=adopted(parent,pool[i],ae)
    eq(child,r['child'],'adopted mechanism');demand(ok==r['check']['accepted'],'adoption Boolean')
    numeric_equal(old,r['check']['old'],'adoption incumbent risks');numeric_equal(new,r['check']['new'],'candidate risks')
    demand(r['proposal_record']<min(r['adoption_refs']),'proposal not frozen before adoption evidence')
    eq(bodies[r['proposal_record']]['proposed'],pool[i],'ledger proposal differs')
    eq(bodies[r['decision_record']]['child'],child,'ledger decision differs')
    return child,ae,expected_refs

def check_applied(applied,chosen,step,engine,records,bodies):
    eq(applied['mechanism'],chosen,'installed mechanism')
    j=engine.run(chosen,0)['task']
    demand(j==applied['task_index'],'installed task index')
    eq(step['tasks'][j],applied['task_program'],'installed task program')
    demand(applied['same_queen_and_ledger'] is True,'runner failed object continuity')
    eq(bodies[applied['event']]['actually_installed'],chosen,'runtime installation event')
    return step['tasks'][j]

def check_assay(a,origin):
    donor=a['donor'];mode=a['mode'];gains=[]
    demand(mode in ('full','selector') and donor['key']==bk(donor),'assay donor identity')
    for k,s in enumerate(a['slates']):
        phase='assay:'+str(k);demand(s['slate']==k,'slate identity')
        eq(s['receiver'],A0,'common recipient');eq(s['donor'],donor,'assay donor changed')
        bodies=ledger_parse(s['ledger']);records=s['ledger']
        refs=[]
        for j,source in enumerate(s['source']):
            demand(source['seed']==addr(origin,phase,'history',j),'assay history seed')
            read_block(records,bodies,source['ref'],source['seed'],0);refs.append(source['ref'])
        eq(refs,s['history_refs'],'assay history references')
        histories=[read_block(records,bodies,ref) for ref in refs]
        eq(histories,s['history_blocks'],'assay history values')
        ts=addr(origin,phase,'tasks');demand(ts==s['task_seed'],'assay task seed')
        tt=tasks(0,ts);eq(tt,s['tasks'],'assay task regeneration')
        ps=addr(origin,phase,'candidates');demand(ps==s['generation']['seed'],'assay candidate seed')
        pool,emitted=product_pool(donor,ps,mode);eq(pool,s['pool'],'assay candidate generation')
        eq(emitted,s['generation']['inspected_mutants'],'mutant origin')
        demand(s['generation']['generated_ast_slots']==16,'generation budget')
        eng=Engine(tt,histories);i,sel,_,_=select(pool,donor,eng)
        numeric_equal(sel,s['selection'],'assay selection');eq(pool[i],s['candidate'],'assay proposed')
        asources=[addr(origin,phase,'adoption',j) for j in range(4)]
        eq(asources,s['adoption_seeds'],'assay adoption seeds')
        ab=[read_block(records,bodies,ref,z,0) for ref,z in zip(s['adoption_refs'],asources)]
        eq(ab,s['adoption_blocks'],'assay adoption evidence')
        ae=Engine(tt,ab);child,ok,old,new=adopted(A0,pool[i],ae)
        eq(child,s['product'],'assay adopted product');demand(ok==s['check']['accepted'],'assay adoption status')
        numeric_equal(old,s['check']['old'],'assay original risk');numeric_equal(new,s['check']['new'],'assay new risk')
        demand(s['proposal_record']<min(s['adoption_refs']),'assay proposal timing')
        eq(bodies[s['decision_record']]['product'],child,'assay deployment ledger')
        audit_seeds=[addr(origin,phase,'audit',j) for j in range(8)]
        eq(audit_seeds,s['audit_seeds'],'audit exogenous schedule')
        blocks=[make_block(z) for z in audit_seeds];eq(blocks,s['audit_blocks'],'audit block generation')
        ev=Engine(tt,blocks)
        left=[ev.run(A0,j)['loss'] for j in range(8)];right=[ev.run(child,j)['loss'] for j in range(8)]
        numeric_equal(left,s['baseline_risks'],'assay common baseline')
        numeric_equal(right,s['product_risks'],'assay product performance')
        all_risks=[mean(ev.run(b,j)['loss'] for j in range(8)) for b in pool]
        numeric_equal(all_risks,s['oracle_all_risks_post_decision'],'post hoc all-pool audit')
        gain=mean(left)-mean(right);close(gain,s['gain'],'assay product gain');gains.append(gain)
    demand(len(gains)==2,'slate sample count');close(mean(gains),a['estimated_I'],'finite I estimate')
    return mean(gains)

def semantic(f):
    return key([{'parent':r['parent'],'pool':r['pool'],'tasks':r['tasks'],
                  'history':r['history_blocks'],'adoption':r['adoption_blocks'],
                  'selection':r['selection'],'child':r['child'],'task':r['applied']['task_program']}
                 for r in f['rounds']])

def verify(data):
    origin=data['origin'];demand(data['protocol']=='R41_v1','wrong protocol')
    records=data['pre_root_ledger'];bodies=ledger_parse(records)
    history=[];parent=A0;program=0
    for j,s in enumerate(data['warmup']):
        demand(s['seed']==addr(origin,'discovery','warmup',j),'warmup seed')
        read_block(records,bodies,s['ref'],s['seed'],0);history.append(s['ref'])
    demand(len(history)==3,'warmup scope')
    roots=[]
    for g,r in enumerate(data['natural']):
        child,ae,hrefs=check_round(r,records,bodies,origin,'discovery',g,parent,program,history)
        if r['check']['accepted']:
            roots.append(g);demand(g==len(data['natural'])-1,'did not select first accepted root');break
        program=check_applied(r['applied'],child,r,ae,records,bodies)
        parent=child;history=(hrefs+r['adoption_refs'])[-6:]
    if not roots:
        demand(data['root'] is None and len(data['natural'])==6,'missing or selected-away natural root')
        for f in ('delta0','delta3','additional_effect','selector_delta3'):close(data['summary'][f],0,'no-root weighting')
        demand(data['summary']['has_root'] is False,'no-root indicator')
        return {'pass':True,'origin':origin,'has_root':False,'verified_rounds':6,'verified_assays':0}
    root=data['natural'][-1];eq(root,data['root'],'root snapshot identity')
    demand(data['summary']['has_root'] is True,'root indicator')
    expected={'with':True,'without':False,'restored':True,'annotation_only':True}
    total_rounds=len(data['natural'])
    for label,retain in expected.items():
        f=data['branches'][label];lr=f['ledger'];lb=ledger_parse(lr);ins=f['installation']
        eq(lr[:len(records)],records,'counterfactual prefix not exact')
        demand(ins['prefix_sha256']==key(records) and ins['prefix_records']==len(records),'prefix hash')
        demand(ins['retain']==retain and ins['annotation']==(label=='annotation_only') and
               ins['restore']==(label=='restored'),'intervention definition')
        installed=root['child'] if retain else root['parent']
        engine=Engine(root['tasks'],root['adoption_blocks'])
        p=check_applied(ins['applied'],installed,root,engine,lr,lb)
        h=(root['history_refs']+root['adoption_refs'])[-6:];m=installed
        demand(len(f['rounds'])==3,'future horizon')
        for g,r in enumerate(f['rounds']):
            child,ae,hrefs=check_round(r,lr,lb,origin,'continuation',g,m,p,h)
            p=check_applied(r['applied'],child,r,ae,lr,lb);m=child
            h=(hrefs+r['adoption_refs'])[-6:];total_rounds+=1
        eq(m,f['endpoint'],'future endpoint mechanism')
    demand(semantic(data['branches']['with'])==semantic(data['branches']['restored']),'restoration replay')
    demand(semantic(data['branches']['with'])==semantic(data['branches']['annotation_only']),'annotation no-op replay')
    values={k:check_assay(a,origin) for k,a in data['assays'].items()}
    for alias,k in data['aliases'].items():
        mode=alias.split(':')[-1]
        demand(k==mode+':'+data['assays'][k]['donor']['key'],'assay cache reference')
        label=alias.rsplit(':',1)[0]
        if label=='root_parent':expected_donor=root['parent']
        elif label=='root_child':expected_donor=root['child']
        else:
            b,g=label.rsplit('_',1)
            expected_donor=data['branches'][b]['endpoint'] if g=='end' else data['branches'][b]['rounds'][int(g)]['child']
        eq(data['assays'][k]['donor'],expected_donor,'assay lineage donor')
    get=lambda label,mode='full':values[data['aliases'][label+':'+mode]]
    d0=get('root_child')-get('root_parent');d3=get('with_end')-get('without_end')
    for tag,value in [('delta0',d0),('delta3',d3),('additional_effect',d3-d0),
       ('selector_delta3',get('with_end','selector')-get('without_end','selector'))]:
        close(value,data['summary'][tag],'summary '+tag)
    for label in ('with','without'):
        demand(data['summary'][label+'_updates']==sum(r['check']['accepted'] for r in data['branches'][label]['rounds']),
               'update count')
    previous=get('root_child');better=0
    for g,r in enumerate(data['branches']['with']['rounds']):
        current=get(f'with_{g}')
        better+=r['check']['accepted'] and current>previous+1e-12
        previous=current
    demand(better==data['summary']['with_I_improving_updates'],'intermediate ability changes')
    screen=bool(d0>1e-12 and d3>1e-12 and d3-d0>1e-12 and data['summary']['with_updates']>=2 and
                better>=2 and get('with_end')>1e-12)
    demand(screen==data['summary']['chain_screen'],'chain screening')
    return {'pass':True,'origin':origin,'has_root':True,'verified_rounds':total_rounds,
            'verified_assays':len(values),'delta0':d0,'delta3':d3,
            'restoration_control':True,'annotation_control':True}


def verify_acquisition(data):
    """Checks from independently decoded observations, not fixture parameter truth."""
    from itertools import product
    learning=data['learning'];mode=data['method'];offsets=learning['learned_offsets']
    records=learning['ledger'];bodies=ledger_parse(records);out=[]
    for row in learning['rows']:
        intent=bodies[row['intention']];receipt=bodies[row['observation']]
        demand(receipt['intention']==row['intention'],'partial evidence pairing')
        before=[[(x-offsets[j])%7 for x in v] for j,v in enumerate(intent['before']['workers'])]
        after=[[(x-offsets[j])%7 for x in v] for j,v in enumerate(receipt['after']['workers'])]
        eq(before[0],before[1],'partial sensors before');eq(after[0],after[1],'partial sensors after')
        eq(before[0],row['state'][:2],'partial reset state')
        demand(intent['last']==row['state'][2] and intent['issued']==1,'history/command reset')
        demand(intent['object']==row['action'][0] and row['action'][1]==1,'learning action vocabulary')
        effect=[(b-a)%7 for a,b in zip(before[0],after[0])];eq(effect,row['output'],'learning output')
        out.append(effect[row['action'][0]])
    demand(len(out)==learning['learning_cells']<=14,'partial acquisition cap')
    for i,r in enumerate(learning['rows'][:7]):eq(r['state'],[i,0,0],'initial relative position probe')
    from collections import Counter
    normal,count=Counter(out[:7]).most_common(1)[0];demand(count==6,'distinct gain prior')
    d=next(i for i,v in enumerate(out[:7]) if v!=normal)
    r=next(i for i in range(7) if i!=(-d)%7)
    eq(learning['rows'][7]['state'],[r,0,0],'other object ordinary probe')
    normals=[normal,out[7]];possible=set()
    vals=[v for v in range(1,7) if v not in normals]
    for a,b in product(vals,repeat=2):
        if a==b:continue
        for t in range(1,6):
            for equal in (False,True):
                profile=tuple(b if (h==t if equal else h<t) else a for h in range(7))
                if profile[0]==out[d]:possible.add(profile)
    seen={0};ops=0
    for row,step,v in zip(learning['rows'][8:],learning['steps'],out[8:]):
        remaining=[h for h in range(7) if h not in seen]
        if mode=='fixed':h=remaining[0]
        else:
            scored=[]
            for h in remaining:
                c=Counter(p[h] for p in possible);scored.append((sum(n*n for n in c.values()),h));ops+=len(possible)
            h=min(scored)[1]
        demand(step['before']==len(possible),'version space count')
        eq(row['state'],[d,0,h],'active query choice');demand(step['history']==h and step['observed']==v,'history sample')
        ops+=len(possible);possible={p for p in possible if p[h]==v};seen.add(h)
        demand(step['after']==len(possible),'posterior count')
    demand(len(possible)==1,'unsupported identification')
    model={'special_relative':d,'normals':normals,'history_profile':list(next(iter(possible)))}
    eq(model,learning['model'],'identified model');demand(ops==learning['posterior_operations'],'posterior operations')
    demand(len(data['audit_cells'])==4802 and key(data['audit_cells'])==data['audit_digest'],'full audit archive')
    states=list(product(range(7),repeat=3));actions=list(product(range(2),range(7)));failures=[]
    for k,row in enumerate(data['audit_cells']):
        i,j,before,after=row;demand((i,j)==divmod(k,14),'audit complete ordered coverage')
        decoded_before=[[(x-data['audit_offsets'][w])%7 for x in v] for w,v in enumerate(before)]
        decoded_after=[[(x-data['audit_offsets'][w])%7 for x in v] for w,v in enumerate(after)]
        eq(decoded_before[0],states[i][:2],'audit reset');eq(decoded_before[0],decoded_before[1],'audit before sensors')
        eq(decoded_after[0],decoded_after[1],'audit after sensors')
        p0,p1,h=states[i];obj,cmd=actions[j];positions=(p0,p1)
        gain=model['history_profile'][h] if (positions[obj]-positions[1-obj])%7==d else normals[obj]
        expected=[0,0];expected[obj]=gain*cmd%7
        observed=[(decoded_after[0][k]-positions[k])%7 for k in (0,1)]
        if expected!=observed:failures.append([i,j])
    eq(failures,data['audit_failures'],'partial model audit failures');demand(data['audit_correct']==4802-len(failures),'audit score')
    if data['negative_control']:eq(failures,[[0,2]],'one hidden unmeasured transition negative control')
    else:demand(not failures,'family identification failed')
    return {'pass':True,'seed':data['seed'],'method':mode,'negative_control':data['negative_control'],
            'learning_cells':len(out),'audit_correct':4802-len(failures),'posterior_operations':ops}
