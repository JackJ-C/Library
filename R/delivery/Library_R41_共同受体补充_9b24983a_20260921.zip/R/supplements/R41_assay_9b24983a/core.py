"""R41 independent reconstruction: controlled modification of a bounded allocator.
Not the lost R39 source. All experimental programs run offline. No credentials.
"""
from __future__ import annotations
from collections import Counter
from copy import deepcopy
from dataclasses import asdict
from hashlib import sha256
from pathlib import Path
from random import Random
from statistics import mean
import json
import sys

HERE = Path(__file__).resolve().parent
REFERENCE = HERE / 'reference' / 'R37' / 'R'
sys.path.insert(0, str(REFERENCE))
from r28_r31 import study as base
from r32_r37.space import MeasuredSpace
from r20_r23_recovery import racing

INITIAL = base.INITIAL
BATCHES = {'C': list(range(85100, 85228)), 'D': list(range(86100, 86228))}
DEV = [0, 1, 2, 3]
ROUNDS = 3
ROOT_LIMIT = 6
SLATES = 2
AUDIT_BLOCKS = 8

def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False)

def identity(x):
    return sha256(canon(x).encode()).hexdigest()

def innovation(origin, *role):
    # Arm/donor labels are deliberately absent. Independent semantic substreams.
    return int(sha256(canon(['R41_v1', origin, *role]).encode()).hexdigest()[:15], 16)

def bundle(x):
    return base.Bundle(x['ast'], x['scale'])

def blocks_json(blocks):
    return [[{'problem': base.serialize_problem(p), 'inferred': h} for p, h in block] for block in blocks]

def blocks_from_json(blocks):
    return [[(base.search.Problem(tuple(tuple(row) for row in x['problem']['masks']),
                                 tuple(x['problem']['prices']), x['problem']['count']), x['inferred'])
             for x in block] for block in blocks]

def diff(a, b):
    return {k: a.get(k, 0)-b.get(k, 0) for k in sorted(set(a)|set(b))}

def init_queen(origin, phase):
    seed = innovation(origin, phase, 'queen')
    q, _ = base.make_queen(seed)
    schedule = []
    for j in range(3):
        s = innovation(origin, phase, 'warmup', j)
        observed, ref = q.acquire(base.opaque_problems(s))
        q.remember(observed, ref)
        schedule.append({'seed': s, 'ref': ref})
    return q, schedule

def prepare_round(q, origin, phase, generation):
    before_actual = asdict(q.own_diagnostic_cost)
    parent = q.require_allocator()
    start_program = q.search_program.ast
    new_seed = innovation(origin, phase, generation, 'new_history')
    observed, ref = q.acquire(base.opaque_problems(new_seed))
    q.remember(observed, ref)
    task_seed = innovation(origin, phase, generation, 'tasks')
    pool_seed = innovation(origin, phase, generation, 'mechanisms')
    tasks = base.task_pool(start_program, task_seed)
    pool = base.candidate_pool(parent, pool_seed)
    if len(tasks) != 6 or len(pool) != 8:
        raise RuntimeError('fixed task/candidate size violated')
    eng = base.InterventionEngine(tasks, q.history)
    cols = [[eng.run(b, j) for b in pool] for j in range(3)]
    context = {'tasks': tasks, 'inner_budget': 12, 'train': 4, 'check': 2,
               'response': 'R37', 'cost_normalizer': '9*len(query_masks)'}
    space = MeasuredSpace(q, pool, cols, q.block_refs[:3], context)
    proposed, selection = base.choose_proposal(parent, parent, pool, space, eng, 'space')
    proposal = q.add('R41_frozen_proposal', {
        'parent': parent.json(), 'proposed': proposed.json(), 'tasks': tasks,
        'pool': [b.json() for b in pool], 'selection': selection,
        'space': space.public(), 'history_refs': list(q.block_refs)
    }, deps=(space.version,)+tuple(q.block_refs))
    saved_history = blocks_json(q.history)
    history_refs = list(q.block_refs)
    adopt_blocks, adopt_refs, adopt_seeds = [], [], []
    for j in range(4):
        s = innovation(origin, phase, generation, 'adoption', j)
        obs, r = q.acquire(base.opaque_problems(s))
        adopt_blocks.append(obs); adopt_refs.append(r); adopt_seeds.append(s)
    ae = base.InterventionEngine(tasks, adopt_blocks)
    child, check = base.adoption(parent, proposed, ae)
    record = q.add('R41_adoption_decision', {
        'proposal': proposal, 'check': check, 'child': child.json(),
        'scope': 'finite adoption bank; distribution certificate UNKNOWN'
    }, deps=(proposal,)+tuple(adopt_refs))
    return {'phase': phase, 'generation': generation,
            'parent': parent.json(), 'proposed': proposed.json(), 'child': child.json(),
            'start_program': start_program, 'tasks': tasks, 'pool': [b.json() for b in pool],
            'selection': selection, 'space': space.public(), 'context': context,
            'history_blocks': saved_history, 'history_refs': history_refs,
            'new_history_ref': ref, 'new_history_seed': new_seed,
            'task_seed': task_seed, 'pool_seed': pool_seed,
            'adoption_blocks': blocks_json(adopt_blocks), 'adoption_refs': adopt_refs,
            'adoption_seeds': adopt_seeds, 'proposal_record': proposal,
            'decision_record': record, 'check': check,
            'proposal_responses': eng.export(), 'adoption_responses': ae.export(),
            'proposal_cost': dict(eng.cost), 'adoption_cost': dict(ae.cost),
            'actual_cost': diff(asdict(q.own_diagnostic_cost), before_actual)}

def deploy(q, step, chosen, reason):
    old_id, old_ledger = id(q), id(q.ledger)
    parent = bundle(step['parent'])
    intervention = q.add('R41_deployment_intervention', {
        'natural_decision': step['decision_record'], 'natural_child': step['child'],
        'actually_installed': chosen.json(), 'reason': reason,
        'changed_component': 'allocator_ast_and_scale_only'
    }, deps=(step['decision_record'],))
    q.previous_allocator = parent
    q.bind_allocator(chosen, (intervention,))
    eng = base.InterventionEngine(step['tasks'], blocks_from_json(step['adoption_blocks']))
    selected_task = eng.run(chosen, 0).task
    q.search_program = base.search.Program(step['tasks'][selected_task])
    q.add('R41_task_program_binding', {'actual_allocator': chosen.json(),
          'task_index': selected_task, 'program': q.search_program.ast}, deps=(q.bundle_permission,))
    for block, ref in zip(blocks_from_json(step['adoption_blocks']), step['adoption_refs']):
        q.remember(block, ref)
    if q.require_allocator().key != chosen.key or (id(q), id(q.ledger)) != (old_id, old_ledger):
        raise RuntimeError('deployment or persistence failure')
    return {'mechanism': chosen.json(), 'task_index': selected_task,
            'task_program': q.search_program.ast, 'event': intervention,
            'model_cost': dict(eng.cost), 'same_queen_and_ledger': True}

def branch_from(q, root, retain, annotation=False, restore=False):
    # Experimenter-controlled finite counterfactual state copies, not autonomous replication.
    b = deepcopy(q)
    prefix = identity(q.ledger.export())
    if identity(b.ledger.export()) != prefix:
        raise RuntimeError('snapshot prefix mismatch')
    parent = bundle(root['parent'])
    permission = b.bundle_permission
    b.bind_allocator(parent, (permission,)) # Rebind object-identity guard after the explicit copy.
    if annotation:
        b.add('R41_annotation_only', {'text': 'root modification removed from a note only'},
              refs=(root['decision_record'],))
    if restore:
        b.bind_allocator(parent, (root['decision_record'],))
    child = bundle(root['child']) if retain else parent
    applied = deploy(b, root, child, 'controlled_root_retain' if retain else 'controlled_root_remove')
    return b, {'prefix_sha256': prefix, 'prefix_records': len(q.ledger.records),
               'retain': retain, 'annotation': annotation, 'restore': restore, 'applied': applied}

def future_run(q, origin):
    object_ids = (id(q), id(q.ledger))
    rows = []
    for g in range(ROUNDS):
        r = prepare_round(q, origin, 'continuation', g)
        r['applied'] = deploy(q, r, bundle(r['child']), 'natural_adoption')
        rows.append(r)
    if object_ids != (id(q), id(q.ledger)):
        raise RuntimeError('persistent process replaced')
    return {'rounds': rows, 'endpoint': q.require_allocator().json(),
            'ledger': q.ledger.export(), 'actual_total': asdict(q.own_diagnostic_cost),
            'same_queen_and_ledger': True}

def future_semantic(f):
    # This ignores bookkeeping record IDs/notes, never mechanism/data/decisions.
    return identity([{'parent':r['parent'], 'pool':r['pool'], 'tasks':r['tasks'],
                      'history':r['history_blocks'], 'adoption':r['adoption_blocks'],
                      'selection':r['selection'], 'child':r['child'],
                      'task':r['applied']['task_program']} for r in f['rounds']])

def assay_pool(donor, seed, mode):
    generator = donor if mode == 'full' else INITIAL
    # Explicitly a NEW R41 sampler, not a reconstructed R39 hash match.
    asts = racing.candidates(generator.ast, seed, 16)
    rng = Random(seed ^ 731)
    out, seen = [INITIAL], {INITIAL.key}
    emitted = []
    for ast in asts[1:]:
        b = base.Bundle(ast, rng.choice(base.SCALES))
        emitted.append(b.json())
        if b.key in seen or (mode == 'full' and b.key == donor.key):
            continue
        seen.add(b.key); out.append(b)
        if len(out) == 8:
            return out, {'generator':generator.json(), 'seed':seed,
                         'generated_ast_slots':16, 'inspected_mutants':emitted}
    raise RuntimeError('fixed assay generation cap could not supply seven unique mutants')

def assay(origin, donor, mode):
    slates = []
    for k in range(SLATES):
        phase = 'assay:'+str(k)
        q, _ = base.make_queen(innovation(origin, phase, 'queen'))
        source = []
        for j in range(6):
            s=innovation(origin, phase, 'history', j)
            block, ref=q.acquire(base.opaque_problems(s)); q.remember(block, ref)
            source.append({'seed':s,'ref':ref})
        tasks=base.task_pool(0, innovation(origin, phase, 'tasks'))
        pool, gen=assay_pool(donor, innovation(origin, phase, 'candidates'), mode)
        eng=base.InterventionEngine(tasks, q.history)
        cols=[[eng.run(b,j) for b in pool] for j in range(3)]
        ctx={'tasks':tasks,'inner_budget':12,'train':4,'check':2,'receiver':INITIAL.json()}
        space=MeasuredSpace(q,pool,cols,q.block_refs[:3],ctx)
        candidate, selection=base.choose_proposal(INITIAL,donor,pool,space,eng,'space')
        proposal=q.add('R41_assay_proposal',{'candidate':candidate.json(),'donor':donor.json(),
                       'pool':[b.json() for b in pool]},deps=(space.version,))
        histories=blocks_json(q.history); hrefs=list(q.block_refs)
        adopt, arefs, asources=[],[],[]
        for j in range(4):
            s=innovation(origin,phase,'adoption',j)
            block,ref=q.acquire(base.opaque_problems(s))
            adopt.append(block);arefs.append(ref);asources.append(s)
        ae=base.InterventionEngine(tasks,adopt)
        product,check=base.adoption(INITIAL,candidate,ae)
        decision=q.add('R41_assay_product',{'product':product.json(),'check':check},
                       deps=(proposal,)+tuple(arefs))
        q.bind_allocator(product,(decision,))
        # Future audit is constructed only AFTER the candidate and its adoption are fixed.
        test_seeds=[innovation(origin,phase,'audit',j) for j in range(AUDIT_BLOCKS)]
        tests=[base.problems(s) for s in test_seeds]
        ev=base.InterventionEngine(tasks,tests)
        initial=[ev.run(INITIAL,j).loss for j in range(AUDIT_BLOCKS)]
        offspring=[ev.run(product,j).loss for j in range(AUDIT_BLOCKS)]
        # Post-decision oracle diagnostics; explicitly evaluator-only and not fed back.
        all_risks=[mean(ev.run(b,j).loss for j in range(AUDIT_BLOCKS)) for b in pool]
        slates.append({'slate':k,'mode':mode,'donor':donor.json(),'receiver':INITIAL.json(),
          'source':source,'task_seed':innovation(origin,phase,'tasks'), 'tasks':tasks,
          'generation':gen,'pool':[b.json() for b in pool], 'history_blocks':histories,'history_refs':hrefs,
          'context':ctx,'space':space.public(),'selection':selection,'candidate':candidate.json(),
          'proposal_record':proposal,'adoption_blocks':blocks_json(adopt), 'adoption_refs':arefs,
          'adoption_seeds':asources,'check':check,'product':product.json(),'decision_record':decision,
          'audit_seeds':test_seeds,'audit_blocks':blocks_json(tests),'baseline_risks':initial,
          'product_risks':offspring,'gain':mean(initial)-mean(offspring),
          'oracle_all_risks_post_decision':all_risks,'ledger':q.ledger.export(),
          'proposal_responses':eng.export(),'adoption_responses':ae.export(),
          'proposal_cost':dict(eng.cost),'adoption_cost':dict(ae.cost),
          'evaluator_cost':dict(ev.cost),'actual_cost':asdict(q.own_diagnostic_cost)})
    return {'mode':mode,'donor':donor.json(),'slates':slates,
            'estimated_I':mean(r['gain'] for r in slates)}

def origin_trial(origin):
    q, warmup=init_queen(origin,'discovery')
    natural=[];root=None
    for g in range(ROOT_LIMIT):
        row=prepare_round(q,origin,'discovery',g)
        natural.append(row)
        if row['check']['accepted']:
            root=row;break
        row['applied']=deploy(q,row,bundle(row['child']),'natural_adoption')
    result={'stage':'R41','origin':origin,'warmup':warmup,'natural':natural,
            'root':root,'pre_root_ledger':q.ledger.export(),'protocol':'R41_v1',
            'original_R39_reproduction':False}
    if root is None:
        result['summary']={'has_root':False,'delta0':0.,'delta3':0.,'additional_effect':0.,
                           'selector_delta3':0.,'with_updates':0,'without_updates':0,
                           'chain_screen':False}
        return result
    branches={}
    for label, retain, note, restore in [('with',True,False,False),('without',False,False,False),
                                       ('restored',True,False,True),('annotation_only',True,True,False)]:
        b, installation=branch_from(q,root,retain,note,restore)
        f=future_run(b,origin);f['installation']=installation;branches[label]=f
    if future_semantic(branches['with'])!=future_semantic(branches['restored']):
        raise RuntimeError('restoration positive control failed')
    if future_semantic(branches['with'])!=future_semantic(branches['annotation_only']):
        raise RuntimeError('annotation negative control failed')
    assays={}; aliases={}
    donors={'root_parent':root['parent'],'root_child':root['child'],
            'with_end':branches['with']['endpoint'],'without_end':branches['without']['endpoint']}
    for label in ('with','without'):
        for i,r in enumerate(branches[label]['rounds']):donors[f'{label}_{i}']=r['child']
    for label,b in donors.items():
        modes=('full','selector') if label in ('root_parent','root_child','with_end','without_end') else ('full',)
        for mode in modes:
            key=mode+':'+b['key'];aliases[label+':'+mode]=key
            if key not in assays:assays[key]=assay(origin,bundle(b),mode)
    get=lambda label,mode='full':assays[aliases[label+':'+mode]]['estimated_I']
    d0=get('root_child')-get('root_parent')
    d3=get('with_end')-get('without_end')
    wu=sum(r['check']['accepted'] for r in branches['with']['rounds'])
    nu=sum(r['check']['accepted'] for r in branches['without']['rounds'])
    root_i=get('root_child');prev=root_i;improving=0
    for g,r in enumerate(branches['with']['rounds']):
        now=get(f'with_{g}')
        if r['check']['accepted'] and now>prev+base.EPS:improving+=1
        prev=now
    summary={'has_root':True,'delta0':d0,'delta3':d3,'additional_effect':d3-d0,
       'selector_delta3':get('with_end','selector')-get('without_end','selector'),
       'root_parent_I':get('root_parent'),'root_child_I':get('root_child'),
       'with_end_I':get('with_end'),'without_end_I':get('without_end'),
       'with_updates':wu,'without_updates':nu,'with_I_improving_updates':improving,
       'chain_screen': bool(d0>base.EPS and d3>base.EPS and d3-d0>base.EPS and wu>=2 and
                            improving>=2 and get('with_end')>base.EPS),
       'restoration_control':True,'annotation_control':True,
       'with_future_actual':diff(branches['with']['actual_total'],asdict(q.own_diagnostic_cost)),
       'without_future_actual':diff(branches['without']['actual_total'],asdict(q.own_diagnostic_cost))}
    result.update(branches=branches,assays=assays,aliases=aliases,summary=summary)
    return result
