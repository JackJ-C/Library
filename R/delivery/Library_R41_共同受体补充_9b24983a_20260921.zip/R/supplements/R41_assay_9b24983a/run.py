"""Foreground, offline frozen execution; per-origin atomic evidence and read-only audit."""
from __future__ import annotations
import argparse
import hashlib
import json
import lzma
import os
from pathlib import Path
import sys
import time
from . import audit
from .core import HERE, BATCHES, canon, origin_trial
from .acquisition import experiment

ACQUISITION = {'C': list(range(95100,95116)), 'D':list(range(96100,96116))}

def deny_external(event,args):
    if event.startswith('socket.') or event in ('subprocess.Popen','os.system','os.fork','os.posix_spawn'):
        raise PermissionError('R41 offline experiment forbids external execution/network: '+event)

def check_frozen():
    p=HERE/'FROZEN.json'
    frozen=json.loads(p.read_text())
    for relative,expected in frozen['sha256'].items():
        actual=hashlib.sha256((HERE/relative).read_bytes()).hexdigest()
        if actual!=expected:raise RuntimeError('frozen mismatch '+relative)
    return hashlib.sha256(p.read_bytes()).hexdigest()

def save_new(path,data):
    raw=(canon(data)+'\n').encode()
    with path.open('xb') as f:f.write(raw)

def existing(path):
    receipt=path.with_suffix('.receipt.json');verification=path.with_suffix('.audit.json')
    if not (path.exists() and receipt.exists() and verification.exists()):
        if any(p.exists() for p in (path,receipt,verification)):
            raise RuntimeError('incomplete saved artifact; preserve and inspect before recovery: '+str(path))
        return False
    r=json.loads(receipt.read_text());v=json.loads(verification.read_text())
    packed=path.read_bytes();raw=lzma.decompress(packed)
    if hashlib.sha256(packed).hexdigest()!=r['xz_sha256'] or hashlib.sha256(raw).hexdigest()!=r['raw_sha256']:
        raise RuntimeError('saved archive changed')
    if v.get('pass') is not True or v.get('raw_sha256')!=r['raw_sha256']:
        raise RuntimeError('saved audit receipt inconsistent')
    if r['freeze_sha256']!=check_frozen():raise RuntimeError('saved receipt belongs to different freeze')
    return True

def one(kind,batch,index):
    frozen_id=check_frozen()
    if kind=='origin':
        seed=BATCHES[batch][index];method=None;negative=False
        path=HERE/'results'/batch/f'{seed}.json.xz'
    else:
        negative=kind=='negative'
        seed=ACQUISITION['C'][0] if negative else ACQUISITION[batch][index//2]
        method=('fixed','active')[index%2]
        path=HERE/'results'/'acquisition'/f'{seed}_{method}_{"outside" if negative else "family"}.json.xz'
    path.parent.mkdir(parents=True,exist_ok=True)
    if existing(path):return {'file':str(path.relative_to(HERE)),'status':'existing_verified_not_new_sample'}
    began=time.perf_counter()
    data=origin_trial(seed) if kind=='origin' else experiment(seed,method,negative)
    raw=(canon(data)+'\n').encode();compressed=lzma.compress(raw,preset=3)
    # Complete data saved before independent verification; a failed audit never deletes the raw record.
    with path.open('xb') as f:f.write(compressed)
    generated=time.perf_counter()
    receipt={'file':str(path.relative_to(HERE)), 'seed':seed,'kind':kind,'batch':batch,
             'raw_sha256':hashlib.sha256(raw).hexdigest(),'xz_sha256':hashlib.sha256(compressed).hexdigest(),
             'raw_bytes':len(raw),'xz_bytes':len(compressed),'freeze_sha256':frozen_id,
             'generation_seconds':generated-began,'python':sys.version,
             'summary':data.get('summary',None)}
    save_new(path.with_suffix('.receipt.json'),receipt)
    try:
        outcome=audit.verify(json.loads(raw)) if kind=='origin' else audit.verify_acquisition(json.loads(raw))
    except Exception as e:
        save_new(path.with_suffix('.audit_failure.json'), {'error_type':type(e).__name__,'error':str(e),
                 'raw_sha256':receipt['raw_sha256'],'freeze_sha256':frozen_id})
        raise
    outcome.update(raw_sha256=receipt['raw_sha256'],freeze_sha256=frozen_id,
                   audit_seconds=time.perf_counter()-generated)
    save_new(path.with_suffix('.audit.json'),outcome)
    return {'file':str(path.relative_to(HERE)), 'status':'new_verified','summary':data.get('summary',outcome)}

def main():
    p=argparse.ArgumentParser();p.add_argument('kind',choices=('origin','acquisition','negative'))
    p.add_argument('batch',choices=('C','D'));p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int)
    a=p.parse_args();count=128 if a.kind=='origin' else 32 if a.kind=='acquisition' else 2
    end=count if a.end is None else a.end
    if not 0<=a.start<=end<=count:raise ValueError('invalid frozen range')
    if a.kind=='negative' and a.batch!='C':raise ValueError('negative control registered on C seed only')
    sys.addaudithook(deny_external)
    for i in range(a.start,end):print(canon(one(a.kind,a.batch,i)),flush=True)

if __name__=='__main__':main()
