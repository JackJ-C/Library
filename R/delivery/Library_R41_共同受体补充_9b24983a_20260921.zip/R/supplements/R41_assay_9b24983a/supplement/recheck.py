"""Post-freeze replay and third-path arithmetic checks; does not change formal experiments."""
from pathlib import Path
from hashlib import sha256
from fractions import Fraction
import argparse,json,lzma,time
from ..core import HERE,origin_trial,canon
from ..run import check_frozen,save_new

def replay(seed):
    batch='C' if 85100<=seed<85228 else 'D'
    p=HERE/'results'/batch/f'{seed}.json.xz';old=lzma.decompress(p.read_bytes())
    t=time.perf_counter();new=(canon(origin_trial(seed))+'\n').encode()
    if old!=new:raise RuntimeError('complete semantic archive replay differs')
    out={'origin':seed,'raw_sha256':sha256(new).hexdigest(),'full_raw_bytes_equal':True,
         'elapsed_seconds':time.perf_counter()-t,'freeze_sha256':check_frozen(),
         'new_independent_scientific_sample':False}
    save_new(HERE/'supplement'/f'replay_{seed}.json',out);print(out)

def totals():
    summary=json.loads((HERE/'results/SUMMARY.json').read_text());out={}
    for b in ('C','D'):
        effects=[];immediate=[];roots=0;updates=[0,0];nr=0;ng=0
        for p in sorted((HERE/'results'/b).glob('*.json.xz')):
            d=json.loads(lzma.decompress(p.read_bytes()));nr+=len(d['natural'])
            if not d['root']:effects.append(Fraction());immediate.append(Fraction());continue
            roots+=1
            vals={}
            for label in ('root_parent','root_child','with_end','without_end'):
                a=d['assays'][d['aliases'][label+':full']];sl=[]
                for s in a['slates']:
                    # Exact arithmetic on stored decimal risks, not importing analyze/means.
                    g=(sum(map(lambda v:Fraction(str(v)),s['baseline_risks']))-
                       sum(map(lambda v:Fraction(str(v)),s['product_risks'])))/8
                    sl.append(g)
                vals[label]=sum(sl)/2
            effects.append(vals['with_end']-vals['without_end']);immediate.append(vals['root_child']-vals['root_parent'])
            for i,arm in enumerate(('with','without')):
                for r in d['branches'][arm]['rounds']:
                    accepted=(r['child']['key']!=r['parent']['key'])
                    if accepted!=r['check']['accepted']:raise RuntimeError('adoption/binding discrepancy')
                    updates[i]+=accepted
            ng+=4*3
        avg=float(sum(effects)/len(effects))
        if abs(avg-summary['batches'][b]['delta3']['mean'])>1e-11:raise RuntimeError('third path summary differs')
        out[b]={'origins':len(effects),'roots':roots,'exact_decimal_mean_delta3':str(sum(effects)/len(effects)),
                'mean_delta3':avg,'mean_delta0':float(sum(immediate)/len(immediate)),
                'with_updates':updates[0],'without_updates':updates[1],
                'actual_discovery_rounds':nr,'actual_continuation_rounds_four_arms':ng,'pass':True}
    save_new(HERE/'supplement/THIRD_PATH_TOTALS.json',out);print(out)

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--seed',type=int);a=p.parse_args()
    if a.seed:replay(a.seed)
    else:totals()
