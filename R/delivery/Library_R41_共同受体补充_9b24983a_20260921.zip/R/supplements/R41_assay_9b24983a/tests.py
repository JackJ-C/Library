"""Pre-formal mechanism and deliberate-corruption tests; not scientific samples."""
import unittest,json,lzma
from pathlib import Path
from copy import deepcopy
from itertools import product
from . import core,audit
from .acquisition import experiment

class Contracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.d=core.origin_trial(1)
        cls.no=core.origin_trial(0)
        cls.pos=experiment(0,'active',False)
        cls.neg=experiment(0,'active',True)
    def test_01_independent_origin(self):self.assertTrue(audit.verify(self.d)['pass'])
    def test_02_no_root(self):self.assertEqual(audit.verify(self.no)['verified_rounds'],6)
    def test_03_deterministic_replay(self):self.assertEqual(core.canon(self.d),core.canon(core.origin_trial(1)))
    def test_04_coupled_innovations(self):
        for w,n in zip(self.d['branches']['with']['rounds'],self.d['branches']['without']['rounds']):
            for k in ('new_history_seed','task_seed','pool_seed','adoption_seeds'):self.assertEqual(w[k],n[k])
    def test_05_prefix(self):
        pre=self.d['pre_root_ledger']
        for f in self.d['branches'].values():self.assertEqual(f['ledger'][:len(pre)],pre)
    def test_06_removal_is_deployment(self):
        self.assertNotEqual(self.d['branches']['with']['installation']['applied']['mechanism']['key'],
                            self.d['branches']['without']['installation']['applied']['mechanism']['key'])
    def test_07_restore(self):self.assertEqual(core.future_semantic(self.d['branches']['with']),core.future_semantic(self.d['branches']['restored']))
    def test_08_annotation_is_not_removal(self):self.assertEqual(core.future_semantic(self.d['branches']['with']),core.future_semantic(self.d['branches']['annotation_only']))
    def test_09_summary_corruption(self):
        x=deepcopy(self.d);x['summary']['delta3']+=.01
        with self.assertRaises(ValueError):audit.verify(x)
    def test_10_seed_corruption(self):
        x=deepcopy(self.d);x['branches']['without']['rounds'][0]['pool_seed']+=1
        with self.assertRaises(ValueError):audit.verify(x)
    def test_11_mechanism_corruption(self):
        x=deepcopy(self.d);x['branches']['with']['endpoint']['scale']=.5
        with self.assertRaises(ValueError):audit.verify(x)
    def test_12_prefix_corruption(self):
        x=deepcopy(self.d);x['branches']['with']['ledger'][0]['source']='changed'
        with self.assertRaises(ValueError):audit.verify(x)
    def test_13_product_score_corruption(self):
        x=deepcopy(self.d);next(iter(x['assays'].values()))['slates'][0]['product_risks'][0]+=.01
        with self.assertRaises(ValueError):audit.verify(x)
    def test_14_future_edge_corruption(self):
        x=deepcopy(self.no);x['pre_root_ledger'][0]['deps']=[1]
        with self.assertRaises(ValueError):audit.verify(x)
    def test_15_selector_pool_is_fixed(self):
        donor=core.bundle(self.d['root']['child'])
        for s in range(8):
            a,_=core.assay_pool(core.INITIAL,s,'selector');b,_=core.assay_pool(donor,s,'selector')
            self.assertEqual([v.key for v in a],[v.key for v in b])
    def test_16_no_full_direct_donor(self):
        donor=core.bundle(self.d['root']['child'])
        for s in range(8):
            p,_=core.assay_pool(donor,s,'full')
            self.assertNotIn(donor.key,[b.key for b in p[1:]])
    def test_17_partial_identification(self):self.assertTrue(audit.verify_acquisition(self.pos)['pass'])
    def test_18_hidden_cell_negative(self):self.assertEqual(audit.verify_acquisition(self.neg)['audit_correct'],4801)
    def test_19_hidden_cell_same_evidence(self):self.assertEqual(self.pos['learning'],self.neg['learning'])
    def test_20_partial_tamper(self):
        x=deepcopy(self.pos);x['learning']['model']['special_relative']=(x['learning']['model']['special_relative']+1)%7
        with self.assertRaises(ValueError):audit.verify_acquisition(x)
    def test_21_equal_execution(self):
        for f in product((0.,.1,.5,1.),repeat=4):self.assertEqual(audit.alloc_eval(0,f),audit.alloc_eval(['*',0,2],f))
    def test_22_generator_support_witness(self):
        def depth(t):return 0 if isinstance(t,(int,str)) else 1+max(depth(t[1]),depth(t[2]))
        found=False
        for s in range(64):
            self.assertTrue(all(depth(t)<=2 for t in audit.alloc_candidates(0,s,8)))
            found=found or any(depth(t)>2 for t in audit.alloc_candidates(['*',0,2],s,8))
        self.assertTrue(found)
    def test_23_context_dependent_order(self):
        first=[1.,0.];second=[0.,1.]
        self.assertGreater(first[0],second[0]);self.assertLess(first[1],second[1])
    def test_24_unknown_cell_not_identified(self):
        a={(0,0):0,(0,1):0};b={(0,0):0,(0,1):1}
        self.assertEqual(a[0,0],b[0,0]);self.assertNotEqual(a[0,1],b[0,1])
    def test_25_root_is_first_accepted(self):
        self.assertTrue(self.d['natural'][-1]['check']['accepted'])
        self.assertTrue(all(not r['check']['accepted'] for r in self.d['natural'][:-1]))
    def test_26_source_hashes(self):
        from hashlib import sha256
        f=json.loads((core.REFERENCE/'r32_r37/FROZEN.json').read_text())
        existing={p:h for p,h in f['sha256'].items() if (core.REFERENCE/p).is_file()}
        self.assertEqual(len(existing),12)
        for p,h in existing.items():self.assertEqual(sha256((core.REFERENCE/p).read_bytes()).hexdigest(),h)
if __name__=='__main__':unittest.main(verbosity=2)
