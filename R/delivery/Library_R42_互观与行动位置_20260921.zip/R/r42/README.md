# R42研究包入口

先读REPORT.md与ERRATA_AND_SCOPE.md，再读THEORY.md和PROTOCOL.md。FROZEN.json是正式前14项清单；它的“all_formal_complete: false”是冻结时历史状态，不应改写为结项状态。结项数据在results/SUMMARY.json，补强在supplement/。

本目录可隔离放在任意工作目录。Python3.10+仅标准库，实际执行为CPython3.13。没有安装依赖、网络、密钥或付费服务。原依赖有动态编译固定算术函数，但不执行任意外部输入程序。先人工审核源码再运行。

```bash
cd R/r42
python tests.py
python -O tests.py
python supplement/checks.py
python -O supplement/checks.py
python analyze.py
```

从既有JSON逐件审核可导入audit.py按记录类别调用验证器。逐文件SHA-256见MANIFEST.json，正式raw/XZ/运行冻结合约身份见各receipt.json。results/FINAL_INTEGRITY.json是同核验器再检查回执；results/BYTE_REPLAY.json是4份整条字节复现，不增加独立样本。

真正重跑请先复制全部目录至新的隔离位置，将已有results/和supplement/results/移动到独立只读归档目录，而不是删除原档，然后执行：

```bash
python run.py A --start 0 --end 16
python run.py A --start 16 --end 64
python run.py B --start 0 --end 16
python run.py B --start 16 --end 64
python run.py aux
python analyze.py
python supplement/checks.py run
```

运行器拒绝覆盖已存在原档。若某条原档已写而回执核验中断，保留文件并从其字节补核验，不重抽seed或偷偷更改冻结算法。正式177份原档与4份恢复覆盖原档必须分开统计。

本期使用原Queen与Ledger的执行依赖，但新世界、响应包装与学习适配器由研究者提供。不是R41完整基准重放，也不是原Queen自行发明这些最高层规则。公共文本与完整ZIP的远端上传状态见PUBLICATION.json；原R37、远端R41和9b24983a补充不修改。
