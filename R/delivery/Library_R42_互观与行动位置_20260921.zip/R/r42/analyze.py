"""Read-only summary construction from the frozen raw records, not from success prose."""
from pathlib import Path
from hashlib import sha256
from random import Random
from statistics import mean
import json,lzma
ROOT=Path(__file__).resolve().parent

def summarize():
    out={'stage':'R42','frozen_sha256':sha256((ROOT/'FROZEN.json').read_bytes()).hexdigest(),
         'unit':'world seed; within-world actors, phases, goals and windows are not independent samples','batches':{}}
    allrows=[]
    for batch,base in [('A',105100),('B',106100)]:
        rows=[]
        for seed in range(base,base+64):
            p=ROOT/'results'/batch/f'{seed}.json.xz';raw=lzma.decompress(p.read_bytes());r=json.loads(raw)
            receipt=json.loads(p.with_suffix('.receipt.json').read_text());review=json.loads(p.with_suffix('.audit.json').read_text())
            if receipt['raw_sha256']!=sha256(raw).hexdigest() or receipt['xz_sha256']!=sha256(p.read_bytes()).hexdigest() or review['status']!='PASS':raise RuntimeError('invalid archive')
            rows.append(r);allrows.append(r)
        metrics={k:sum(r['summary'][k] for r in rows) for k in ('heldout_correct','heldout_total','live_goal_correct','live_goal_total','post_goal_correct','stale_goal_correct','goal_refusals','local_full_models_refused','changed_self_horizon2','actual_microsteps','sensor_scalar_reads','resets','ledger_reads','guard_source_checks')}
        metrics['worlds']=64;metrics['actor_instances']=192
        metrics['all_same_motors']=all(r['summary']['same_motors'] for r in rows)
        metrics['all_changed_feedback']=all(r['summary']['changed_feedback'] for r in rows)
        metrics['all_flat_equal']=all(r['summary']['flat_equal'] for r in rows)
        metrics['all_cross_source_revocation_and_restore']=all(r['summary']['withdrawals_pass'] and r['summary']['restoration_pass'] for r in rows)
        metrics['executed_goal_successes']=sum(g['action'] is not None and g['correct'] for r in rows for p in r['phases'] for g in p['goals'])
        metrics['calibration_trials']=64*2*4;metrics['calibration_microsteps']=64*2*4*3
        metrics['restoration_trials']=64*4
        effects=[(r['summary']['post_goal_correct']-r['summary']['stale_goal_correct'])/21 for r in rows]
        rng=Random(20260921+(batch=='B'));boot=sorted(mean(rng.choices(effects,k=64)) for _ in range(5000))
        metrics['decision_accuracy_difference']=mean(effects);metrics['descriptive_bootstrap_95']=[boot[125],boot[4875]]
        metrics['exact_family_warning']='This particular edge removal has an algebraically forced pattern; not an unanticipated universal performance advantage.'
        out['batches'][batch]=metrics
    out['raw_main_records']=len(allrows)
    out['ledger_records']=sum(len(l) for r in allrows for l in r['ledgers'])
    neg=[json.loads(lzma.decompress(p.read_bytes())) for p in sorted((ROOT/'results/negative').glob('*.xz'))]
    out['negative']={'worlds':len(neg),'witness_successes':sum(r['summary']['witness_successes'] for r in neg),
        'physical_successes':sum(r['summary']['physical_successes'] for r in neg),'goals':7*len(neg),'scope':'correlated calibration error, not consciousness detection'}
    out['solo_control']={'worlds':len(list((ROOT/'results/solo').glob('*.xz'))),'solo_models':48,'sensor_devices':'extra proprioceptive channel; not equal sensor cost'}
    out['rename_control']={'worlds':len(list((ROOT/'results/rename').glob('*.xz'))),'relabels_per_world':6}
    syn=json.loads(lzma.decompress((ROOT/'results/synchrony/finite_counterexample.json.xz').read_bytes()))
    out['synchrony']={k:syn[k] for k in ('same_observational_stream','different_private_pulse_streams','equally_likely_origin_bound')}
    out['total_raw_archives']=len(list((ROOT/'results').rglob('*.xz')))
    out['not_claimed']=['consciousness','universal special observer','necessary social origin of self','stable RSI','equal cost of stale and refreshed inference','unconditional finite-world identification']
    return out

if __name__=='__main__':
    print(json.dumps(summarize(),indent=2,ensure_ascii=False))
