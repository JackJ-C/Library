"""R42 independent read-only verifier. Imports neither Queen nor study/core.
Uses evaluator fixture only to reconstruct the actual physical sensor/action stream.
Independence is implementation-path independence, not an independent laboratory.
"""
from __future__ import annotations
from hashlib import sha256
import json
from random import Random


def ensure(value,message):
    if not value:raise ValueError('AUDIT: '+message)

def enc(x):
    return json.dumps(x,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)

def hashobj(x):return sha256(enc(x).encode()).hexdigest()

def regenerate_fixture(seed):
    generator=Random(seed)
    ports=[0,1,2];generator.shuffle(ports)
    view_order=[];bias=[];policy=[]
    for j in range(3):
        channels=[k for k in (0,1,2) if k!=ports[j]]
        generator.shuffle(channels)
        view_order.append(channels)
        bias.append([generator.randrange(7),generator.randrange(7)])
        policy.append([generator.randrange(1,7),generator.randrange(1,7)])
    return {'seed':seed,'owner':ports,'slots':view_order,'offsets':bias,'weights':policy,
        'gains':[generator.randrange(1,7) for _ in range(3)],'start':[generator.randrange(7) for _ in range(3)],
        'scales':[[1,1] for _ in range(3)]}

def validate_ledger(records):
    invalid=set();children={};parsed=[]
    for seq,record in enumerate(records):
        ensure(record['seq']==seq,'ledger sequence')
        for field in ('refs','deps'):
            links=record[field]
            ensure(len(links)==len(set(links)) and all(type(r)is int and 0<=r<seq for r in links),'ledger links')
        ensure(not any(r in invalid for r in record['deps']),'invalid dependency accepted')
        value=json.loads(record['body']);parsed.append(value)
        for r in record['deps']:children.setdefault(r,set()).add(seq)
        if record['kind']=='revocation':
            root=value['root'];ensure(type(root)is int and 0<=root<seq,'revocation root')
            queue=[root];new=set()
            while queue:
                r=queue.pop()
                if r in invalid:continue
                invalid.add(r);new.add(r);queue.extend(children.get(r,()))
            ensure(sorted(new)==value['invalidated'],'revocation closure')
    return parsed,invalid

def read_sensors(f,state):
    ans=[]
    for i in range(3):
        row=[]
        for k,j in enumerate(f['slots'][i]):row.append((f['scales'][i][k]*state[j]+f['offsets'][i][k])%7)
        ans.append(row)
    return ans

def check_trial(f,tr,parsed=None):
    state=list(f['start']);positions=[]
    ensure(len(tr['initial_input'])==3,'pulse width')
    for h,row in enumerate(tr['steps']):
        before=read_sensors(f,state)
        ensure(row['before']==before,'before observations')
        wants=tr['initial_input'] if h==0 else [sum(f['weights'][i][k]*before[i][k] for k in range(len(before[i])))%7 for i in range(3)]
        ensure(row['requested']==wants,'reactive action differs')
        issued=[v%7 for v in wants];ensure(row['issued']==issued,'emission')
        for i,v in enumerate(issued):state[f['owner'][i]]=(state[f['owner'][i]]+v*f['gains'][i])%7
        after=read_sensors(f,state);ensure(row['after']==after,'after observations')
        if parsed is not None:
            for i in range(3):
                ir=row['intentions'][i];orr=row['receipts'][i]
                intention=parsed[i][ir];obs=parsed[i][orr]
                ensure(intention['observed']==before[i] and intention['requested']==wants[i] and intention['horizon']==h,'intention linkage')
                ensure(intention['policy']==('external_local_pulse' if h==0 else 'fixed_linear_response'),'policy type')
                ensure(intention['local_weights']==(None if h==0 else f['weights'][i]),'own weights')
                ensure(obs['intention']==ir and obs['issued']==issued[i] and obs['before']==before[i] and obs['after']==after[i],'receipt linkage')
        positions.append([state[f['owner'][i]] for i in range(3)])
    return positions

def rebuild_from_views(cal, witnesses=(0,1,2), expected_count=2):
    """Reconstruct response tensors cell-by-cell from actual reported observations."""
    expected=[[0,0,0],[1,0,0],[0,1,0],[0,0,1]]
    ensure([r['initial_input'] for r in cal]==expected,'calibration design')
    assignments={};fps={};coords={i:[] for i in range(3)}
    for w in witnesses:
        for k in range(len(cal[0]['steps'][0]['after'][w])):
            row=[]
            for source in range(3):row.append((cal[source+1]['steps'][0]['after'][w][k]-cal[0]['steps'][0]['after'][w][k])%7)
            act=[i for i in range(3) if row[i]!=0]
            ensure(len(act)==1,'calibration origin rank')
            assignments[str(w)+':'+str(k)]=act[0];fps[str(w)+':'+str(k)]=row;coords[act[0]].append((w,k))
    ensure(all(len(v)==expected_count for v in coords.values()),'two distinct views per origin')
    hs=[]
    for h in range(3):
        tensor=[]
        for target in range(3):
            line=[]
            for source in range(3):
                vals=[]
                for w,k in coords[target]:vals.append((cal[source+1]['steps'][h]['after'][w][k]-cal[0]['steps'][h]['after'][w][k])%7)
                ensure(len(set(vals))==1,'witness disagreement');line.append(vals[0])
            tensor.append(line)
        hs.append(tensor)
    gain=[hs[0][i][i] for i in range(3)]
    ensure(all(gain),'zero gain')
    # Brute-force finite-field division, rather than learner's modular-inverse call.
    F=[]
    for i in range(3):
        row=[]
        for j in range(3):
            choices=[a for a in range(7) if a*gain[j]%7==hs[1][i][j]]
            ensure(len(choices)==1,'division not unique');row.append(choices[0])
        F.append(row)
    for i in range(3):
        for j in range(3):
            ensure(sum(F[i][k]*hs[1][k][j] for k in range(3))%7==hs[2][i][j],'two-step closure')
    return {'H':hs,'gains':gain,'F':F,'assignments':assignments,'fingerprints':fps,
        'scope':'stationary affine feedback; calibrated channels; four trials; no subjective identity'}

def linear_forecast(num,u,h):
    z=[sum(num['H'][0][i][j]*u[j] for j in range(3))%7 for i in range(3)]
    for _ in range(h):z=[sum(num['F'][i][j]*z[j] for j in range(3))%7 for i in range(3)]
    return z

def choose_action(num,root,goal):
    allowed=[a for a in range(7) if num['H'][2][root][root]*a%7==goal]
    return min(allowed) if allowed else None

def check_goal(f,g,num,base_positions,parsed,decision_num=None):
    root=g['root'];d=g['delta'];action=g['action']
    ensure(action==choose_action(decision_num or num,root,d),'chosen inverse action')
    if action is None:
        ensure(g['trial'] is None,'refusal secretly acted')
        correct=not any(num['H'][2][root][root]*a%7==d for a in range(7))
    else:
        u=[0]*3;u[root]=action
        ensure(g['trial']['initial_input']==u,'goal acted on wrong port')
        ps=check_trial(f,g['trial'],parsed)
        effect=(ps[2][root]-base_positions[2][root])%7
        ensure(g['effect']==effect,'goal effect')
        correct=(effect==d)
    ensure(g['correct']==correct,'goal success flag')
    return int(correct)

def validate_episode(r):
    ensure(r['stage']=='R42','study identity')
    parsed=[]; invalid=[]
    for records in r['ledgers']:
        p,iv=validate_ledger(records);parsed.append(p);invalid.append(iv)
    ensure([sorted(x) for x in invalid]==r['invalid'],'final invalid sets')
    f0=r['fixture_evaluator_only'];ensure(f0==regenerate_fixture(r['seed']),'fixture/seed identity')
    f1=json.loads(enc(f0));f1['weights'][1][0]=0
    phase_metrics=[];numerics=[];trials=[]
    for phase,f in zip(r['phases'],(f0,f1)):
        cal=phase['calibration'];poss=[check_trial(f,tr,parsed) for tr in cal];trials+=cal
        num=rebuild_from_views(cal);numerics.append(num)
        # Recovered view labels must match actual intervention origin, not arbitrary row IDs.
        for key,origin in num['assignments'].items():
            w,k=map(int,key.split(':'));ensure(f['slots'][w][k]==f['owner'][origin],'origin alignment')
        ensure(num['gains']==f['gains'],'motor calibration')
        for i,model in enumerate(phase['models']):
            ensure(model['numeric']==num and model['hash']==hashobj(num),'committed numeric model')
            ensure(parsed[i][model['license']]==num,'model ledger body')
            ensure(list(r['ledgers'][i][model['license']]['deps'])==list(model['supports']),'model support list')
        held=phase['heldout'];bp=check_trial(f,held['baseline'],parsed);trials.append(held['baseline'])
        successes=total=0
        for entry in held['rows']:
            tr=entry['trial'];trials.append(tr);poses=check_trial(f,tr,parsed);flags=[]
            for h,px in enumerate(poses):
                effect=[(px[j]-bp[h][j])%7 for j in range(3)]
                flags.append(effect==linear_forecast(num,tr['initial_input'],h))
            ensure(entry['flags']==flags,'heldout predictions')
            successes+=sum(flags);total+=len(flags)
        ensure(held['correct']==successes and held['total']==total,'heldout count')
        expected_n=343 if held['exhaustive_initial_pulses'] else 32
        ensure(len(held['rows'])==expected_n,'heldout sample count')
        if held['exhaustive_initial_pulses']:
            ensure(len({tuple(e['trial']['initial_input']) for e in held['rows']})==343,'exhaustive coverage')
        goal_success=sum(check_goal(f,g,num,poss[0],parsed) for g in phase['goals'])
        trials.extend(g['trial'] for g in phase['goals'] if g['trial'] is not None)
        ensure([(g['root'],g['delta']) for g in phase['goals']]==[(i,d) for i in range(3) for d in range(7)],'goal coverage')
        stale_success=None
        if 'stale_goals' in phase:
            stale_success=sum(check_goal(f,g,num,poss[0],parsed,numerics[0]) for g in phase['stale_goals'])
            trials.extend(g['trial'] for g in phase['stale_goals'] if g['trial'] is not None)
            ensure(phase['evaluator_change']=={'before':f0['weights'],'after':f1['weights']},'changed intervention')
            ensure(all(phase['old_license_blocked']),'old model not blocked')
        phase_metrics.append((successes,total,goal_success,stale_success))
    for item in r['withdrawal']:
        i=item['root'];own=item['source_owner'];source=item['evidence']
        ensure(source in invalid[own] and item['old_license'] in invalid[i],'cross-ledger withdrawal')
        ensure(item['history_ref'] not in invalid[i],'history wrongly revoked')
        ensure(all(item[k] for k in ('blocked','world_unchanged','body_preserved','history_valid')),'withdrawal runtime flags')
    restored=r['restore_calibration'];trials+=restored
    for tr in restored:check_trial(f1,tr,parsed)
    newnum=rebuild_from_views(restored);ensure(newnum==numerics[1],'restoration changed numeric law')
    for item in r['restored']:
        i=item['root'];ensure(item['license'] not in invalid[i],'new license invalid')
        ensure(parsed[i][item['license']]==newnum,'restored body')
        ensure(item['plans']==[choose_action(newnum,i,d) for d in range(7)],'restored actions')
    s=r['summary'];n0,n1=numerics
    # Recheck the local-only information gap and the identity of the plain-data calculation.
    ensure(rebuild_from_views(json.loads(enc(r['phases'][0]['calibration'])))==n0,'plain representation changed information')
    for observer in range(3):
        ensure(len({v for k,v in n0['assignments'].items() if k.startswith(str(observer)+':')})==2,'local blind projection')
    expected={'seed':r['seed'],'heldout_correct':sum(m[0] for m in phase_metrics),'heldout_total':sum(m[1] for m in phase_metrics),
        'live_goal_correct':sum(m[2] for m in phase_metrics),'live_goal_total':42,'post_goal_correct':phase_metrics[1][2],
        'stale_goal_correct':phase_metrics[1][3], 'goal_refusals':sum(g['action'] is None for p in r['phases'] for g in p['goals']),
        'same_motors':n0['gains']==n1['gains'],'changed_feedback':n0['F']!=n1['F'],
        'changed_self_horizon2':sum(n0['H'][2][i][i]!=n1['H'][2][i][i] for i in range(3)),
        'actual_microsteps':sum(len(tr['steps']) for tr in trials),'resets':len(trials)}
    expected['sensor_scalar_reads']=12*expected['actual_microsteps']
    expected['ledger_reads']=sum(c.get('actual_record_reads',0) for c in r['runtime_costs'])
    expected['guard_source_checks']=sum(c.get('r42_source_guard_checks',0) for c in r['runtime_costs'])
    for k,v in expected.items():ensure(s[k]==v,'summary '+k)
    ensure(s['local_full_models_refused']==3,'self-blind full-model condition')
    ensure(all(s[k] for k in ('flat_equal','withdrawals_pass','restoration_pass','tape_refused','disagreement_refused','same_actors_ledgers','not_RSI')),'reported checks')
    return {'status':'PASS','independence':'no learner/Queen imports; physical streams and lineage recalculated',
            'ledger_records':sum(len(x) for x in r['ledgers']),'physical_trials':len(trials),
            'checked_summary':expected, 'runtime_identity_scope':'reported runtime checks, not a proof of physical identity'}

def validate_negative(r):
    f=r['fixture_evaluator_only'];p=[validate_ledger(l)[0] for l in r['ledgers']]
    for tr in r['calibration']:check_trial(f,tr,p)
    num=rebuild_from_views(r['calibration']);ensure(num==r['numeric'],'negative numeric')
    ws=ps=0
    for g in r['goals']:
        action=choose_action(num,0,g['delta']);ensure(g['action']==action,'negative inverse')
        check_trial(f,g['trial'],p)
        effect=action*f['gains'][0]%7
        sensed=2*effect%7
        ensure(effect==g['physical_effect_evaluator_only'] and sensed==g['witnessed_effect'],'common scale')
        ws+=int(sensed==g['delta']);ps+=int(effect==g['delta'])
    ensure(r['summary']['witness_successes']==ws and r['summary']['physical_successes']==ps,'negative counts')
    return {'status':'PASS','witness_successes':ws,'physical_successes':ps,'not_certified':'sensor calibration'}

def validate_rename(r):
    f=r['fixture_evaluator_only']
    ensure(len(r['checks'])==6,'six renamings')
    for ch in r['checks']:
        pm=ch['permutation'];ff=json.loads(enc(f))
        ff['owner']=[pm[v] for v in f['owner']];ff['slots']=[[pm[v] for v in s] for s in f['slots']]
        for old,new in enumerate(pm):ff['start'][new]=f['start'][old]
        for tr in ch['calibration']:check_trial(ff,tr)
        sem=[{'initial_input':tr['initial_input'],'steps':[{k:st[k] for k in ('before','issued','after')} for st in tr['steps']]} for tr in ch['calibration']]
        ensure(hashobj(sem)==ch['semantic_hash']==r['expected'] and ch['equal'],'renaming covariance')
    return {'status':'PASS','renamings':6}


def validate_full_sensor(r):
    f=r['fixture_evaluator_only']
    for tr in r['calibration']:check_trial(f,tr)
    for i,num in enumerate(r['solo_models']):
        ensure(num==rebuild_from_views(r['calibration'],(i,),1),'solo full-sensor model')
    ensure(r['microsteps']==12 and r['sensor_scalar_reads']==216,'solo sensor costs')
    return {'status':'PASS','solo_models':3,'not_a_same_sensor_budget_control':True}


def validate_synchrony(r):
    ensure(len(r['cases'])==6,'six routing hypotheses')
    obs_hashes=set();act_hashes=set()
    for c in r['cases']:
        f=c['fixture_evaluator_only']
        for tr in c['observational']+[c['intervention']]:check_trial(f,tr)
        def sem(tr):return {'initial_input':tr['initial_input'],'steps':[{k:st[k] for k in ('before','issued','after')} for st in tr['steps']]}
        o=hashobj([sem(t) for t in c['observational']]);a=hashobj(sem(c['intervention']))
        ensure(o==c['observational_hash'] and a==c['intervention_hash'],'synchrony hashes')
        obs_hashes.add(o);act_hashes.add(a)
    ensure(len(obs_hashes)==1 and len(act_hashes)==3,'observational non-identifiability')
    return {'status':'PASS','observational_classes':1,'private_pulse_classes':3}
