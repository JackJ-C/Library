"""R42 finite reciprocal-observation study. Offline; fixed researcher-authored adapter.
Uses the unchanged R3 Queen/M54/M8 Ledger, not simulated ledger substitutes.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
from random import Random
from itertools import product, permutations
from copy import deepcopy
from hashlib import sha256
import json
import sys

REFERENCE = Path(__file__).resolve().parent / 'reference'
sys.path.insert(0, str(REFERENCE))
from src.core import Queen

P, N = 7, 3

def canonical(x):
    return json.dumps(x, sort_keys=True, ensure_ascii=False, separators=(',', ':'), allow_nan=False)

def digest(x):
    return sha256(canonical(x).encode()).hexdigest()

def require(ok, msg):
    if not ok:
        raise ValueError(msg)

def mv(a, v):
    return [sum(x*y for x,y in zip(row,v)) % P for row in a]

def mm(a,b):
    return [[sum(a[i][k]*b[k][j] for k in range(N)) % P for j in range(N)] for i in range(N)]

def semantic_trial(row):
    return {'initial_input':row['initial_input'], 'steps':[{k:s[k] for k in ('before','issued','after')} for s in row['steps']]}

def fixture(seed):
    rng=Random(seed)
    owner=list(range(N)); rng.shuffle(owner)
    slots=[]; offsets=[]; weights=[]
    for i in range(N):
        s=[j for j in range(N) if j!=owner[i]]; rng.shuffle(s); slots.append(s)
        offsets.append([rng.randrange(P) for _ in range(2)])
        weights.append([rng.randrange(1,P) for _ in range(2)])
    return {'seed':seed, 'owner':owner, 'slots':slots, 'offsets':offsets,
            'gains':[rng.randrange(1,P) for _ in range(N)], 'weights':weights,
            'start':[rng.randrange(P) for _ in range(N)], 'scales':[[1,1] for _ in range(N)]}

class World:
    def __init__(self, spec):
        self.spec=deepcopy(spec); self.x=list(spec['start']); self.microsteps=0; self.read_scalars=0; self.resets=0
    def reset(self):
        self.x=list(self.spec['start']); self.resets+=1
    def sense(self):
        f=self.spec; self.read_scalars+=sum(len(v) for v in f['slots'])
        return [[(f['scales'][i][k]*self.x[j]+f['offsets'][i][k])%P
                 for k,j in enumerate(f['slots'][i])] for i in range(N)]
    def step(self, issued):
        require(len(issued)==N and all(type(v) is int and 0<=v<P for v in issued),'bad issued action')
        for i,a in enumerate(issued):
            self.x[self.spec['owner'][i]]=(self.x[self.spec['owner'][i]]+self.spec['gains'][i]*a)%P
        self.microsteps+=1
        return self.sense()

def queens(seed, weights=None):
    qs=[Queen(seed*3+i) for i in range(N)]
    weights=fixture(seed)['weights'] if weights is None else weights
    for i,q in enumerate(qs):
        q.r42_weights=tuple(weights[i])
        q.add('R42_adapter_scope',{'state_units':'calibrated Z7 channels; self-blind views',
            'adapter':'researcher supplied', 'not_measured':'subjective experience; recursive improvement'})
    return qs

def trial(qs, world, inputs, horizons=2, kind='probe'):
    """Only observations enter each reactive policy. Owner and gains are not inputs."""
    require(len(inputs)==N and all(type(v)is int and 0<=v<P for v in inputs),'invalid input')
    world.reset(); steps=[]
    for h in range(horizons+1):
        before=world.sense()
        requested=list(inputs) if h==0 else [sum(w*y for w,y in zip(qs[i].r42_weights,before[i]))%P for i in range(N)]
        issued=[]; intentions=[]
        for i,q in enumerate(qs):
            intentions.append(q.add('R42_intention',{'kind':kind,'horizon':h, 'observed':before[i],
                'requested':requested[i], 'policy':'external_local_pulse' if h==0 else 'fixed_linear_response',
                'local_weights':None if h==0 else list(qs[i].r42_weights)}))
            issued.append(q._emit(requested[i]))
        after=world.step(issued); evidence=[]
        for i,q in enumerate(qs):
            evidence.append(q.add('R42_receipt',{'intention':intentions[i],'issued':issued[i],
                'before':before[i], 'after':after[i]},refs=(intentions[i],)))
        steps.append({'before':before, 'requested':requested, 'issued':issued, 'after':after,
                      'intentions':intentions, 'receipts':evidence})
    return {'kind':kind,'initial_input':list(inputs),'steps':steps}

def collect(qs, world, kind='calibration'):
    rows=[trial(qs,world,[0,0,0],kind=kind)]
    for i in range(N):
        u=[0]*N; u[i]=1; rows.append(trial(qs,world,u,kind=kind))
    return rows

def infer(rows, witnesses=(0,1,2), min_witnesses=2):
    """Numeric learner: does not accept true owner, true gains, weights or source labels.
    Columns refer to requested intervention capabilities, not pre-labelled bodies.
    """
    require(len(rows)==4,'four protocol trials required')
    expect=[[0,0,0],[1,0,0],[0,1,0],[0,0,1]]
    require([r['initial_input'] for r in rows]==expect,'unmatched intervention protocol')
    require(all(len(r['steps'])>=3 for r in rows),'missing feedback horizons')
    require(all(r['steps'][0]['before']==rows[0]['steps'][0]['before'] for r in rows),'unmatched reset observations')
    require(all(r['steps'][0]['issued']==r['initial_input'] for r in rows),'identity emitter outside scope')
    require(len(set(witnesses))==len(witnesses),'duplicate witness handles do not add evidence')
    fingerprints={}; assignments={}; candidates={i:[] for i in range(N)}
    for w in witnesses:
        require(type(w)is int and 0<=w<N,'unknown witness')
        for slot in range(len(rows[0]['steps'][0]['after'][w])):
            fp=[(rows[i+1]['steps'][0]['after'][w][slot]-rows[0]['steps'][0]['after'][w][slot])%P for i in range(N)]
            nonzero=[i for i,x in enumerate(fp) if x]
            require(len(nonzero)==1,'UNKNOWN: direct origin not uniquely witnessed')
            origin=nonzero[0]; candidates[origin].append((w,slot))
            assignments[f'{w}:{slot}']=origin; fingerprints[f'{w}:{slot}']=fp
    require(all(len(candidates[i])>=min_witnesses for i in range(N)),'UNKNOWN: full two-witness protocol unavailable')
    H=[]
    for h in range(3):
        mat=[[0]*N for _ in range(N)]
        for target in range(N):
            for source in range(N):
                vals=[(rows[source+1]['steps'][h]['after'][w][k]-rows[0]['steps'][h]['after'][w][k])%P
                      for w,k in candidates[target]]
                require(len(set(vals))==1,'witness disagreement')
                mat[target][source]=vals[0]
        H.append(mat)
    require(all(H[0][i][j]==0 for i in range(N) for j in range(N) if i!=j),'nonlocal direct actuator')
    gains=[H[0][i][i] for i in range(N)]
    require(all(gains),'singular actuator')
    F=[[H[1][i][j]*pow(gains[j],-1,P)%P for j in range(N)] for i in range(N)]
    require(mm(F,H[1])==H[2],'finite affine closure contradicted')
    return {'H':H,'gains':gains,'F':F,'assignments':assignments,'fingerprints':fingerprints,
            'scope':'stationary affine feedback; calibrated channels; four trials; no subjective identity'}

@dataclass
class Model:
    q: object
    numeric: dict
    license: int
    payload_hash: str
    root: int
    upstream: tuple=()
    bound: object=None
    def require(self):
        if self.license in self.q.ledger.invalid:
            raise PermissionError('withdrawn relational model')
        for peer,ref,body_hash in self.upstream:
            self.q.cost['r42_source_guard_checks']+=1
            if ref in peer.ledger.invalid or digest(peer.ledger.records[ref].body)!=body_hash:
                self.q.ledger.revoke(self.license,'upstream peer observation withdrawn or changed')
                raise PermissionError('upstream peer evidence invalid')
        if getattr(self.q,'r42_plan',None) is not self.bound or digest(self.numeric)!=self.payload_hash:
            raise PermissionError('changed model or plan binding')
    def plan(self, delta):
        self.require(); require(type(delta)is int and 0<=delta<P,'invalid goal')
        h=self.numeric['H'][2][self.root][self.root]
        if h:
            return delta*pow(h,-1,P)%P
        return 0 if delta==0 else None

def install(q, rows, root, peers):
    data=infer(rows)
    supports=[]; upstream=[]
    # Receiving evidence is explicit. This is not trusted merely because someone says "I".
    for tr in rows:
        for horizon,st in enumerate(tr['steps']):
            own=st['receipts'][root]
            require(own not in q.ledger.invalid,'own receipt withdrawn')
            supports.append(own)
            for witness,peer in enumerate(peers):
                ref=st['receipts'][witness]
                payload=peer.read(ref)
                require(payload['after']==st['after'][witness],'forwarded source payload mismatch')
                upstream.append((peer,ref,digest(peer.ledger.records[ref].body)))
            supports.append(q.add('R42_peer_packet',{'initial_input':tr['initial_input'],
                'horizon':horizon,'views':st['after'],
                'upstream_receipts':st['receipts'],'witness_reliability':'assumed calibrated; common-mode failure tested'},deps=(own,)))
    license=q.add('R42_relational_model',data,deps=tuple(supports))
    model=Model(q,data,license,digest(data),root,tuple(upstream))
    model.bound=model.plan; q.r42_plan=model.bound
    return model,supports

def difference(row, baseline, numeric, h):
    """Decode actual witnessed effects using learned origin-to-local-channel map."""
    pairs={i:[] for i in range(N)}
    for key,i in numeric['assignments'].items():
        w,k=map(int,key.split(':'))
        pairs[i].append((row['steps'][h]['after'][w][k]-baseline['steps'][h]['after'][w][k])%P)
    require(all(len(set(v))==1 for v in pairs.values()),'audit views disagree')
    return [v[0] for _,v in sorted(pairs.items())]

def predicted(numeric,u,h):
    z=mv(numeric['H'][0],u)
    for _ in range(h):
        z=mv(numeric['F'],z)
    return z

def checks(qs,world,numeric,seed,exhaustive=False):
    rng=Random(seed)
    vectors=list(product(range(P),repeat=N)) if exhaustive else [tuple(rng.randrange(P) for _ in range(N)) for _ in range(32)]
    baseline=trial(qs,world,[0,0,0],horizons=5,kind='heldout_baseline')
    rows=[]; correct=0; total=0
    for j,u in enumerate(vectors):
        horizon=5 if j<4 else 2
        row=trial(qs,world,list(u),horizons=horizon,kind='heldout')
        flags=[difference(row,baseline,numeric,h)==predicted(numeric,u,h) for h in range(horizon+1)]
        correct+=sum(flags);total+=len(flags);rows.append({'trial':row,'flags':flags})
    return {'baseline':baseline,'rows':rows,'correct':correct,'total':total,'exhaustive_initial_pulses':exhaustive}

def goals(qs,world,models,baseline,kind='live_goal'):
    out=[]
    for root in range(N):
        for delta in range(P):
            action=qs[root].r42_plan(delta)
            htrue=models[root].numeric['H'][2][root][root]
            if action is None:
                out.append({'root':root,'delta':delta,'action':None,'correct':htrue==0 and delta!=0,'trial':None})
            else:
                u=[0]*N;u[root]=action;row=trial(qs,world,u,kind=kind)
                effect=difference(row,baseline,models[root].numeric,2)[root]
                out.append({'root':root,'delta':delta,'action':action,'effect':effect,'correct':effect==delta,'trial':row})
    return out

def root_gain_plans(numeric,root):
    h=numeric['H'][2][root][root]
    return [d*pow(h,-1,P)%P if h else (0 if d==0 else None) for d in range(P)]

def episode(seed,exhaustive=False):
    spec=fixture(seed); w=World(spec); qs=queens(seed); ids=[(id(q),id(q.ledger)) for q in qs]
    phases=[]
    cal0=collect(qs,w)
    models=[]; supports=[]
    for root,q in enumerate(qs):
        m,sp=install(q,cal0,root,qs);models.append(m);supports.append(sp)
    num0=deepcopy(models[0].numeric)
    # A local observer is self-blind, even while all peers are active observers.
    local=[]
    for root in range(N):
        try: infer(cal0,(root,)); local.append(False)
        except ValueError: local.append(True)
    flat_equal=infer(json.loads(canonical(cal0)))==num0
    audit0=checks(qs,w,num0,seed^123450,exhaustive)
    goal0=goals(qs,w,models,cal0[0])
    phases.append({'calibration':cal0,'models':[{'numeric':m.numeric,'license':m.license,'hash':m.payload_hash,'supports':s} for m,s in zip(models,supports)],
        'heldout':audit0,'goals':goal0})
    # Controlled change to a peer policy, not to a learner's motor or proprioception.
    before_weights=deepcopy(w.spec['weights']); w.spec['weights'][1][0]=0
    qs[1].r42_weights=tuple(w.spec['weights'][1])
    cal1=collect(qs,w,kind='post_change_probe')
    num1=infer(cal1)
    old_plans=[root_gain_plans(num0,i) for i in range(N)]
    stale=[]
    # No automatic knowledge of drift: old licenses revoked only after contradictory observations.
    detected=num0['H']!=num1['H']
    for q,m in zip(qs,models):
        if detected:q.ledger.revoke(m.license,'new witnessed response contradicts old relation, motor may be unchanged')
    old_block=[]
    for q in qs:
        try:q.r42_plan(1);old_block.append(False)
        except PermissionError:old_block.append(True)
    models1=[];supports1=[]
    for root,q in enumerate(qs):
        m,s=install(q,cal1,root,qs);models1.append(m);supports1.append(s)
    for root in range(N):
        for delta,act in enumerate(old_plans[root]):
            h=num1['H'][2][root][root]
            if act is None:
                stale.append({'root':root,'delta':delta,'action':None,'correct':h==0 and delta!=0,'trial':None})
            else:
                u=[0]*N;u[root]=act;tr=trial(qs,w,u,kind='stale_model_goal')
                eff=difference(tr,cal1[0],num1,2)[root]
                stale.append({'root':root,'delta':delta,'action':act,'effect':eff,'correct':eff==delta,'trial':tr})
    audit1=checks(qs,w,num1,seed^678901,exhaustive)
    goal1=goals(qs,w,models1,cal1[0])
    phases.append({'calibration':cal1,'models':[{'numeric':m.numeric,'license':m.license,'hash':m.payload_hash,'supports':s} for m,s in zip(models1,supports1)],
        'heldout':audit1,'goals':goal1,'stale_goals':stale,'old_license_blocked':old_block,
        'evaluator_change':{'before':before_weights,'after':deepcopy(w.spec['weights'])}})
    # Withdraw ONE real peer observation; all dependent plan entries check upstream validity.
    withdrawal=[]
    source_owner=1; evidence=cal1[1]['steps'][0]['receipts'][source_owner]
    body=qs[source_owner].ledger.records[evidence].body
    qs[source_owner].ledger.revoke(evidence,'R42 source observation withdrawal challenge')
    for i,(q,m,sp) in enumerate(zip(qs,models1,supports1)):
        before=w.microsteps; blocked=False
        try:q.r42_plan(1)
        except PermissionError:blocked=True
        history_target=evidence if i==source_owner else sp[1]
        ref=q.add('R42_history_retained',{'old_model':m.license},refs=(history_target,))
        withdrawal.append({'root':i,'source_owner':source_owner,'evidence':evidence,'old_license':m.license,'blocked':blocked,
            'world_unchanged':w.microsteps==before,'body_preserved':qs[source_owner].ledger.records[evidence].body==body,
            'history_ref':ref,'history_valid':ref not in q.ledger.invalid})
    restore_cal=collect(qs,w,kind='restoration_probe'); restored=[]
    for i,q in enumerate(qs):
        m,sp=install(q,restore_cal,i,qs)
        restored.append({'root':i,'numeric_equal':m.numeric==num1,'old_stays_invalid':models1[i].license in q.ledger.invalid,
            'license':m.license,'plans':root_gain_plans(m.numeric,i)})
    # Fixed replay witnesses and a single inconsistent observer must not count as fresh grounding.
    tape=deepcopy(cal0)
    for row in tape[1:]:
        for h,st in enumerate(row['steps']):st['after']=deepcopy(cal0[0]['steps'][h]['after'])
    tape_refused=False
    try:infer(tape)
    except ValueError:tape_refused=True
    inconsistent=deepcopy(cal0)
    # Alter one of the two corroborating reports, with origin still unchanged.
    key=next(k for k,v in num0['assignments'].items() if v==0); obs,slot=map(int,key.split(':'))
    val=num0['gains'][0]; replacement=1 if val!=1 else 2
    baseline=inconsistent[0]['steps'][0]['after'][obs][slot]
    inconsistent[1]['steps'][0]['after'][obs][slot]=(baseline+replacement)%P
    disagreed=False
    try:infer(inconsistent)
    except ValueError:disagreed=True
    summary={'seed':seed,'heldout_correct':audit0['correct']+audit1['correct'],'heldout_total':audit0['total']+audit1['total'],
        'live_goal_correct':sum(g['correct'] for g in goal0+goal1),'live_goal_total':42,
        'post_goal_correct':sum(g['correct'] for g in goal1),'stale_goal_correct':sum(g['correct'] for g in stale),
        'goal_refusals':sum(g['action'] is None for g in goal0+goal1),
        'local_full_models_refused':sum(local),'flat_equal':flat_equal,'same_motors':num0['gains']==num1['gains'],
        'changed_feedback':num0['F']!=num1['F'],'changed_self_horizon2':sum(num0['H'][2][i][i]!=num1['H'][2][i][i] for i in range(N)),
        'withdrawals_pass':all(r['blocked'] and r['world_unchanged'] and r['body_preserved'] and r['history_valid'] for r in withdrawal),
        'restoration_pass':all(r['numeric_equal'] and r['old_stays_invalid'] for r in restored),'tape_refused':tape_refused,
        'disagreement_refused':disagreed,'same_actors_ledgers':ids==[(id(q),id(q.ledger)) for q in qs],
        'actual_microsteps':w.microsteps,'sensor_scalar_reads':w.read_scalars,'resets':w.resets,
        'ledger_reads':sum(q.cost.get('actual_record_reads',0) for q in qs),
        'guard_source_checks':sum(q.cost.get('r42_source_guard_checks',0) for q in qs),
        'not_RSI':True}
    return {'stage':'R42','seed':seed,'fixture_evaluator_only':spec,'phases':phases,'withdrawal':withdrawal,
        'restore_calibration':restore_cal,'restored':restored,'summary':summary,
        'runtime_costs':[dict(q.cost) for q in qs],'ledgers':[q.ledger.export() for q in qs],'invalid':[sorted(q.ledger.invalid) for q in qs]}

def common_mode_negative(seed):
    """Counterexample outside the calibrated-channel assumption. Agreeing witnesses can be wrong."""
    spec=fixture(seed);spec['weights']=[[0,0] for _ in range(N)]
    target=spec['owner'][0]
    for i,slots in enumerate(spec['slots']):
        for k,j in enumerate(slots):
            if j==target:spec['scales'][i][k]=2
    qs=queens(seed,spec['weights']); w=World(spec); cal=collect(qs,w); num=infer(cal)
    m,_=install(qs[0],cal,0,qs)
    goals_out=[]
    for d in range(P):
        a=qs[0].r42_plan(d);u=[a,0,0];tr=trial(qs,w,u,kind='common_mode_goal')
        sensed=difference(tr,cal[0],num,2)[0]
        physical=spec['gains'][0]*a%P
        goals_out.append({'delta':d,'action':a,'witnessed_effect':sensed,'physical_effect_evaluator_only':physical,
                          'trial':tr,'witness_success':sensed==d,'physical_success':physical==d})
    return {'stage':'R42_negative','seed':seed,'fixture_evaluator_only':spec,'calibration':cal,'numeric':num,'goals':goals_out,
        'summary':{'witness_successes':sum(x['witness_success'] for x in goals_out),'physical_successes':sum(x['physical_success'] for x in goals_out),
         'detected_from_witness_disagreement':False,'scope_violation':'common-mode sensor scale; declared calibrated units violated'},
         'ledgers':[q.ledger.export() for q in qs]}

def rename_check(seed):
    spec=fixture(seed); rows=collect(queens(seed),World(spec)); expected=digest([semantic_trial(x) for x in rows]);out=[]
    for perm in permutations(range(N)):
        f=deepcopy(spec)
        f['owner']=[perm[v] for v in spec['owner']]
        f['slots']=[[perm[v] for v in sl] for sl in spec['slots']]
        for old,new in enumerate(perm):f['start'][new]=spec['start'][old]
        rs=collect(queens(seed),World(f))
        got=digest([semantic_trial(x) for x in rs])
        out.append({'permutation':list(perm),'semantic_hash':got,'equal':got==expected,'calibration':rs})
    return {'seed':seed,'fixture_evaluator_only':spec,'expected':expected,'checks':out}


def full_sensor_control(seed):
    """Explicit sensor-equipment control: each actor additionally sees its own motor stream.
    No peer reports are supplied to each solo inference. Extra sensor costs are separate.
    """
    spec=fixture(seed)
    for i in range(N):
        spec['slots'][i].append(spec['owner'][i]);spec['offsets'][i].append(0)
        spec['scales'][i].append(1);spec['weights'][i].append(0)
    qs=queens(seed,spec['weights']);world=World(spec);cal=collect(qs,world)
    inferred=[infer(cal,(i,),min_witnesses=1) for i in range(N)]
    return {'seed':seed,'fixture_evaluator_only':spec,'calibration':cal,'solo_models':inferred,
            'sensor_scalar_reads':world.read_scalars,'microsteps':world.microsteps}


def synchrony_counterexample():
    """All six possible motor-to-visible-stream routings fit the same synchronized data.
    A unilateral pulse distinguishes the first actor's three possible controlled streams.
    """
    entries=[]
    for owner in permutations(range(N)):
        f={'seed':0,'owner':list(owner),'slots':[[0,1,2] for _ in range(N)],
           'offsets':[[0,0,0] for _ in range(N)],'scales':[[1,1,1] for _ in range(N)],
           'weights':[[0,0,0] for _ in range(N)],'gains':[1,1,1],'start':[0,0,0]}
        qs=queens(0,f['weights']);world=World(f)
        observational=[trial(qs,world,[v,v,v],kind='synchronous') for v in range(P)]
        intervention=trial(qs,world,[1,0,0],kind='private_pulse')
        entries.append({'fixture_evaluator_only':f,'observational':observational,
            'observational_hash':digest([semantic_trial(t) for t in observational]),
            'intervention':intervention,'intervention_hash':digest(semantic_trial(intervention))})
    return {'cases':entries,'same_observational_stream':len({e['observational_hash'] for e in entries})==1,
            'different_private_pulse_streams':len({e['intervention_hash'] for e in entries}),
            'equally_likely_origin_bound':'1/3 under a uniform prior over the six routings, not a consciousness probability'}
