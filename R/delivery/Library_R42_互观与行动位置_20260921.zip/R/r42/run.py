"""Bounded foreground runner. No networking, subprocesses, credentials, or self-replication."""
from pathlib import Path
from hashlib import sha256
import argparse, json, lzma, time
import core, audit
ROOT=Path(__file__).resolve().parent
SEEDS={'A':list(range(105100,105164)),'B':list(range(106100,106164))}
NEGATIVE={'A':list(range(105900,105908)),'B':list(range(106900,106908))}

def check_frozen():
    p=ROOT/'FROZEN.json';f=json.loads(p.read_text())
    for path,expected in f['sha256'].items():
        if sha256((ROOT/path).read_bytes()).hexdigest()!=expected:raise RuntimeError('frozen mismatch: '+path)
    return sha256(p.read_bytes()).hexdigest()

def save(name,result,verify,frozen,seconds):
    path=ROOT/'results'/name;path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():raise FileExistsError('immutable result already present: '+str(path))
    raw=(core.canonical(result)+'\n').encode();compressed=lzma.compress(raw,preset=3)
    receipt={'name':name,'raw_sha256':sha256(raw).hexdigest(),'xz_sha256':sha256(compressed).hexdigest(),
        'raw_bytes':len(raw),'xz_bytes':len(compressed),'frozen_sha256':frozen,'seconds':seconds}
    with path.open('xb') as f:f.write(compressed)
    path.with_suffix('.receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    parsed=json.loads(raw);review=verify(parsed)
    review['raw_sha256']=receipt['raw_sha256'];review['xz_sha256']=receipt['xz_sha256']
    path.with_suffix('.audit.json').write_text(json.dumps(review,indent=2)+'\n')
    return receipt

def run(batch,start,end):
    freeze=check_frozen()
    for j in range(start,end):
        seed=SEEDS[batch][j];t=time.perf_counter();result=core.episode(seed,exhaustive=j<4)
        save(f'{batch}/{seed}.json.xz',result,audit.validate_episode,freeze,time.perf_counter()-t)
        print(batch,seed,result['summary']['heldout_correct'],result['summary']['post_goal_correct'],result['summary']['stale_goal_correct'],flush=True)
    check_frozen()

def auxiliary():
    freeze=check_frozen()
    for batch in SEEDS:
        for seed in NEGATIVE[batch]:
            t=time.perf_counter();r=core.common_mode_negative(seed)
            save(f'negative/{seed}.json.xz',r,audit.validate_negative,freeze,time.perf_counter()-t)
        for seed in SEEDS[batch][:8]:
            t=time.perf_counter();r=core.full_sensor_control(seed)
            save(f'solo/{seed}.json.xz',r,audit.validate_full_sensor,freeze,time.perf_counter()-t)
            t=time.perf_counter();r=core.rename_check(seed)
            save(f'rename/{seed}.json.xz',r,audit.validate_rename,freeze,time.perf_counter()-t)
    t=time.perf_counter();r=core.synchrony_counterexample()
    save('synchrony/finite_counterexample.json.xz',r,audit.validate_synchrony,freeze,time.perf_counter()-t)
    check_frozen()

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('batch',choices=['A','B','aux']);p.add_argument('--start',type=int,default=0);p.add_argument('--end',type=int,default=64)
    a=p.parse_args()
    if a.batch=='aux':auxiliary()
    else:
        if not 0<=a.start<=a.end<=64:raise ValueError('bad finite range')
        run(a.batch,a.start,a.end)
