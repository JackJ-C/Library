"""Post-formal exact examples and live restoration checks, kept separate from A/B.
The guard is an additive repair; published formal results remain unchanged.
"""
import json,sys,lzma,hashlib,unittest
from pathlib import Path
from itertools import permutations
from copy import deepcopy
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import core,audit
from guarded_witnesses import infer_distinct,install_distinct
ROOT=Path(__file__).resolve().parents[1]

def packet_audit(r):
    """Additional read-only source-to-license linkage checks, no learner call."""
    parsed=[audit.validate_ledger(rows)[0] for rows in r['ledgers']]
    total=0
    for phase in r['phases']:
        for root,model in enumerate(phase['models']):
            deps=r['ledgers'][root][model['license']]['deps']
            if len(deps)!=24:raise ValueError('two local dependencies per micro-observation')
            for n,step in enumerate(st for tr in phase['calibration'] for st in tr['steps']):
                own,pkt=deps[n*2:n*2+2]
                if own!=step['receipts'][root]:raise ValueError('wrong local source dependency')
                body=parsed[root][pkt]
                if body['views']!=step['after'] or body['upstream_receipts']!=step['receipts']:
                    raise ValueError('forwarded views differ from actual sources')
                if list(r['ledgers'][root][pkt]['deps'])!=[own]:raise ValueError('packet local support')
                total+=1
    return total

def live_restore(seed):
    f=core.fixture(seed);world=core.World(f);qs=core.queens(seed)
    ids=[(id(q),id(q.ledger)) for q in qs]
    cal=core.collect(qs,world);models=[install_distinct(q,cal,i,qs)[0] for i,q in enumerate(qs)]
    source=cal[1]['steps'][0]['receipts'][1];qs[1].ledger.revoke(source,'post-formal restoration challenge')
    stopped=[]
    for q in qs:
        try:q.r42_plan(1);stopped.append(False)
        except PermissionError:stopped.append(True)
    newcal=core.collect(qs,world,kind='supplement_fresh_evidence')
    newmodels=[install_distinct(q,newcal,i,qs)[0] for i,q in enumerate(qs)]
    actual=core.goals(qs,world,newmodels,newcal[0],kind='supplement_restored_entry')
    ledgers=[q.ledger.export() for q in qs];parsed=[audit.validate_ledger(l)[0] for l in ledgers]
    for trial in cal+newcal:audit.check_trial(f,trial,parsed)
    num=audit.rebuild_from_views(newcal);baseline=audit.check_trial(f,newcal[0],parsed)
    passed=sum(audit.check_goal(f,g,num,baseline,parsed) for g in actual)
    if not all(stopped) or passed!=21 or not all(m.license in q.ledger.invalid for m,q in zip(models,qs)):
        raise ValueError('restoration failed')
    if ids!=[(id(q),id(q.ledger)) for q in qs]:raise ValueError('object replaced')
    return {'seed':seed,'fixture_evaluator_only':f,'old_calibration':cal,'new_calibration':newcal,'source':source,
        'blocked':stopped,'goals':actual,'correct_decisions':passed,
        'executed_goal_successes':sum(g['action'] is not None and g['correct'] for g in actual),
        'ledgers':ledgers,'old_licenses':[m.license for m in models],'new_licenses':[m.license for m in newmodels],
        'same_instances':True,'classification':'post-formal execution coverage; not additional independent worlds'}

def duplicate_case():
    r=core.full_sensor_control(0);rows=deepcopy(r['calibration'])
    for tr in rows:
        for st in tr['steps']:
            for field in ('before','after'):st[field][0]=st[field][0]+st[field][0]
    original=core.infer(rows,(0,),2)
    blocked=False
    try:infer_distinct(rows,(0,),2)
    except ValueError:blocked=True
    if not blocked:raise ValueError('new guard did not stop duplicate')
    return {'calibration':rows,'original_accepted':True,'original_numeric':original,'distinct_observers_per_origin':[1,1,1],
        'new_guard_refused':blocked,'scope':'malformed duplicated full-sensor channels; not a formal two-slot main fixture'}

class SupplementTests(unittest.TestCase):
    def test_duplicate_counterexample(self):self.assertTrue(duplicate_case()['new_guard_refused'])
    def test_standard_unchanged(self):
        qs=core.queens(0);cal=core.collect(qs,core.World(core.fixture(0)))
        self.assertEqual(core.infer(cal),infer_distinct(cal))
    def test_solo_explicit(self):
        r=core.full_sensor_control(1)
        self.assertEqual(core.infer(r['calibration'],(1,),1),infer_distinct(r['calibration'],(1,),1))
    def test_same_peer_twice(self):
        qs=core.queens(0);cal=core.collect(qs,core.World(core.fixture(0)))
        with self.assertRaises(ValueError):install_distinct(qs[0],cal,0,[qs[0],qs[1],qs[1]])
    def test_wrong_root(self):
        qs=core.queens(0);cal=core.collect(qs,core.World(core.fixture(0)))
        with self.assertRaises(ValueError):install_distinct(qs[1],cal,0,qs)
    def test_live_restore(self):self.assertEqual(live_restore(0)['correct_decisions'],21)
    def test_no_unrooted_vertex(self):
        perms=list(permutations(range(3)))
        self.assertEqual([v for v in range(3) if all(p[v]==v for p in perms)],[])
        self.assertEqual(len([p for p in perms if p[0]==0]),2)
    def test_source_packet_corruption(self):
        r=json.loads(core.canonical(core.episode(0)))
        model=r['phases'][0]['models'][0];packet=model['supports'][1]
        value=json.loads(r['ledgers'][0][packet]['body']);value['views'][0][0]^=1
        r['ledgers'][0][packet]['body']=json.dumps(value)
        with self.assertRaises(ValueError):packet_audit(r)

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='run':
        out=ROOT/'supplement/results';out.mkdir(parents=True,exist_ok=True)
        links=0;recorded=[]
        for batch,start in [('A',105100),('B',106100)]:
            for seed in range(start,start+64):
                r=json.loads(lzma.decompress((ROOT/'results'/batch/f'{seed}.json.xz').read_bytes()))
                links+=packet_audit(r)
                for p in r['phases']:
                    if infer_distinct(p['calibration'])!=p['models'][0]['numeric']:raise ValueError('guard altered formal numeric')
            for seed in (start,start+63):
                r=live_restore(seed);raw=(core.canonical(r)+'\n').encode();p=out/f'live_restore_{seed}.json.xz'
                with p.open('xb') as h:h.write(lzma.compress(raw,preset=3))
                recorded.append({'seed':seed,'sha256':hashlib.sha256(raw).hexdigest(),'xz_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'decisions':21,'executed':r['executed_goal_successes']})
        (out/'DUPLICATED_CHANNEL_COUNTEREXAMPLE.json').write_text(json.dumps(duplicate_case(),indent=2)+'\n')
        group=list(permutations(range(3)))
        (out/'SUMMARY.json').write_text(json.dumps({'stage':'R42 post-formal supplement','new_guard_preserves_all_formal_models':True,
            'formal_source_packets_checked':links,'formal_worlds':128,'restored_live_entries':recorded,'new_independent_worlds':0,
            'automorphisms_symmetric_three_node_world':len(group),'vertices_fixed_by_all':[],
            'root_zero_stabilizer':len([p for p in group if p[0]==0]),'original_frozen_code_unchanged':True},indent=2)+'\n')
        print('supplement source packets',links,'live restoration records',len(recorded))
    else:unittest.main(verbosity=2)
