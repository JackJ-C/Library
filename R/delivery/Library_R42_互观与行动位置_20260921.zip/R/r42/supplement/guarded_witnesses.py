"""R42 post-formal guard supplement. Does not replace frozen core.infer/install.
The original function counts channels; this wrapper counts distinct observer handles.
Trusted observer-handle identity is still a declared assumption, not anti-Sybil security.
"""
import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import core

def infer_distinct(rows,witnesses=(0,1,2),min_witnesses=2):
    numeric=core.infer(rows,witnesses,min_witnesses)
    observers={i:set() for i in range(core.N)}
    for key,origin in numeric['assignments'].items():
        observers[origin].add(int(key.split(':')[0]))
    if any(len(ids)<min_witnesses for ids in observers.values()):
        raise ValueError('duplicate channels do not create independent observer handles')
    return numeric

def install_distinct(q,rows,root,peers):
    if len(peers)!=3 or len({id(p) for p in peers})!=3 or len({id(p.ledger) for p in peers})!=3:
        raise ValueError('distinct actor and ledger handles required')
    if q is not peers[root]:
        raise ValueError('root does not match receiving action capability')
    expected=infer_distinct(rows)
    model,supports=core.install(q,rows,root,peers)
    if model.numeric!=expected:raise RuntimeError('numeric wrapper mismatch')
    return model,supports
