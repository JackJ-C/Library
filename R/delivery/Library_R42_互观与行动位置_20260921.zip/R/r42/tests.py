"""Development and mutation tests. Same suite under regular Python and -O."""
import unittest, json, inspect
from copy import deepcopy
import core, audit

class StudyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.f=core.fixture(0);cls.q=core.queens(0);cls.w=core.World(cls.f)
        cls.cal=core.collect(cls.q,cls.w);cls.num=core.infer(cls.cal)
        cls.raw=json.loads(core.canonical(core.episode(0)))
    def test_01_route_bijection(self):self.assertEqual(sorted(self.f['owner']),[0,1,2])
    def test_02_no_self_visible(self):
        for i in range(3):self.assertNotIn(self.f['owner'][i],self.f['slots'][i])
    def test_03_same_inherited_class(self):self.assertEqual(len({type(q) for q in self.q}),1)
    def test_04_no_gold_in_learner_signature(self):self.assertEqual(list(inspect.signature(core.infer).parameters),['rows','witnesses','min_witnesses'])
    def test_05_gains_inferred(self):self.assertEqual(self.num['gains'],self.f['gains'])
    def test_06_direct_diagonal(self):
        for i in range(3):
            for j in range(3):self.assertEqual(self.num['H'][0][i][j],self.f['gains'][i] if i==j else 0)
    def test_07_closure(self):self.assertEqual(core.mm(self.num['F'],self.num['H'][1]),self.num['H'][2])
    def test_08_independent_episode(self):self.assertEqual(audit.validate_episode(self.raw)['status'],'PASS')
    def test_09_independent_negative(self):self.assertEqual(audit.validate_negative(core.common_mode_negative(0))['physical_successes'],1)
    def test_10_local_full_sensor(self):self.assertEqual(audit.validate_full_sensor(core.full_sensor_control(0))['solo_models'],3)
    def test_11_all_relabels(self):self.assertEqual(audit.validate_rename(core.rename_check(0))['renamings'],6)
    def test_12_synchrony(self):self.assertEqual(audit.validate_synchrony(core.synchrony_counterexample())['private_pulse_classes'],3)
    def test_13_plain_same_information(self):self.assertEqual(core.infer(json.loads(core.canonical(self.cal))),self.num)
    def test_14_duplicate_witness(self):
        with self.assertRaises(ValueError):core.infer(self.cal,(0,0,1))
    def test_15_missing_probe(self):
        with self.assertRaises(ValueError):core.infer(self.cal[:3])
    def test_16_pulse_label_corruption(self):
        r=deepcopy(self.cal);r[1]['initial_input']=[0,1,0]
        with self.assertRaises(ValueError):core.infer(r)
    def test_17_inconsistent_observer(self):
        r=deepcopy(self.cal);key=next(k for k,v in self.num['assignments'].items() if v==0);w,s=map(int,key.split(':'))
        r[1]['steps'][1]['after'][w][s]=(r[1]['steps'][1]['after'][w][s]+1)%7
        with self.assertRaises(ValueError):core.infer(r)
    def test_18_replay(self):
        r=deepcopy(self.cal)
        for t in r[1:]:
            for h,step in enumerate(t['steps']):step['after']=deepcopy(r[0]['steps'][h]['after'])
        with self.assertRaises(ValueError):core.infer(r)
    def test_19_no_feedback(self):
        f=core.fixture(1);f['weights']=[[0,0]]*3;q=core.queens(1,f['weights'])
        m=core.infer(core.collect(q,core.World(f)));self.assertEqual(m['H'][0],m['H'][2])
    def test_20_unreachable_not_failure(self):
        f=core.fixture(1);f['gains']=[1,1,1];k=[[0,1,1],[3,0,1],[3,1,0]]
        f['weights']=[[k[i][f['owner'].index(j)] for j in f['slots'][i]] for i in range(3)]
        q=core.queens(1,f['weights']);cal=core.collect(q,core.World(f));m,_=core.install(q[0],cal,0,q)
        self.assertEqual(m.plan(0),0);self.assertIsNone(m.plan(1))
    def test_21_source_revocation(self):
        q=core.queens(2);cal=core.collect(q,core.World(core.fixture(2)));m,_=core.install(q[0],cal,0,q)
        q[1].ledger.revoke(cal[1]['steps'][0]['receipts'][1],'test')
        with self.assertRaises(PermissionError):q[0].r42_plan(1)
        self.assertIn(m.license,q[0].ledger.invalid)
    def test_22_numeric_mutation(self):
        q=core.queens(2);cal=core.collect(q,core.World(core.fixture(2)));m,_=core.install(q[0],cal,0,q)
        m.numeric['gains'][0]=(m.numeric['gains'][0]+1)%7
        with self.assertRaises(PermissionError):q[0].r42_plan(1)
    def test_23_binding_mutation(self):
        q=core.queens(2);cal=core.collect(q,core.World(core.fixture(2)));m,_=core.install(q[0],cal,0,q)
        q[0].r42_plan=lambda _:0
        with self.assertRaises(PermissionError):m.plan(1)
    def test_24_invalid_goal(self):
        q=core.queens(2);cal=core.collect(q,core.World(core.fixture(2)));m,_=core.install(q[0],cal,0,q)
        with self.assertRaises(ValueError):m.plan(7)
    def test_25_negative_corrupted_summary(self):
        r=core.common_mode_negative(1);r['summary']['physical_successes']=7
        with self.assertRaises(ValueError):audit.validate_negative(r)
    def test_26_bad_ledger(self):
        r=deepcopy(self.raw);r['ledgers'][0][3]['seq']=999
        with self.assertRaises(ValueError):audit.validate_episode(r)
    def test_27_bad_after(self):
        r=deepcopy(self.raw);r['phases'][0]['calibration'][0]['steps'][0]['after'][0][0]^=1
        with self.assertRaises(ValueError):audit.validate_episode(r)
    def test_28_bad_fixture(self):
        r=deepcopy(self.raw);r['fixture_evaluator_only']['gains'][0]=7
        with self.assertRaises(ValueError):audit.validate_episode(r)
    def test_29_bad_model(self):
        r=deepcopy(self.raw);r['phases'][0]['models'][0]['numeric']['F'][0][1]^=1
        with self.assertRaises(ValueError):audit.validate_episode(r)
    def test_30_bad_summary(self):
        r=deepcopy(self.raw);r['summary']['stale_goal_correct']=21
        with self.assertRaises(ValueError):audit.validate_episode(r)
    def test_31_two_endpoints(self):self.assertEqual(self.raw['summary']['changed_self_horizon2'],2)
    def test_32_zero_gains(self):
        r=deepcopy(self.cal)
        for t in r[1:]:t['steps'][0]['after']=deepcopy(r[0]['steps'][0]['after'])
        with self.assertRaises(ValueError):core.infer(r)
    def test_33_missing_horizon(self):
        r=deepcopy(self.cal);r[3]['steps']=r[3]['steps'][:1]
        with self.assertRaises(ValueError):core.infer(r)
    def test_34_reset_not_matched(self):
        r=deepcopy(self.cal);r[3]['steps'][0]['before'][0][0]^=1
        with self.assertRaises(ValueError):core.infer(r)
    def test_35_emitter_changed(self):
        r=deepcopy(self.cal);r[3]['steps'][0]['issued'][2]=2
        with self.assertRaises(ValueError):core.infer(r)
    def test_36_five_feedback_rounds(self):
        for p in self.raw['phases']:
            self.assertEqual(len(p['heldout']['rows'][0]['flags']),6)
            self.assertTrue(all(p['heldout']['rows'][0]['flags']))

if __name__=='__main__':unittest.main(verbosity=2)
