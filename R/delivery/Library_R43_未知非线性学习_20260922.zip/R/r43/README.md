# R43：可重放交付入口

阅读顺序：REPORT.md → THEORY.md → PROTOCOL.md → ERRATA_AND_SCOPE.md → results/PUBLIC_SUMMARY.json。旧R37参考文件在reference/，未改原字节。本期所有路径仅在R/r43/内。

## 隔离解压后验证

以下命令在解压目录的R/下运行，使用Python 3.13（正式回执记录具体版本）。仅标准库，无网络、模型API或付费计算依赖。

```bash
python -m r43.tests
python -O -m r43.tests
python -c 'from r43.run import check_frozen; print(check_frozen())'
python -m r43.audit r43/results/A/113100.json.xz
```

`python -m r43.analyze`会根据已保存原档和回执重新写入两份派生汇总，运行前可先复制到新的检查目录。原XZ不会被该命令改写。supplement/下脚本是冻结后独立覆盖审查，亦只读正式XZ、生成派生诊断；不作为额外独立样本。

## 全部重放

不要清空当前证据包的results。另建一个空工作目录，复制本包源码、FROZEN及reference、去掉副本中的results与logs（保留原交付目录），在新目录R/下运行：

```bash
python -m r43.run A 0 32
python -m r43.run A 0 4 --negative
python -m r43.run B 0 32
python -m r43.run B 0 4 --negative
python -m r43.analyze
```

驱动在执行前核对17份冻结哈希、拒绝覆盖已有XZ；出现已有文件会停止，而不是覆盖历史。每个世界完成后立即保存XZ和执行回执，再独立核验。再次运行与原样本同源，不算新的独立科学样本。全部结果来自有限前台本地仿真；以上代码不会推送GitHub、联系外部服务或连接用户主系统。

## 文件身份与发布

FROZEN.json绑定正式前源码/理论/协议。FILE_MANIFEST.json绑定此交付所有其他文件，明确不把自身纳入；它不是科学预注册。results/ARCHIVE_MANIFEST.json逐件保存正式XZ/JSON身份及回执关联。results/CLOSING_RECEIPT.json汇总封存检查。包内不含自身ZIP或未来的远端上传状态，避免循环哈希。

远端R43任务和正式前FREEZE_RECORD已发布；其余当次实际发布范围由独立GitHub包登记及最终回复说明。没有把本地完整ZIP写成自动已上传。不要用本包覆盖旧R系列或另一R41目录。
