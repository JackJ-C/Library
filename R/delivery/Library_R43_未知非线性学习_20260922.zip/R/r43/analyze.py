"""Predeclared summary; no training inputs, no optional stopping or metric selection."""
from pathlib import Path
import json,lzma,hashlib,csv
from random import Random
from statistics import mean
ROOT=Path(__file__).resolve().parent

def interval(xs,seed):
    rng=Random(seed);n=len(xs);v=sorted(sum(xs[rng.randrange(n)] for _ in xs)/n for _ in range(5000))
    return [v[124],v[4874]]
def summary():
    out={'stage':'R43','sample_unit':'world seed','batches':{},'negative':[]};score=[]
    for b in ('A','B'):
        data=[]
        for p in sorted((ROOT/'results'/b).glob('*.json.xz')):
            raw=lzma.decompress(p.read_bytes());r=json.loads(raw)
            rc=json.loads(p.with_suffix('.receipt.json').read_text());au=json.loads(p.with_suffix('.audit.json').read_text())
            if hashlib.sha256(raw).hexdigest()!=rc['raw_sha256'] or hashlib.sha256(p.read_bytes()).hexdigest()!=rc['xz_sha256'] or not au['passed']:raise ValueError('archive/audit mismatch')
            if r.get('type'):out['negative'].append({'seed':r['seed'],'rejected':r['rejected'],'stopped':r['stopped']});continue
            data.append(r)
        if len(data)!=32:raise ValueError('incomplete batch')
        batch={'worlds':32,'families':{},'full_exact':0,'full_tasks':0,'full_decisions_correct':0,'actual_goals':0,'unreachable':0,'source_stop_recover':0,'drift':[],'learner_cost':{},'evaluator_cost':{}}
        diff=[]
        for r in data:
            a=r['arms']['active'];n=r['arms']['random'];f=a['complete'];p=a['partial'];rp=n['partial']
            row={'batch':b,'seed':r['seed'],'family':r['kind'],'active_unseen_correct':p['unseen_correct'],'random_unseen_correct':rp['unseen_correct'],'unseen':320,'active_all_correct':p['all_correct'],'random_all_correct':rp['all_correct'],'partial_degree':p['model']['degree'],'partial_history_bits':(p['model']['axes']>>6).bit_count(),'full_degree':f['model']['degree'],'full_terms':len(f['model']['poly']),'partial_active_task_correct':sum(t['correct'] for t in p['plans']),'partial_random_task_correct':sum(t['correct'] for t in rp['plans']),'partial_tasks':24}
            score.append(row);diff.append((p['all_correct']-rp['all_correct'])/512)
            batch['full_exact']+=f['all_correct']==512
            batch['full_tasks']+=len(f['plans']);batch['full_decisions_correct']+=sum(t['correct'] for t in f['plans'])
            batch['actual_goals']+=sum(t.get('actual_success',False) for t in f['plans']);batch['unreachable']+=sum(t['plan'] is None for t in f['plans'])
            batch['source_stop_recover']+=all(a['pressure'][k] for k in ('stopped','blocked_without_action','old_invalid','recovery_correct'))
            for arm in (a,n):
                for k,v in arm['archive']['count'].items():batch['learner_cost'][k]=batch['learner_cost'].get(k,0)+v
            for k,v in r['evaluator_cost'].items():batch['evaluator_cost'][k]=batch['evaluator_cost'].get(k,0)+v
            if 'drift' in a:
                d=a['drift'];batch['drift'].append({'seed':r['seed'],'detected':d['detected'],'monitor_queries':len(d['monitor']),'direct_changed':d.get('direct_changed'),'final_changed':d.get('final_changed'),'relearn_queries':512 if d['detected'] else 0,'relearn_correct':d['relearned']['all_correct'] if d['detected'] else None,'actual_goals':sum(t.get('actual_success',False) for t in d.get('relearned',{}).get('plans',[]))})
                if d['detected']:
                    for k,v in d['audit_cost'].items():batch['evaluator_cost'][k]=batch['evaluator_cost'].get(k,0)+v
        for kind in ('switch','lag','rare','lookup'):
            ss=[s for s in score if s['batch']==b and s['family']==kind]
            batch['families'][kind]={'n':len(ss),'active_unseen_accuracy':mean(x['active_unseen_correct']/320 for x in ss),'random_unseen_accuracy':mean(x['random_unseen_correct']/320 for x in ss),'active_partial_exact_worlds':sum(x['active_all_correct']==512 for x in ss),'random_partial_exact_worlds':sum(x['random_all_correct']==512 for x in ss),'active_plan_accuracy':mean(x['partial_active_task_correct']/24 for x in ss),'random_plan_accuracy':mean(x['partial_random_task_correct']/24 for x in ss),'full_degrees':[x['full_degree'] for x in ss]}
        batch['active_minus_random_common_risk_mean']=mean(diff);batch['descriptive_95_interval']=interval(diff,181 if b=='A' else 182)
        batch['active_advantage_gate']=mean(diff)>0 and batch['descriptive_95_interval'][0]>0
        out['batches'][b]=batch
    out['active_repeated_advantage']=all(v['active_advantage_gate'] for v in out['batches'].values())
    (ROOT/'results/PUBLIC_SUMMARY.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    with (ROOT/'results/WORLD_SCORES.csv').open('w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(score[0]));w.writeheader();w.writerows(score)
    return out
if __name__=='__main__':print(json.dumps(summary(),ensure_ascii=False,indent=2))
