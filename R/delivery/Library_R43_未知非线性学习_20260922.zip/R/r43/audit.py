"""Read-only alternative implementation. No imports from learner, world, common, or Queen.
Reconstructs Boolean transitions, nonlinear coefficients, action plans, query ranks,
source linkage and revocation directly from exported JSON.
"""
from __future__ import annotations
import hashlib,json,lzma
from itertools import product
from functools import lru_cache
from random import Random

class AuditError(ValueError):pass
def check(ok,msg):
    if not ok:raise AuditError(msg)
def stable(v):return (json.dumps(v,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False)+'\n').encode()
def digest(v):return hashlib.sha256(stable(v)).hexdigest()

def physical(spec,x):
    s=x%8;u=(x//8)%8;h=x//64
    p=[0,0,0]
    for channel,coord in enumerate(spec['sensor_order']):p[coord]=((s^spec['sensor_flip'])>>channel)&1
    v=[(u//2**i)%2 for i in range(3)]
    if spec['kind']=='lookup':
        z=spec['lookup'][x]^spec['sensor_flip'];d=[0,0,0]
        for channel,coord in enumerate(spec['sensor_order']):d[coord]=(z>>channel)&1
    else:
        d=p.copy()
        for i,coord in enumerate(spec['owner']):
            j=spec['owner'][(i+1)%3];k=spec['owner'][(i+2)%3]
            d[coord]=(p[coord]+v[i]+v[i]*p[j]+spec['cross'][i]*v[(i+1)%3]*p[k])%2
    impulses=[]
    for i,(a,b) in enumerate(spec['peer_slots']):
        index=d[a]+2*d[b]+4*((h>>i)&1);impulses.append(spec['peers'][i][index])
    f=d.copy()
    for i,coord in enumerate(spec['owner']):f[coord]=(f[coord]+impulses[i])%2
    def obs(z):return sum(z[coord]<<k for k,coord in enumerate(spec['sensor_order']))^spec['sensor_flip']
    direct=obs(d);after=obs(f)
    if spec['kind']=='rare' and x==spec['rare_x']:after^=2**spec['rare_bit']
    return direct+8*after,impulses

def decode(packets):
    seen=set();by={0:[],1:[],2:[]}
    for r in packets:
        check(r['observer'] not in seen,'duplicate observer');seen.add(r['observer'])
        for k,v in r['channels']:by[k].append((r['observer'],v))
    check(all(len({i for i,v in vv})==2 and len({v for i,v in vv})==1 for vv in by.values()),'sensor agreement/distinct source')
    return sum(by[i][0][1]<<i for i in range(3))

def prediction(poly,x):
    # Independent output-bit accumulation rather than vector XOR evaluator.
    result=0
    for output in range(6):
        value=sum(1 for mon,coeff in poly if (coeff>>output)&1 and all((x>>i)&1 for i in range(9) if (mon>>i)&1))%2
        result+=value<<output
    return result

@lru_cache(None)
def feature_set(x,axes,degree):
    ts=[m for m in range(512) if not(m&~axes) and m.bit_count()<=degree]
    return sum((int((x&m)==m)<<i) for i,m in enumerate(ts))

def echelon(rows,axes,degree):
    # Low-pivot row elimination, unlike learner's high-pivot convention.
    piv={}
    for x,y in rows:
        row=feature_set(x,axes,degree);out=y
        while row:
            low=row&-row
            if low not in piv:piv[low]=(row,out);break
            a,b=piv[low];row^=a;out^=b
        if not row and out:return None
    return piv

def independent(v,basis):
    while v:
        p=v&-v
        if p not in basis:return True
        v^=basis[p][0]
    return False

def graph(values):
    return [[sum(1 for x in range(512) if not((x>>v)&1) and ((values[x]^values[x+2**v])>>o)&1) for v in range(9)] for o in range(6)]

def plan_for(values,s,h,actor,channel,goal):
    for n in (1,2,3):
        for controls in product((0,2**actor),repeat=n):
            state,last=s,h
            for a in controls:state=values[state+8*a+64*last]//8;last=a
            if (state>>channel)&1==goal:return list(controls)
    return None

def audit_model(assessment,truth,seed,role,active,full=False):
    m=assessment['model'];rows=m['rows'];known=dict(rows)
    check(len(known)==len(rows),'duplicate training coordinates')
    check(len(rows)==(512 if full else 192),'fixed observation budget')
    check(all(truth[x]==y for x,y in rows),'training observation differs from fixture')
    values=[prediction(m['poly'],x) for x in range(512)]
    check(all(values[x]==y for x,y in rows),'model inconsistent with own observations')
    check(all(mon&~m['axes']==0 and mon.bit_count()<=m['degree'] for mon,c in m['poly']),'language scope')
    mat=echelon(rows,m['axes'],m['degree']);check(mat is not None and len(mat)==m['rank'],'rank')
    if m['degree']>1:check(echelon(rows,m['axes'],m['degree']-1) is None,'degree expansion unsupported')
    unseen=[x for x in range(512) if x not in known]
    check(assessment['unseen_total']==len(unseen),'unseen total')
    check(assessment['unseen_correct']==sum(values[x]==truth[x] for x in unseen),'held-out accuracy')
    check(assessment['all_correct']==sum(a==b for a,b in zip(values,truth)),'all accuracy')
    check(assessment['conditional_universal_certificate']==full,'universal certificate scope')
    check(assessment['learned_edges']==graph(values),'dependency counts')
    order=list(range(512));Random(seed*104729+role).shuffle(order)
    if not active:check([x for x,y in rows]==order[:len(rows)],'random schedule differs')
    # Every active query is independently checked for legal pool and rank gain preference.
    if active:
        seen=set();prefix=[]
        check(len(m['choices'])==len(rows),'choice count')
        for decision,(x,y) in zip(m['choices'],rows):
            check(decision['x']==x,'query lineage')
            pool=[p for p in order if p not in seen][:24]
            check(decision['pool']==pool,'public candidate pool')
            bs=echelon(prefix,decision['axes'],decision['degree'])
            check(bs is not None and len(bs)==decision['rank'],'choice basis rank')
            preferred=[p for p in pool if independent(feature_set(p,decision['axes'],decision['degree']),bs)]
            check(x==(preferred or pool)[0],'query policy not reproduced')
            seen.add(x);prefix.append((x,y))
    if full:
        # Independent Boolean Möbius inversion proves the complete nonlinear coefficients.
        coeff=truth.copy()
        for v in range(9):
            for mask in range(512):
                if (mask>>v)&1:coeff[mask]^=coeff[mask^(1<<v)]
        check(dict(m['poly'])=={i:c for i,c in enumerate(coeff) if c},'canonical ANF not equal')
    for t in assessment['plans']:
        expected=plan_for(values,t['s'],t['h'],t['actor'],t['channel'],t['goal'])
        check(t['plan']==expected,'plan not from learned model')
        correct_plan=plan_for(truth,t['s'],t['h'],t['actor'],t['channel'],t['goal'])
        check(t['reachable']==(correct_plan is not None),'reachability')
        state,last=t['s'],t['h']
        for u in t['plan'] or []:state=truth[state+8*u+64*last]//8;last=u
        correct=correct_plan is None if t['plan'] is None else (state>>t['channel'])&1==t['goal']
        check(t['correct']==correct,'task accuracy')
        if full and t['plan'] is not None:
            rr=t['actual_rows'];check([r['issued'] for r in rr]==[[(u>>i)&1 for i in range(3)] for u in t['plan']],'actual emitted plan')
            check(all(r['y']==truth[r['x']] for r in rr),'actual rollout')
            check(t['actual_success'] and (rr[-1]['y']>>(3+t['channel']))&1==t['goal'],'actual goal')
    return {'queries':len(rows),'rank':m['rank'],'degree':m['degree'],'full_exact':values==truth}

def audit_archive(archive,spec,change=None,hidden=False):
    ledgers=archive['ledgers'];bodies=[]
    for actor,ledger in enumerate(ledgers):
        invalid=set();parsed=[]
        for i,record in enumerate(ledger):
            check(record['seq']==i,'sequence number')
            check(all(0<=j<i for j in record['deps']+record['refs']),'nonhistorical ledger links')
            parsed.append(json.loads(record['body']))
            if record['kind']=='revocation':invalid.add(parsed[-1]['root'])
        for record in ledger:
            if any(p in invalid for p in record['deps']):invalid.add(record['seq'])
        check(sorted(invalid)==archive['invalid'][actor],'withdrawal transitive closure')
        bodies.append(parsed)
    for n,r in enumerate(archive['trace']):
        check(decode(r['before'])==r['x']%8,'before reading')
        check(decode(r['direct'])+8*decode(r['after'])==r['y'],'assembled sensor response')
        sp=change['spec_after'] if change and n>=change['trace_offset'] else spec
        if not hidden:
            y,reactions=physical(sp,r['x']);check(y==r['y'] and reactions==r['reactions'],'nonlinear transition/peer policy')
        check(sum(v<<i for i,v in enumerate(r['issued']))==(r['x']//8)%8,'issued input')
        for ref in r['refs']:
            actor,seq=ref['observer'],ref['seq'];record=ledgers[actor][seq];body=bodies[actor][seq]
            check(digest(record['body'])==ref['body_sha'],'source hash')
            check(record['kind']=='R43_observation','source kind')
            check(body['before']==r['before'][actor] and body['direct']==r['direct'][actor] and body['after']==r['after'][actor],'raw source body')
            check(body['issued']==r['issued'][actor] and body['reacted']==r['reactions'][actor],'source emitted action')
    check(archive['count']['physical_microsteps']==len(archive['trace'])*2,'microstep cost')
    return sum(map(len,ledgers))

def verify(data):
    if data.get('type')=='hidden_state_counterexample':
        check(data['first']['x']==data['second']['x'] and data['first']['y']!=data['second']['y'],'hidden-state falsifier')
        check(data['rejected'] and data['stopped'],'unsupported hidden state did not stop')
        count=audit_archive(data['archive'],None,hidden=True)
        return {'passed':True,'kind':'hidden_counterexample','ledger_records':count}
    truth=[physical(data['spec'],x)[0] for x in range(512)]
    check(truth==data['truth'],'evaluation truth reconstruction')
    check(graph(truth)==data['true_edges'],'true dependence graph')
    w=data['nonlinear_witness'];check(w is not None and truth[w['x']]^truth[w['x']^(1<<w['a'])]^truth[w['x']^(1<<w['b'])]^truth[w['x']^(1<<w['a'])^(1<<w['b'])]==w['second_difference'] and w['second_difference']!=0,'nonlinearity witness')
    count=0;models=[]
    for name,arm in data['arms'].items():
        models.append(audit_model(arm['partial'],truth,data['seed'],11,name=='active'))
        base=arm['paired_baselines'];consistent=echelon(arm['partial']['model']['rows'],511,1) is not None
        check((base['affine_status']=='PROVISIONAL')==consistent,'affine rejection')
        check(base['table_observed_correct']==192 and base['table_unseen_abstentions']==320,'same information table')
        if name=='active':
            models.append(audit_model(arm['complete'],truth,data['seed'],11,True,True))
            p=arm['pressure'];check(all(p[k] for k in ('stopped','blocked_without_action','old_invalid','historical_body_unchanged','historical_reference_valid','recovery_correct')),'withdrawal/recovery flags')
            check(p['recovery_queries']==1 and p['old_license']!=p['new_license'],'new evidence/license')
            check(all(r['y']==truth[r['x']] for r in p['recovery_actual']),'live recovery')
            change=arm.get('drift')
            if change:
                nt=[physical(change['spec_after'],x)[0] for x in range(512)]
                check(change['peer']!=data['seed']%3,'focal actor changed')
                for r in change['monitor']:check(r['predicted']==truth[r['x']] and r['observed']==nt[r['x']],'drift monitor')
                check(change['detected']==any(r['predicted']!=r['observed'] for r in change['monitor']),'drift detection')
                if change['detected']:
                    check(nt==change['truth_after'],'new truth')
                    check(change['direct_changed']==sum((a%8)!=(b%8) for a,b in zip(truth,nt))==0,'direct effect unchanged')
                    check(change['final_changed']==sum((a//8)!=(b//8) for a,b in zip(truth,nt)),'total effect changed')
                    models.append(audit_model(change['relearned'],nt,data['seed'],32,True,True))
        count+=audit_archive(arm['archive'],data['spec'],arm.get('drift'))
    return {'passed':True,'seed':data['seed'],'kind':data['kind'],'model_checks':models,'ledger_records':count}

if __name__=='__main__':
    import sys
    with lzma.open(sys.argv[1],'rt') as f:d=json.load(f)
    print(json.dumps(verify(d),ensure_ascii=False))
