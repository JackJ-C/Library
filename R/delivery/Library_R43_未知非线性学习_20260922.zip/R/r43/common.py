"""Shared serialization and inherited identities; no fixture truth in this module."""
from __future__ import annotations
import hashlib,json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
sys.path.insert(0,str(ROOT/'reference'))
from src.core import Queen as BaseQueen

def encode(x):return (json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False)+'\n').encode()
def sha(x):return hashlib.sha256(encode(x)).hexdigest()
def require(ok,msg):
    if not ok:raise ValueError(msg)
def bits(v,n=3):return [(v>>i)&1 for i in range(n)]
def pack(v):return sum(int(a)<<i for i,a in enumerate(v))
def atomic_json(path,x):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('xb') as f:f.write(encode(x))
