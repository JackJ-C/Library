"""External trial orchestration. Evaluator-only labels never enter LearningQueen.
All models are exported BEFORE reference table and candidate plan outcomes are computed.
"""
from __future__ import annotations
from random import Random
from collections import Counter
from copy import deepcopy
from .common import BaseQueen,sha,require
from .world import specification,make_fixture,World,Port,KINDS
from .learner import LearningQueen,evaluate,fit,polynomial

BUDGET=192

def shuffled(seed,role):
    order=list(range(512));Random(seed*104729+role).shuffle(order);return order

def truth_table(spec):
    # New evaluator fixtures; not accessible to learner. Actually call emitters and ports.
    w=World(spec);qs=[BaseQueen(i) for i in range(3)]
    for i,q in enumerate(qs):
        t=tuple(spec['peers'][i]);q.r43_reactor=lambda a,t=t:t[a]
    p=Port(w,qs,0);out=[]
    for x in range(512):out.append(p.probe(x)['y'])
    return out,dict(w.count)

def edges(table):
    return [[sum(bool((table[x]^table[x^(1<<a)])&(1<<o)) for x in range(512) if not x&(1<<a)) for a in range(9)] for o in range(6)]

def nonlinear_witness(table):
    for a in range(9):
        for b in range(a+1,9):
            for x in range(512):
                if (x>>a)&1 or (x>>b)&1:continue
                z=table[x]^table[x^(1<<a)]^table[x^(1<<b)]^table[x^(1<<a)^(1<<b)]
                if z:return {'x':x,'a':a,'b':b,'second_difference':z}
    return None

def make_tasks(seed):
    r=Random(seed*3253+17)
    return [{'s':r.randrange(8),'h':r.randrange(8),'channel':r.randrange(3)} for _ in range(24)]

def roll(table,s,h,plan):
    for u in plan:s=table[s|(u<<3)|(h<<6)]>>3;h=u
    return s

def reachable(table,s,h,actor,c,goal):
    states={(s,h)}
    for _ in range(3):
        nxt=set()
        for a,b in states:
            for u in (0,1<<actor):
                t=table[a|(u<<3)|(b<<6)]>>3
                if ((t>>c)&1)==goal:return True
                nxt.add((t,u))
        states=nxt
    return False

def assessment(q,table,tasks,live=False):
    # Raw held-out risk is outside LearningQueen and never used to update it.
    model=q.export_model();known={x for x,y in model['rows']};unseen=[x for x in range(512) if x not in known]
    predictions=[evaluate(model['poly'],x) for x in range(512)]
    out={'model':model,'unseen_total':len(unseen),'unseen_correct':sum(predictions[x]==table[x] for x in unseen),
        'all_correct':sum(a==b for a,b in zip(predictions,table)),
        'conditional_universal_certificate':len(known)==512,'plans':[],'learned_edges':edges(predictions)}
    for t in tasks:
        s,h,c=t['s'],t['h'],t['channel'];goal=1-((s>>c)&1)
        plan=q.propose(s,h,q.seed_actor,c,goal)
        reach=reachable(table,s,h,q.seed_actor,c,goal)
        item={**t,'actor':q.seed_actor,'goal':goal,'plan':plan,'reachable':reach,
              'correct':(not reach if plan is None else ((roll(table,s,h,plan)>>c)&1)==goal)}
        if live and plan is not None:
            rr=q.execute_plan(s,h,plan);item['actual_rows']=rr
            item['actual_success']=bool(rr) and ((rr[-1]['y']>> (3+c))&1)==goal and len(rr)==len(plan)
        out['plans'].append(item)
    return out

def baseline_from_same_rows(rows,table):
    b,_=fit(rows,511,1)
    poly=polynomial(b,511,1) if b is not None else None
    unseen=[x for x in range(512) if x not in dict(rows)]
    return {'affine_status':'INCONSISTENT' if b is None else 'PROVISIONAL', 'affine_poly':poly,
       'affine_unseen_correct':None if b is None else sum(evaluate(poly,x)==table[x] for x in unseen),
       'table_observed_correct':sum(table[x]==y for x,y in rows),'table_unseen_abstentions':len(unseen)}

def scenario(seed,kind,drift=False):
    arms={}; table=None;audit_cost=None
    for mode in ('active','random'):
        q,p,w,qs=make_fixture(seed,kind,LearningQueen);q.seed_actor=seed%3;q.attach(p)
        order=shuffled(seed,11);q.learn(order,BUDGET,mode=='active')
        # The next two lines are external evaluator operations after partial model commitment.
        if table is None:table,audit_cost=truth_table(deepcopy(w.spec))
        part=assessment(q,table,make_tasks(seed),False)
        arm={'partial':part,'paired_baselines':baseline_from_same_rows(part['model']['rows'],table)}
        if mode=='active':
            q.learn(order,512,True)
            complete=assessment(q,table,make_tasks(seed),True)
            # Remove real observation of another actor. It must stop before even a reset pulse.
            removed_x=order[0];rec,rs=q.support[removed_x]
            source=next(r for r in rs if r['observer']!=seed%3)
            oldlicense=q.license;oldbody=qs[source['observer']].ledger.records[source['seq']].body
            p.revoke_source(source);before=w.count['physical_microsteps'];stopped=False
            try:q.execute_plan(0,0,[0])
            except PermissionError:stopped=True
            blocked_count=w.count['physical_microsteps'];recovered=q.repair_sources();actual=q.execute_plan(0,0,[0])
            history=qs[source['observer']].add('R43_historical_reference',{'kept':True},refs=(source['seq'],))
            pressure={'source':source,'removed_x':removed_x,'old_license':oldlicense,'new_license':q.license,
              'stopped':stopped,'blocked_without_action':before==blocked_count,'old_invalid':oldlicense in q.ledger.invalid,
              'historical_body_unchanged':oldbody==qs[source['observer']].ledger.records[source['seq']].body,
              'historical_reference_valid':history not in qs[source['observer']].ledger.invalid,
              'recovery_queries':len(recovered),'recovery_actual':actual,'recovery_correct':actual[-1]['y']==table[actual[-1]['x']]}
            arm.update(complete=complete,pressure=pressure)
            if drift:
                peer=(seed%3+1)%3;w.spec['peers'][peer][0]^=1;t=tuple(w.spec['peers'][peer]);qs[peer].r43_reactor=lambda a,t=t:t[a]
                changed_spec=deepcopy(w.spec);offset=len(p.trace)
                change=q.monitor_and_relearn(shuffled(seed,31),shuffled(seed,32),64)
                change.update(peer=peer,own_peer_unchanged=peer!=seed%3,spec_after=changed_spec,trace_offset=offset)
                if change['detected']:
                    nt,nc=truth_table(changed_spec);out=assessment(q,nt,make_tasks(seed+1),True)
                    change.update(relearned=out,truth_after=nt,audit_cost=nc,
                        direct_changed=sum((a&7)!=(b&7) for a,b in zip(table,nt)),
                        final_changed=sum((a>>3)!=(b>>3) for a,b in zip(table,nt)))
                arm['drift']=change
        arm['archive']=p.export();arms[mode]=arm
    return {'stage':'R43','seed':seed,'kind':kind,'spec':specification(seed,kind),
            'truth':table,'evaluator_cost':audit_cost,'nonlinear_witness':nonlinear_witness(table),
            'true_edges':edges(table),'arms':arms}

def hidden_counterexample(seed):
    q,p,w,qs=make_fixture(seed,'lag',LearningQueen);q.attach(p);q.seed_actor=seed%3
    w.hidden_toggle=True
    r1=p.probe(0);q.ingest(r1);q.bind();w.toggle^=1;r2=p.probe(0);q.ingest(r2)
    stopped=False
    try:q.predict(0)
    except PermissionError:stopped=True
    return {'stage':'R43','type':'hidden_state_counterexample','seed':seed,'first':r1,'second':r2,
      'rejected':q.rejected,'stopped':stopped,'model':q.export_model(),'archive':p.export()}
