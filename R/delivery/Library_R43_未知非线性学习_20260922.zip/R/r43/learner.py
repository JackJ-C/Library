"""Generic evidence-driven nonlinear learner mounted in the inherited Queen.
No fixture imports; no true formula, degree, topology, family or seed is accepted by fit.
All Boolean functions of nine recorded bits fit within the universal final language.
"""
from __future__ import annotations
from functools import lru_cache
from itertools import combinations
from random import Random
from collections import Counter
from .common import BaseQueen,sha,require

@lru_cache(None)
def terms(axes,degree):return tuple(m for m in range(512) if m&~axes==0 and m.bit_count()<=degree)
@lru_cache(None)
def feature(x,axes,degree):
    return sum(1<<j for j,m in enumerate(terms(axes,degree)) if x&m==m)
def reduce_row(row,basis):
    while row:
        p=row.bit_length()-1
        if p not in basis:break
        row^=basis[p][0]
    return row

def fit(rows,axes,degree):
    basis={};ops=0
    for x,y in rows:
        a=feature(x,axes,degree);b=y
        while a:
            p=a.bit_length()-1;ops+=1
            if p not in basis:basis[p]=(a,b);break
            v,w=basis[p];a^=v;b^=w
        if a==0 and b:return None,ops
    return basis,ops

def polynomial(basis,axes,degree):
    values={}
    for p in sorted(basis):
        a,b=basis[p];a^=1<<p
        while a:
            bit=a&-a;j=bit.bit_length()-1;b^=values.get(j,0);a^=bit
        values[p]=b
    ts=terms(axes,degree)
    return [(ts[p],v) for p,v in sorted(values.items()) if v]
def evaluate(poly,x):
    out=0
    for m,v in poly:
        if x&m==m:out^=v
    return out

class LearningQueen(BaseQueen):
    def __init__(self,seed):
        super().__init__(seed);self.rows={};self.support={};self.axes=63;self.degree=1
        self.basis={};self.poly=[];self.events=[];self.cost=Counter();self.license=None;self.bound=None
        self.rejected=False;self.port=None;self.revisions=0;self.choices=[]
    def attach(self,port):self.port=port
    def project_conflicts(self,axes):
        seen={}
        for x,y in self.rows.items():
            k=x&axes
            if k in seen and seen[k]!=y:return True
            seen[k]=y
        return False
    def ingest(self,row):
        x,y=row['x'],row['y']
        rec=self.add('R43_received_trial',{'x':x,'observed':y,'sources':row['refs']})
        if x in self.rows and self.rows[x]!=y:
            self.rejected=True;self.invalidate_model('same complete recorded state/action gives conflicting effect')
            self.events.append({'type':'UNREPRESENTED_STATE_OR_NONSTATIONARITY','x':x,'old':self.rows[x],'new':y})
            return False
        self.rows[x]=y;self.support[x]=(rec,row['refs'])
        if self.project_conflicts(self.axes):
            before=self.axes;options=sorted((63|m<<6 for m in range(8) if (63|m<<6)&self.axes==self.axes),key=lambda a:(a.bit_count(),a))
            self.axes=next(a for a in options if not self.project_conflicts(a));self.degree=1
            self.events.append({'type':'expand_recorded_history','before':before,'after':self.axes,'observations':len(self.rows)})
        # Refit chooses the least degree consistent with ALL currently valid observations.
        while True:
            basis,ops=fit(list(self.rows.items()),self.axes,self.degree);self.cost['elimination_steps']+=ops
            if basis is not None:break
            self.events.append({'type':'degree_refuted','degree':self.degree,'axes':self.axes,'observations':len(self.rows)})
            self.degree+=1
            require(self.degree<=self.axes.bit_count(),'universal Boolean representation inconsistent')
        self.basis=basis;self.poly=polynomial(basis,self.axes,self.degree)
        return True
    def choose_query(self,order,active=True):
        unknown=[x for x in order if x not in self.rows]
        require(unknown,'scope exhausted')
        if not active:return unknown[0]
        # Inspect only candidate inputs, not their unknown labels.
        pool=unknown[:24];ranks=[]
        for i,x in enumerate(pool):
            residual=reduce_row(feature(x,self.axes,self.degree),self.basis)
            self.cost['query_candidate_checks']+=1
            ranks.append((bool(residual),-i,x))
        chosen=max(ranks)[-1]
        self.choices.append({'x':chosen,'axes':self.axes,'degree':self.degree,'pool':pool,'rank':len(self.basis)})
        return chosen
    def learn(self,order,budget,active=True):
        while len(self.rows)<budget and not self.rejected:
            x=self.choose_query(order,active);r=self.port.probe(x);self.ingest(r)
        if not self.rejected:self.bind()
    def invalidate_model(self,reason):
        if self.license is not None and self.license not in self.ledger.invalid:self.ledger.revoke(self.license,reason)
    def bind(self):
        require(not self.rejected,'cannot bind contradictory state model')
        self.invalidate_model('superseded by new evidence-backed model')
        self.bound={'axes':self.axes,'degree':self.degree,'poly':[list(p) for p in self.poly],
                    'queries':sorted(self.rows),'scope':'finite 9-bit recorded interface',
                    'status':'EXHAUSTIVE_EXACT' if len(self.rows)==512 else 'PROVISIONAL_NOT_UNIVERSALLY_CERTIFIED'}
        self.bound_hash=sha(self.bound)
        self.license=self.add('R43_nonlinear_model',self.bound,deps=tuple(rec for rec,rs in self.support.values()))
        self.revisions+=1
    def require_model(self):
        if self.license is None or self.license in self.ledger.invalid or sha(self.bound)!=self.bound_hash:
            raise PermissionError('invalid nonlinear model binding')
        if [list(p) for p in self.poly]!=self.bound['poly']:
            self.invalidate_model('live polynomial differs from committed model');raise PermissionError('changed polynomial')
        for rec,rs in self.support.values():
            if rec in self.ledger.invalid or not self.port.valid_sources(rs):
                self.invalidate_model('source observation withdrawn');raise PermissionError('withdrawn source')
    def predict(self,x):self.require_model();return evaluate(self.poly,x)
    def propose(self,s,h,actor,channel,goal,horizon=3):
        self.require_model()
        require(all(type(v)is int for v in (s,h,actor,channel,goal,horizon)) and 0<=s<8 and 0<=h<8 and 0<=actor<3 and 0<=channel<3 and goal in (0,1) and 1<=horizon<=3,'invalid planning scope')
        # Search the learned dynamics. Never ask fixture for true consequences or a correct action.
        frontier=[(s,h,[])];self.cost['planned_nodes']+=1
        for _ in range(horizon):
            nxt=[]
            for state,last,path in frontier:
                for u in (0,1<<actor):
                    x=state|(u<<3)|(last<<6);out=evaluate(self.poly,x)>>3
                    seq=path+[u];self.cost['planned_nodes']+=1
                    if (out>>channel)&1==goal:return seq
                    nxt.append((out,u,seq))
            frontier=nxt
        return None
    def execute_plan(self,s,h,plan):
        self.require_model()
        state,last=s,h
        for u in plan:
            require(type(u)is int and 0<=u<8,'bad planned action')
            x=state|(u<<3)|(last<<6)
            if x not in self.rows:raise PermissionError('unmeasured planned transition: probe first')
            state=evaluate(self.poly,x)>>3;last=u
        self.port.reset(s,h);rows=[]
        for u in plan:
            self.require_model();r=self.port.act(u);rows.append(r)
            if evaluate(self.poly,r['x'])!=r['y']:
                self.invalidate_model('actual deployment refuted predicted effect');break
        return rows
    def export_model(self):
        return {'axes':self.axes,'degree':self.degree,'poly':[list(v) for v in self.poly],
            'rank':len(self.basis),'terms':len(terms(self.axes,self.degree)),
            'events':self.events[:],'cost':dict(self.cost),'rows':[[x,y] for x,y in self.rows.items()],
            'model_record':self.license,'rejected':self.rejected,'choices':self.choices[:]}
    def new_epoch(self):
        self.invalidate_model('observed change: retire current stationarity interval')
        self.events.append({'type':'new_epoch','previous_rows':len(self.rows)})
        self.rows={};self.support={};self.axes=63;self.degree=1;self.basis={};self.poly=[];self.rejected=False;self.choices=[]
    def repair_sources(self):
        missing=[x for x,(rec,rs) in self.support.items() if rec in self.ledger.invalid or not self.port.valid_sources(rs)]
        self.invalidate_model('repairing withdrawn observation support')
        for x in missing:
            self.rows.pop(x);self.support.pop(x)
            self.ingest(self.port.probe(x))
        if not self.rejected:self.bind()
        return missing
    def monitor_and_relearn(self,monitor_order,learning_order,limit=64):
        records=[];detected=False;old_license=self.license
        for x in monitor_order[:limit]:
            row=self.port.probe(x);expected=evaluate(self.poly,x)
            records.append({'x':x,'predicted':expected,'observed':row['y']})
            if expected!=row['y']:
                self.invalidate_model('new actual observation violates current model')
                self.new_epoch();self.learn(learning_order,512,True);detected=True;break
        return {'monitor':records,'detected':detected,'old_license':old_license,
                'old_invalid':old_license in self.ledger.invalid}
