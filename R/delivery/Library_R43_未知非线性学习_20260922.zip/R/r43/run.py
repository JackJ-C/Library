"""Foreground-only frozen runner. Refuses to overwrite any archived experiment."""
import argparse,json,lzma,hashlib,time,platform
from pathlib import Path
from .common import encode,atomic_json
from .experiment import scenario,hidden_counterexample
from .audit import verify
ROOT=Path(__file__).resolve().parent

def check_frozen():
    blob=(ROOT/'FROZEN.json').read_bytes();f=json.loads(blob)
    for p,h in f['sha256'].items():
        if hashlib.sha256((ROOT/p).read_bytes()).hexdigest()!=h:raise RuntimeError('frozen source mismatch: '+p)
    return hashlib.sha256(blob).hexdigest()

def execute(batch,index,negative=False):
    fh=check_frozen();seed=(113900 if batch=='A' else 114900)+index if negative else (113100 if batch=='A' else 114100)+index
    path=ROOT/'results'/batch/f'{seed}.json.xz';path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists():raise FileExistsError('preserve existing archive '+str(path))
    start=time.perf_counter()
    r=hidden_counterexample(seed) if negative else scenario(seed,('switch','lag','rare','lookup')[index%4],index<4)
    raw=encode(r);packed=lzma.compress(raw,preset=3)
    with path.open('xb') as out:out.write(packed)
    receipt={'file':path.name,'seed':seed,'batch':batch,'raw_sha256':hashlib.sha256(raw).hexdigest(),
      'xz_sha256':hashlib.sha256(packed).hexdigest(),'bytes':len(packed),'raw_bytes':len(raw),
      'frozen_sha256':fh,'seconds_execution':time.perf_counter()-start,'python':platform.python_version()}
    atomic_json(path.with_suffix('.receipt.json'),receipt)
    t=time.perf_counter();v=verify(json.loads(raw));v['seconds_audit']=time.perf_counter()-t;v['raw_sha256']=receipt['raw_sha256'];v['frozen_sha256']=fh
    atomic_json(path.with_suffix('.audit.json'),v)
    print(batch,seed,'verified',len(packed),'bytes','elapsed',round(time.perf_counter()-start,3),flush=True)
    return receipt

if __name__=='__main__':
    ap=argparse.ArgumentParser();ap.add_argument('batch',choices=('A','B'));ap.add_argument('start',type=int);ap.add_argument('end',type=int);ap.add_argument('--negative',action='store_true');a=ap.parse_args()
    if not 0<=a.start<=a.end<=(4 if a.negative else 32):raise ValueError('index scope')
    for i in range(a.start,a.end):execute(a.batch,i,a.negative)
