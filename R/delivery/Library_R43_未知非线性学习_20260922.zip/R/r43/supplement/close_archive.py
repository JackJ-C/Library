"""Post-freeze integrity closure, not a new scientific sample or another independent auditor."""
from pathlib import Path
import json,lzma,hashlib
ROOT=Path(__file__).resolve().parents[1]
def h(b):return hashlib.sha256(b).hexdigest()
def main():
    f=json.loads((ROOT/'FROZEN.json').read_bytes());issues=[];manifest=[]
    for name,digest in f['sha256'].items():
        if h((ROOT/name).read_bytes())!=digest:issues.append('frozen:'+name)
    for p in sorted((ROOT/'results').glob('[AB]/*.json.xz')):
        packed=p.read_bytes();raw=lzma.decompress(packed)
        r=json.loads(p.with_suffix('.receipt.json').read_bytes());a=json.loads(p.with_suffix('.audit.json').read_bytes())
        if h(raw)!=r['raw_sha256'] or h(packed)!=r['xz_sha256'] or h(raw)!=a['raw_sha256'] or not a['passed']:issues.append(str(p))
        if r['frozen_sha256']!=h((ROOT/'FROZEN.json').read_bytes()) or a['frozen_sha256']!=r['frozen_sha256']:issues.append('freeze_receipt:'+str(p))
        manifest.append({'path':str(p.relative_to(ROOT)),'bytes':len(packed),'raw_bytes':len(raw),'xz_sha256':h(packed),'raw_sha256':h(raw),'execution_receipt':str(p.with_suffix('.receipt.json').relative_to(ROOT)),'audit_receipt':str(p.with_suffix('.audit.json').relative_to(ROOT))})
    if len(manifest)!=72:issues.append('archive_count')
    out={'stage':'R43','status':'PASS' if not issues else 'FAIL','frozen_sha256':h((ROOT/'FROZEN.json').read_bytes()),'frozen_files_checked':len(f['sha256']),'formal_archives':len(manifest),'issues':issues,'classification':'integrity_check_not_new_experiment'}
    (ROOT/'results/ARCHIVE_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
    (ROOT/'results/CLOSING_RECEIPT.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps(out,ensure_ascii=False));
    if issues:raise RuntimeError('closure failed')
if __name__=='__main__':main()
