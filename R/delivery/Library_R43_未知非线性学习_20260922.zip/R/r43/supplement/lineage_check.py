"""Additional source-to-learned-model and action-history checks after formal freeze."""
from pathlib import Path
import json,lzma,hashlib
ROOT=Path(__file__).resolve().parents[1]
def ensure(ok,msg):
    if not ok:raise ValueError(msg)
def check_all():
    count={'worlds':0,'action_history_steps':0,'intention_receipt_pairs':0,'model_training_dependencies':0,'models':0}
    for folder in ('A','B'):
        for path in sorted((ROOT/'results'/folder).glob('*.json.xz')):
            r=json.loads(lzma.decompress(path.read_bytes()))
            if r.get('type'):continue
            count['worlds']+=1
            for arm in r['arms'].values():
                ar=arm['archive'];book=ar['ledgers'];body=[[json.loads(x['body']) for x in bb] for bb in book]
                trace_by_sources={};last=0
                for row in ar['trace']:
                    ensure(row['x']//64==last,'action history not actual previous issued input')
                    last=sum(v<<i for i,v in enumerate(row['issued']));count['action_history_steps']+=1
                    key=tuple((z['observer'],z['seq']) for z in row['refs']);trace_by_sources[key]=row
                    for ref in row['refs']:
                        a,j=ref['observer'],ref['seq'];b=body[a][j];ii=body[a][b['intention']];ri=body[a][b['reaction']]
                        ensure(book[a][j]['deps']==[b['intention'],b['reaction']],'receipt proof dependencies')
                        ensure(ii['requested']==row['issued'][a] and ii['before']==row['before'][a] and ii['external_history']==((row['x']>>(6+a))&1),'request/effect lineage')
                        ensure(ri['requested']==row['reactions'][a] and ri['local_view']==row['direct'][a] and ri['last_external']==((row['x']>>(6+a))&1),'reaction lineage')
                        count['intention_receipt_pairs']+=1
                stages=[arm['partial']]+([arm['complete']] if 'complete' in arm else [])
                if arm.get('drift',{}).get('detected'):stages.append(arm['drift']['relearned'])
                for stage in stages:
                    m=stage['model'];a=r['seed']%3;j=m['model_record'];b=body[a][j]
                    ensure(b['poly']==m['poly'] and b['axes']==m['axes'] and b['degree']==m['degree'],'installed model mismatch')
                    observed={x:y for x,y in m['rows']};ensure(sorted(observed)==b['queries'],'model query scope')
                    deps=book[a][j]['deps'];ensure(len(deps)==len(observed),'number of source dependencies')
                    for p in deps:
                        d=body[a][p];key=tuple((z['observer'],z['seq']) for z in d['sources']);tr=trace_by_sources[key]
                        ensure(d['x'] in observed and d['observed']==observed[d['x']]==tr['y'] and tr['x']==d['x'],'learned value did not come from actual observation')
                        ensure(book[a][p]['kind']=='R43_received_trial','model evidence type')
                        count['model_training_dependencies']+=1
                    count['models']+=1
    out={'passed':True,'phase':'POST_FREEZE_SUPPLEMENT','checks':count}
    (ROOT/'results/LINEAGE_SUPPLEMENT.json').write_text(json.dumps(out,indent=2)+'\n');return out
if __name__=='__main__':print(check_all())
