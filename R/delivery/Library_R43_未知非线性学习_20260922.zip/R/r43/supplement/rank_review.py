"""Post-freeze diagnostic only; recompute design-matrix ranks without learner imports."""
from pathlib import Path
from collections import Counter
import json,lzma
ROOT=Path(__file__).resolve().parents[1]
def lowrank(rows,axes,degree):
    masks=[m for m in range(512) if not(m & ~axes) and m.bit_count()<=degree]
    basis={}
    for x,y in rows:
        value=sum(1<<i for i,m in enumerate(masks) if x&m==m)
        while value:
            k=(value&-value).bit_length()-1
            if k not in basis:
                basis[k]=value; break
            value^=basis[k]
    return len(basis),len(masks)
def main():
    groups={};bases=Counter();total=0
    for p in sorted((ROOT/'results').glob('[AB]/*.json.xz')):
        d=json.loads(lzma.decompress(p.read_bytes()))
        if 'arms' not in d:continue
        for arm,data in d['arms'].items():
            m=data['partial']['model'];r,t=lowrank(m['rows'],m['axes'],m['degree'])
            if (r,t)!=(m['rank'],m['terms']):raise ValueError('rank mismatch')
            groups.setdefault(d['kind']+'/'+arm,[]).append({'seed':d['seed'],'rank':r,'columns':t,'degree':m['degree'],'axes':m['axes'],'free_coefficients_per_output':t-r})
            b=data['paired_baselines'];bases[json.dumps(b,sort_keys=True)]+=1;total+=1
    out={'status':'POST_HOC_NOT_TRAINING_FEEDBACK','partial_models_checked':total,'groups':groups,'baseline_records':[{'record':json.loads(k),'count':v}for k,v in bases.items()]}
    (ROOT/'results/RANK_DIAGNOSTIC.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
    print('Models',total,'baselines',out['baseline_records'])
if __name__=='__main__':main()
