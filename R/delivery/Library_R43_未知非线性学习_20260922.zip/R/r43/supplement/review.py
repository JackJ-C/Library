"""Post-freeze semantic and arithmetic review; no formal algorithm/result changes."""
from pathlib import Path
import json,lzma,hashlib
from fractions import Fraction
ROOT=Path(__file__).resolve().parents[1]

def review():
    counts={'raw_peer_view_checks':0,'calibrated_reencoding_matches':0,'sensor_literal_address_equals_physical_address':0,'nonlinear_worlds':0,'ledger_records':0}
    rare=[];history=[];batch_diffs={}
    for batch in ('A','B'):
        total=0
        for path in sorted((ROOT/'results'/batch).glob('1131*.json.xz' if batch=='A' else '1141*.json.xz')):
            r=json.loads(lzma.decompress(path.read_bytes()));counts['nonlinear_worlds']+=r['nonlinear_witness'] is not None
            a=r['arms']['active']['partial'];b=r['arms']['random']['partial'];total+=a['all_correct']-b['all_correct']
            if r['kind']=='rare' and a['all_correct']==511 and r['spec']['rare_x'] not in dict(a['model']['rows']):
                x=r['spec']['rare_x'];old=r['truth'][x]^(1<<(3+r['spec']['rare_bit']))
                rare.append({'seed':r['seed'],'unmeasured_x':x,'model_unseen_correct':a['unseen_correct'],'unseen_total':a['unseen_total'],'unseen_actual':r['truth'][x],'alternative_without_exception':old,'same_all_training_data':True})
            if r['kind']=='lag' and not history:
                seen={}
                for x,y in a['model']['rows']:
                    key=x&63
                    if key in seen and seen[key][1]!=y:
                        history.append({'seed':r['seed'],'first':seen[key],'second':[x,y],'same_current_state_action':key,'learned_axes':a['model']['axes'],'events':a['model']['events']});break
                    seen[key]=[x,y]
            for arm in r['arms'].values():
                d=arm.get('drift');counts['ledger_records']+=sum(map(len,arm['archive']['ledgers']))
                for j,row in enumerate(arm['archive']['trace']):
                    spec=d['spec_after'] if d and j>=d['trace_offset'] else r['spec']
                    for i,packet in enumerate(row['direct']):
                        raw=packet['channels'][0][1]+2*packet['channels'][1][1]+4*((row['x']>>(6+i))&1)
                        flip=0
                        for slot,p in enumerate(spec['peer_slots'][i]):
                            alias=spec['sensor_order'].index(p);flip|=((spec['sensor_flip']>>alias)&1)<<slot
                        address=raw^flip
                        counts['raw_peer_view_checks']+=1
                        counts['calibrated_reencoding_matches']+=spec['peers'][i][address]==row['reactions'][i]
                        counts['sensor_literal_address_equals_physical_address']+=raw==address
        value=Fraction(total,32*512);batch_diffs[batch]={'numerator':value.numerator,'denominator':value.denominator,'float':float(value)}
    out={'stage':'R43','classification':'POST_HOC_REVIEW_NOT_NEW_EXPERIMENT','counts':counts,'common_measure_arithmetic':batch_diffs,'rare_examples':rare,'history_example':history,
      'clarification':'Frozen fixture feeds peers calibrated physical local bits, not literal raw sensor bits. A fixed local XOR calibration converts one to the other. Focus learner uses only pooled observation data. This recoding is researcher-provided and not discovered by the learner; no global state or future consequence is needed to compute it.'}
    (ROOT/'results/POST_HOC_REVIEW.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n');return out
if __name__=='__main__':print(json.dumps(review(),ensure_ascii=False,indent=2))
