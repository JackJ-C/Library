"""Development contract tests. Synthetic algebra fixtures are not experimental worlds."""
import unittest,copy,ast,json
from random import Random
from pathlib import Path
from .learner import LearningQueen,fit,polynomial,evaluate,feature,terms
from .world import make_fixture,Port
from .experiment import scenario,hidden_counterexample,nonlinear_witness,truth_table
from .audit import verify,physical,AuditError

class Contracts(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.data=json.loads(json.dumps(scenario(0,'switch',False)))
    def test_01_universal_truth(self):
        rows=[(x,Random(x).randrange(64)) for x in range(512)]
        b,_=fit(rows,511,9);p=polynomial(b,511,9)
        self.assertTrue(all(evaluate(p,x)==y for x,y in rows))
    def test_02_affine_cannot_and(self):self.assertIsNone(fit([(x, int(x&3==3)) for x in range(4)],3,1)[0])
    def test_03_quadratic_can_and(self):
        b,_=fit([(x,int(x&3==3)) for x in range(4)],3,2);self.assertEqual(polynomial(b,3,2),[(3,1)])
    def test_04_rare_degree_nine(self):
        rows=[(x,int(x==511)) for x in range(512)];self.assertIsNone(fit(rows,511,8)[0])
    def test_05_history_expands(self):
        q=LearningQueen(0)
        for x,y in ((0,0),(64,1)):q.ingest({'x':x,'y':y,'refs':[]})
        self.assertEqual(q.axes,127)
    def test_06_full_state_conflict(self):
        q=LearningQueen(0)
        for y in (0,1):q.ingest({'x':0,'y':y,'refs':[]})
        self.assertTrue(q.rejected)
    def test_07_no_model_no_execution(self):
        with self.assertRaises(PermissionError):LearningQueen(0).predict(0)
    def test_08_unseen_not_executable(self):
        q,p,w,_=make_fixture(0,'switch',LearningQueen);q.attach(p);q.ingest(p.probe(0));q.bind()
        with self.assertRaises(PermissionError):q.execute_plan(7,7,[7])
    def test_09_sensor_duplicate_rejected(self):
        q,p,w,qs=make_fixture(0,'switch');rows=p.observe()
        with self.assertRaises(ValueError):Port.combine([rows[0]]*3)
    def test_10_sensor_disagreement_rejected(self):
        q,p,w,qs=make_fixture(0,'switch');rows=p.observe();rows[0]['channels'][0][1]^=1
        with self.assertRaises(ValueError):Port.combine(rows)
    def test_11_invalid_input_rejected(self):
        _,p,_,_=make_fixture(0,'switch')
        with self.assertRaises(ValueError):p.probe(512)
    def test_12_probe_history_is_receipt(self):
        _,p,_,_=make_fixture(0,'lag');r=p.probe(433);self.assertEqual(r['x'],433)
    def test_13_emitter_mismatch_rejected(self):
        _,p,_,qs=make_fixture(0,'switch');qs[0]._emit=lambda x:3
        with self.assertRaises(ValueError):p.probe(0)
    def test_14_reference_emitter_still_used(self):
        _,p,_,qs=make_fixture(0,'switch');r=p.probe(16);self.assertEqual(r['issued'],[0,1,0])
    def test_15_active_complete_exact(self):self.assertEqual(self.data['arms']['active']['complete']['all_correct'],512)
    def test_16_complete_goals(self):self.assertTrue(all(t['correct'] for t in self.data['arms']['active']['complete']['plans']))
    def test_17_real_withdrawal(self):self.assertTrue(self.data['arms']['active']['pressure']['blocked_without_action'])
    def test_18_real_recovery(self):self.assertTrue(self.data['arms']['active']['pressure']['recovery_correct'])
    def test_19_body_retained(self):self.assertTrue(self.data['arms']['active']['pressure']['historical_body_unchanged'])
    def test_20_cannot_certify_partial(self):self.assertFalse(self.data['arms']['active']['partial']['conditional_universal_certificate'])
    def test_21_affine_baseline_rejects(self):self.assertEqual(self.data['arms']['active']['paired_baselines']['affine_status'],'INCONSISTENT')
    def test_22_nonlinear_witness(self):self.assertIsNotNone(self.data['nonlinear_witness'])
    def test_23_full_verifier(self):self.assertTrue(verify(self.data)['passed'])
    def test_24_tampered_polynomial_rejected(self):
        d=copy.deepcopy(self.data);d['arms']['active']['partial']['model']['poly'][0][1]^=1
        with self.assertRaises(AuditError):verify(d)
    def test_25_tampered_source_rejected(self):
        d=copy.deepcopy(self.data);d['arms']['active']['archive']['trace'][0]['refs'][0]['body_sha']='0'*64
        with self.assertRaises(AuditError):verify(d)
    def test_26_tampered_rank_policy_rejected(self):
        d=copy.deepcopy(self.data);d['arms']['active']['partial']['model']['choices'][0]['x']^=1
        with self.assertRaises(AuditError):verify(d)
    def test_27_no_fixture_import(self):
        tree=ast.parse(Path(__file__).with_name('learner.py').read_text())
        self.assertFalse(any(isinstance(n,ast.ImportFrom) and n.module and ('world' in n.module or 'experiment' in n.module) for n in ast.walk(tree)))
    def test_28_hidden_state_stop(self):self.assertTrue(verify(hidden_counterexample(0))['passed'])
    def test_29_independent_physics(self):
        for kind in ('switch','lag','rare','lookup'):
            _,p,w,_=make_fixture(1,kind)
            for x in (0,433,511):self.assertEqual(p.probe(x)['y'],physical(w.spec,x)[0])
    def test_30_bound_mutation_stops(self):
        q,p,w,_=make_fixture(0,'switch',LearningQueen);q.attach(p);q.ingest(p.probe(0));q.bind();q.bound['degree']=9
        with self.assertRaises(PermissionError):q.predict(0)

if __name__=='__main__':unittest.main()
