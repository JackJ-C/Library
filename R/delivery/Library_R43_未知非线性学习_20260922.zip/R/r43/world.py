"""Evaluator/fixture only. Nonlinear transition structure is never passed to learner.
Each trial really calls three inherited emitters and stores three source ledgers.
Public port exposes only probes, reset, observe, and current action history.
"""
from __future__ import annotations
from random import Random
from collections import Counter
from copy import deepcopy
from .common import BaseQueen,bits,pack,sha,require

KINDS=('switch','lag','rare','lookup')
def specification(seed,kind):
    require(kind in KINDS,'kind')
    r=Random(seed); owner=r.sample(range(3),3); order=r.sample(range(3),3)
    peers=[]
    for i in range(3):
        # Four standard nonlinear truth tables on two local bits. None is supplied to learner.
        small=r.choice((8,14,1,7))
        table=[(small>>k)&1 for k in range(4)]*2
        if kind=='lag':
            table=[table[k]^(((k>>2)&1)&(k&1)) for k in range(8)]
        peers.append(table)
    return {'seed':seed,'kind':kind,'owner':owner,'sensor_order':order,
      'sensor_flip':r.randrange(8),'cross':[r.randrange(2) for _ in range(3)],
      'peers':peers,'peer_slots':[r.sample([p for p in range(3) if p!=owner[i]],2) for i in range(3)],
      'rare_x':r.randrange(512),'rare_bit':r.randrange(3),
      'lookup':[r.randrange(8) for _ in range(512)] if kind=='lookup' else None}

class World:
    def __init__(self,spec):
        self.spec=deepcopy(spec);self.s=0;self.h=0;self.count=Counter();self.hidden_toggle=False;self.toggle=0
    def to_physical(self,observed):
        v=bits(observed^self.spec['sensor_flip']);p=[0]*3
        for k,j in enumerate(self.spec['sensor_order']):p[j]=v[k]
        return p
    def to_observed(self,p):return pack([p[j] for j in self.spec['sensor_order']])^self.spec['sensor_flip']
    def observe(self):
        p=self.to_physical(self.s);out=[]
        for i,slots in enumerate(self.spec['peer_slots']):
            channels=[]
            for j in slots:
                alias=self.spec['sensor_order'].index(j)
                channels.append([alias,p[j]^((self.spec['sensor_flip']>>alias)&1)])
            out.append({'observer':i,'channels':channels})
        self.count['sensor_scalars']+=6
        return out
    def direct(self,u):
        f=self.spec;x=self.s|(u<<3)|(self.h<<6)
        if f['kind']=='lookup':d=self.to_physical(f['lookup'][x])
        else:
            s=self.to_physical(self.s);v=bits(u);d=s[:]
            for i,p in enumerate(f['owner']):
                j=f['owner'][(i+1)%3];k=f['owner'][(i+2)%3]
                effect=v[i]^(v[i]&s[j])^(f['cross'][i]&v[(i+1)%3]&s[k])
                d[p]=s[p]^effect
        self.count['physical_microsteps']+=1;return d
    def complete(self,d,responded,x):
        p=list(d)
        for i,j in enumerate(self.spec['owner']):p[j]^=responded[i]
        y=self.to_observed(p)
        if self.spec['kind']=='rare' and x==self.spec['rare_x']:y^=1<<self.spec['rare_bit']
        if self.hidden_toggle:y^=self.toggle;self.toggle^=1
        self.s=y;self.h=(x>>3)&7;self.count['physical_microsteps']+=1
        return y

class Port:
    __slots__=('__world','__actors','__focal','__birth','trace','sources')
    def __init__(self,world,actors,focal):
        self.__world=world;self.__actors=actors;self.__focal=focal
        self.__birth=[(id(q),id(q.ledger)) for q in actors];self.trace=[];self.sources=[]
    def observe(self):return self.__world.observe()
    def reset(self,s,h):
        require(type(s)is int and 0<=s<8 and type(h)is int and 0<=h<8,'reset outside finite scope')
        # A real priming pulse establishes observable previous external command history.
        self._execute(h,'primer')
        self.__world.s=s;self.__world.count['placements']+=1
        for q in self.__actors:q.r43_external_last=h
        return self.observe()
    @staticmethod
    def combine(packets):
        cells={i:[] for i in range(3)}; seen=set()
        for row in packets:
            require(row['observer'] not in seen,'duplicate observer');seen.add(row['observer'])
            for k,v in row['channels']:
                require(type(k)is int and k in cells and type(v)is int and v in (0,1),'bad sensor')
                cells[k].append((row['observer'],v))
        require(all(len({w for w,v in cells[k]})==2 and len({v for w,v in cells[k]})==1 for k in cells),'missing/inconsistent distinct witnesses')
        return pack([cells[k][0][1] for k in range(3)])
    def _execute(self,u,mode):
        require(type(u)is int and 0<=u<8,'action out of scope')
        w=self.__world; qs=self.__actors; before=self.observe();s=self.combine(before);h=w.h
        req=bits(u);issued=[];ints=[]
        for i,q in enumerate(qs):
            ints.append(q.add('R43_intention',{'mode':mode,'requested':req[i],'before':before[i],
                 'external_history':bits(h)[i]}))
            issued.append(q._emit(req[i]))
        require(issued==req,'emitter changed')
        x=s|(pack(issued)<<3)|(h<<6);d=w.direct(pack(issued));direct=w.to_observed(d)
        old=w.s;w.s=direct;dp=self.observe();w.s=old
        reactions=[];rints=[]
        for i,q in enumerate(qs):
            # Hidden peer program receives only its two local bits and own action history.
            local=[d[j] for j in w.spec['peer_slots'][i]]
            address=local[0]|(local[1]<<1)|(((h>>i)&1)<<2)
            request=q.r43_reactor(address)
            rints.append(q.add('R43_peer_intention',{'mode':mode,'local_view':dp[i],
                 'last_external':(h>>i)&1,'requested':request}))
            reactions.append(q._emit(request))
        y=w.complete(d,reactions,x);after=self.observe();refs=[]
        for i,q in enumerate(qs):
            ref=q.add('R43_observation',{'mode':mode,'before':before[i], 'direct':dp[i], 'after':after[i],
                   'issued':issued[i],'reacted':reactions[i], 'intention':ints[i],'reaction':rints[i]},deps=(ints[i],rints[i]))
            refs.append({'observer':i,'seq':ref,'body_sha':sha(q.ledger.records[ref].body)})
            q.r43_external_last=pack(issued)
        require(self.__birth==[(id(q),id(q.ledger)) for q in qs],'actor identity changed')
        row={'x':x,'mode':mode,'before':before,'direct':dp,'after':after,'issued':issued,
             'reactions':reactions,'refs':refs,'y':self.combine(dp)|(self.combine(after)<<3)}
        self.trace.append(row);self.sources.append(refs)
        return row
    def probe(self,x):
        require(type(x)is int and 0<=x<512,'query out of scope')
        self.reset(x&7,(x>>6)&7)
        return self._execute((x>>3)&7,'learning')
    def act(self,u):return self._execute(u,'deployment')
    def valid_sources(self,refs):
        for r in refs:
            q=self.__actors[r['observer']];seq=r['seq']
            if seq in q.ledger.invalid or sha(q.ledger.records[seq].body)!=r['body_sha']:return False
        return True
    def revoke_source(self,r):
        return self.__actors[r['observer']].ledger.revoke(r['seq'],'R43 explicit source withdrawal')
    def export(self):
        return {'trace':self.trace,'ledgers':[q.ledger.export() for q in self.__actors],
                'invalid':[sorted(q.ledger.invalid) for q in self.__actors],
                'count':dict(self.__world.count),'continuous_actor_objects':self.__birth==[(id(q),id(q.ledger)) for q in self.__actors]}

def make_fixture(seed,kind,learner_class=None):
    f=specification(seed,kind);focal=seed%3
    qs=[(learner_class(seed) if i==focal and learner_class else BaseQueen(seed*3+i)) for i in range(3)]
    for i,q in enumerate(qs):
        table=tuple(f['peers'][i]);q.r43_reactor=lambda address,t=table:t[address];q.r43_external_last=0
    w=World(f);return qs[focal],Port(w,qs,focal),w,qs
